---
name: 'Request a feature'
about: 'Create a feature request'
title: ''
labels: ''
assignees: ''

---

Describe in free form the feature you would like to request. Make sure it has
not been requested before.

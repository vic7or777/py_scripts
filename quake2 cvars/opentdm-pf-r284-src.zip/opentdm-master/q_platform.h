const char *Sys_FindFirst (const char *path);
const char *Sys_FindNext (void);
void Sys_FindClose (void);
void Sys_DebugBreak (void);

void VoteMenuDecreaseValue (edict_t *ent);


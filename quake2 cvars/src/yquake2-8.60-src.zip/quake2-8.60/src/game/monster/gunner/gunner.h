/*
 * Copyright (C) 1997-2001 Id Software, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.
 *
 * =======================================================================
 *
 * Gunner animations.
 *
 * =======================================================================
 */

#define FRAME_stand01 0
#define FRAME_stand02 1
#define FRAME_stand03 2
#define FRAME_stand04 3
#define FRAME_stand05 4
#define FRAME_stand06 5
#define FRAME_stand07 6
#define FRAME_stand08 7
#define FRAME_stand09 8
#define FRAME_stand10 9
#define FRAME_stand11 10
#define FRAME_stand12 11
#define FRAME_stand13 12
#define FRAME_stand14 13
#define FRAME_stand15 14
#define FRAME_stand16 15
#define FRAME_stand17 16
#define FRAME_stand18 17
#define FRAME_stand19 18
#define FRAME_stand20 19
#define FRAME_stand21 20
#define FRAME_stand22 21
#define FRAME_stand23 22
#define FRAME_stand24 23
#define FRAME_stand25 24
#define FRAME_stand26 25
#define FRAME_stand27 26
#define FRAME_stand28 27
#define FRAME_stand29 28
#define FRAME_stand30 29
#define FRAME_stand31 30
#define FRAME_stand32 31
#define FRAME_stand33 32
#define FRAME_stand34 33
#define FRAME_stand35 34
#define FRAME_stand36 35
#define FRAME_stand37 36
#define FRAME_stand38 37
#define FRAME_stand39 38
#define FRAME_stand40 39
#define FRAME_stand41 40
#define FRAME_stand42 41
#define FRAME_stand43 42
#define FRAME_stand44 43
#define FRAME_stand45 44
#define FRAME_stand46 45
#define FRAME_stand47 46
#define FRAME_stand48 47
#define FRAME_stand49 48
#define FRAME_stand50 49
#define FRAME_stand51 50
#define FRAME_stand52 51
#define FRAME_stand53 52
#define FRAME_stand54 53
#define FRAME_stand55 54
#define FRAME_stand56 55
#define FRAME_stand57 56
#define FRAME_stand58 57
#define FRAME_stand59 58
#define FRAME_stand60 59
#define FRAME_stand61 60
#define FRAME_stand62 61
#define FRAME_stand63 62
#define FRAME_stand64 63
#define FRAME_stand65 64
#define FRAME_stand66 65
#define FRAME_stand67 66
#define FRAME_stand68 67
#define FRAME_stand69 68
#define FRAME_stand70 69
#define FRAME_walk01 70
#define FRAME_walk02 71
#define FRAME_walk03 72
#define FRAME_walk04 73
#define FRAME_walk05 74
#define FRAME_walk06 75
#define FRAME_walk07 76
#define FRAME_walk08 77
#define FRAME_walk09 78
#define FRAME_walk10 79
#define FRAME_walk11 80
#define FRAME_walk12 81
#define FRAME_walk13 82
#define FRAME_walk14 83
#define FRAME_walk15 84
#define FRAME_walk16 85
#define FRAME_walk17 86
#define FRAME_walk18 87
#define FRAME_walk19 88
#define FRAME_walk20 89
#define FRAME_walk21 90
#define FRAME_walk22 91
#define FRAME_walk23 92
#define FRAME_walk24 93
#define FRAME_run01 94
#define FRAME_run02 95
#define FRAME_run03 96
#define FRAME_run04 97
#define FRAME_run05 98
#define FRAME_run06 99
#define FRAME_run07 100
#define FRAME_run08 101
#define FRAME_runs01 102
#define FRAME_runs02 103
#define FRAME_runs03 104
#define FRAME_runs04 105
#define FRAME_runs05 106
#define FRAME_runs06 107
#define FRAME_attak101 108
#define FRAME_attak102 109
#define FRAME_attak103 110
#define FRAME_attak104 111
#define FRAME_attak105 112
#define FRAME_attak106 113
#define FRAME_attak107 114
#define FRAME_attak108 115
#define FRAME_attak109 116
#define FRAME_attak110 117
#define FRAME_attak111 118
#define FRAME_attak112 119
#define FRAME_attak113 120
#define FRAME_attak114 121
#define FRAME_attak115 122
#define FRAME_attak116 123
#define FRAME_attak117 124
#define FRAME_attak118 125
#define FRAME_attak119 126
#define FRAME_attak120 127
#define FRAME_attak121 128
#define FRAME_attak201 129
#define FRAME_attak202 130
#define FRAME_attak203 131
#define FRAME_attak204 132
#define FRAME_attak205 133
#define FRAME_attak206 134
#define FRAME_attak207 135
#define FRAME_attak208 136
#define FRAME_attak209 137
#define FRAME_attak210 138
#define FRAME_attak211 139
#define FRAME_attak212 140
#define FRAME_attak213 141
#define FRAME_attak214 142
#define FRAME_attak215 143
#define FRAME_attak216 144
#define FRAME_attak217 145
#define FRAME_attak218 146
#define FRAME_attak219 147
#define FRAME_attak220 148
#define FRAME_attak221 149
#define FRAME_attak222 150
#define FRAME_attak223 151
#define FRAME_attak224 152
#define FRAME_attak225 153
#define FRAME_attak226 154
#define FRAME_attak227 155
#define FRAME_attak228 156
#define FRAME_attak229 157
#define FRAME_attak230 158
#define FRAME_pain101 159
#define FRAME_pain102 160
#define FRAME_pain103 161
#define FRAME_pain104 162
#define FRAME_pain105 163
#define FRAME_pain106 164
#define FRAME_pain107 165
#define FRAME_pain108 166
#define FRAME_pain109 167
#define FRAME_pain110 168
#define FRAME_pain111 169
#define FRAME_pain112 170
#define FRAME_pain113 171
#define FRAME_pain114 172
#define FRAME_pain115 173
#define FRAME_pain116 174
#define FRAME_pain117 175
#define FRAME_pain118 176
#define FRAME_pain201 177
#define FRAME_pain202 178
#define FRAME_pain203 179
#define FRAME_pain204 180
#define FRAME_pain205 181
#define FRAME_pain206 182
#define FRAME_pain207 183
#define FRAME_pain208 184
#define FRAME_pain301 185
#define FRAME_pain302 186
#define FRAME_pain303 187
#define FRAME_pain304 188
#define FRAME_pain305 189
#define FRAME_death01 190
#define FRAME_death02 191
#define FRAME_death03 192
#define FRAME_death04 193
#define FRAME_death05 194
#define FRAME_death06 195
#define FRAME_death07 196
#define FRAME_death08 197
#define FRAME_death09 198
#define FRAME_death10 199
#define FRAME_death11 200
#define FRAME_duck01 201
#define FRAME_duck02 202
#define FRAME_duck03 203
#define FRAME_duck04 204
#define FRAME_duck05 205
#define FRAME_duck06 206
#define FRAME_duck07 207
#define FRAME_duck08 208

#define MODEL_SCALE 1.150000

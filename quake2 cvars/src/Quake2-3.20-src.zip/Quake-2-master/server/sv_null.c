// sv_null.c -- this file can stub out the entire server system
// for pure net-only clients

void SV_Init (void)
{
}

void SV_Shutdown (char *finalmsg, qboolean reconnect)
{
}

void SV_Frame (float time)
{
}


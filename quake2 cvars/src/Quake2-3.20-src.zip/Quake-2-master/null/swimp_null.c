#include "../ref_soft/r_local.h"

void		SWimp_BeginFrame( float camera_separation )
{
}

void		SWimp_EndFrame (void)
{
}

int			SWimp_Init( void *hInstance, void *wndProc )
{
}

void		SWimp_SetPalette( const unsigned char *palette)
{
}

void		SWimp_Shutdown( void )
{
}

rserr_t		SWimp_SetMode( int *pwidth, int *pheight, int mode, qboolean fullscreen )
{
}

void		SWimp_AppActivate( qboolean active )
{
}


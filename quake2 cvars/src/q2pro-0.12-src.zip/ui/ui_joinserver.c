/*
Copyright (C) 1997-2001 Id Software, Inc.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

#include "ui_local.h"

/*
=============================================================================

JOIN SERVER MENU

=============================================================================
*/

static menuframework_s	s_joinserver_menu;
static menuseparator_s	s_joinserver_server_title;
static menuaction_s		s_joinserver_search_action;
static menuaction_s		s_joinserver_address_book_action;
static menuaction_s		s_joinserver_server_actions[MAX_LOCAL_SERVERS];

int		m_num_servers;
#define	NO_SERVER_STRING	"<no server>"

// user readable information
static serverStatus_t localServers[MAX_LOCAL_SERVERS];
static char	local_server_names[MAX_LOCAL_SERVERS][MAX_QPATH];

void M_AddToServerList( const serverStatus_t *status ) {
	serverStatus_t *s;
	char buffer[32];
	int		i;
	
	if( m_num_servers == MAX_LOCAL_SERVERS ) {
		return;
	}

	// ignore if duplicated
	for( i=0, s=localServers ; i<m_num_servers ; i++, s++ ) {
		if( !strcmp( status->address, s->address ) ) {
			return;
		}
	}

	localServers[m_num_servers] = *status;

	Q_strncpyz( buffer, Info_ValueForKey( status->infostring, "hostname" ), sizeof( buffer ) );
	if( strlen( buffer ) > 18 ) {
		strcpy( buffer + 15, "..." );
	}

	i = atoi( Info_ValueForKey( status->infostring, "maxclients" ) );
	Com_sprintf( local_server_names[m_num_servers], sizeof( local_server_names[0] ), "%-18s %i/%i", buffer, status->numPlayers, i );

	m_num_servers++;
}


void JoinServerFunc( void *self )
{
	char	buffer[128];
	int		index;

	index = ( menuaction_s * ) self - s_joinserver_server_actions;

	if ( Q_stricmp( local_server_names[index], NO_SERVER_STRING ) == 0 )
		return;

	if (index >= m_num_servers)
		return;

	Com_sprintf (buffer, sizeof(buffer), "connect %s\n", localServers[index].address );
	Cbuf_AddText (buffer);
	M_ForceMenuOff ();
}

void AddressBookFunc( void *self )
{
	M_Menu_AddressBook_f();
}

void NullCursorDraw( void *self )
{
}

void SearchLocalGames( void )
{
	int		i;

	m_num_servers = 0;
	for (i=0 ; i<MAX_LOCAL_SERVERS ; i++)
		strcpy (local_server_names[i], NO_SERVER_STRING);

	M_DrawTextBox( 8, 120 - 48, 36, 3 );
	M_Print( 16 + 16, 120 - 48 + 8,  "Refreshing server list, this" );
	M_Print( 16 + 16, 120 - 48 + 16, "could take up to a minute, so" );
	M_Print( 16 + 16, 120 - 48 + 24, "please be patient." );

	// the text box won't show up unless we do a buffer swap
	re.EndFrame();

	// send out info packets
	CL_PingServers_f();
}

void SearchLocalGamesFunc( void *self )
{
	SearchLocalGames();
}



void JoinServer_InfoDraw( void ) {
	char key[MAX_INFO_KEY];
	char value[MAX_INFO_VALUE];
	char *info;
	int x = s_joinserver_menu.x + 180;
	int y = s_joinserver_menu.y + 30;
	int index;
	serverStatus_t *server;
	playerStatus_t *player;
	int i;

	// Never draw on low resolutions
	if( viddef.width < 512 ) {
		return;
	}

	index = s_joinserver_menu.cursor - 3;
	if( index < 0 || index >= MAX_LOCAL_SERVERS ) {
		return;
	}

	if( !strcmp( local_server_names[index], NO_SERVER_STRING ) ) {
		return;
	}

	server = &localServers[index];

	SCR_DrawString( x, y, "Server info", DSF_HIGHLIGHT );
	y += 10;

	info = server->infostring;
	while( info ) {
		Info_NextPair( &info, key, value );

		if( strlen( key ) > 15 ) {
			strcpy( key + 12, "..." );
		}

		SCR_DrawString( x, y, va( "%-8s", key ), 0 );
		SCR_DrawString( x + 16 * 8, y, va( "%-16s", value ), 0 );
		y += 8;
	}

	y += 8;

	if( !server->numPlayers ) {
		SCR_DrawString( x, y, "No players", DSF_HIGHLIGHT );
		return;
	}

	SCR_DrawString( x, y, "Score Ping Name", DSF_HIGHLIGHT );
	y += 10;

	for( i=0, player=server->players ; i<server->numPlayers ; i++, player++ ) {
		SCR_DrawString( x, y, va( "%5i %4i %s\n", player->score, player->ping, player->name ), 0 );
		y += 8;
	}

}

static void JoinServer_MenuDraw( menuframework_s *self ) {
	int w, h;

	re.DrawGetPicSize( &w, &h, "m_banner_join_server" );
	re.DrawPic( (viddef.width - w) >> 1, s_joinserver_menu.y - h - 16, "m_banner_join_server" );

	JoinServer_InfoDraw();

	Menu_Draw( self );
}

void JoinServer_MenuInit( void )
{
	int i;

	s_joinserver_menu.x = 60;
	s_joinserver_menu.y = 60;
	s_joinserver_menu.nitems = 0;

	s_joinserver_address_book_action.generic.type	= MTYPE_ACTION;
	s_joinserver_address_book_action.generic.name	= "address book";
	s_joinserver_address_book_action.generic.flags	= QMF_LEFT_JUSTIFY;
	s_joinserver_address_book_action.generic.x		= 0;
	s_joinserver_address_book_action.generic.y		= 0;
	s_joinserver_address_book_action.generic.callback = AddressBookFunc;

	s_joinserver_search_action.generic.type = MTYPE_ACTION;
	s_joinserver_search_action.generic.name	= "refresh server list";
	s_joinserver_search_action.generic.flags	= QMF_LEFT_JUSTIFY;
	s_joinserver_search_action.generic.x	= 0;
	s_joinserver_search_action.generic.y	= 10;
	s_joinserver_search_action.generic.callback = SearchLocalGamesFunc;
	s_joinserver_search_action.generic.statusbar = "search for servers";

	s_joinserver_server_title.generic.type = MTYPE_SEPARATOR;
	s_joinserver_server_title.generic.name = "connect to...";
	s_joinserver_server_title.generic.x    = 80;
	s_joinserver_server_title.generic.y	   = 30;

	for( i=0 ; i<MAX_LOCAL_SERVERS ; i++ ) {
		s_joinserver_server_actions[i].generic.type	= MTYPE_ACTION;
		strcpy( local_server_names[i], NO_SERVER_STRING );
		s_joinserver_server_actions[i].generic.name	= local_server_names[i];
		s_joinserver_server_actions[i].generic.flags	= QMF_LEFT_JUSTIFY;
		s_joinserver_server_actions[i].generic.x		= 0;
		s_joinserver_server_actions[i].generic.y		= 40 + i*10;
		s_joinserver_server_actions[i].generic.callback = JoinServerFunc;
		s_joinserver_server_actions[i].generic.statusbar = "press ENTER to connect";
	}

	s_joinserver_menu.draw = JoinServer_MenuDraw;
	s_joinserver_menu.key = NULL;

	Menu_AddItem( &s_joinserver_menu, &s_joinserver_address_book_action );
	Menu_AddItem( &s_joinserver_menu, &s_joinserver_server_title );
	Menu_AddItem( &s_joinserver_menu, &s_joinserver_search_action );

	for ( i = 0; i < MAX_LOCAL_SERVERS; i++ )
		Menu_AddItem( &s_joinserver_menu, &s_joinserver_server_actions[i] );

	//Menu_Center( &s_joinserver_menu );

	SearchLocalGames();
}

const char *JoinServer_MenuKey( int key )
{
	return Default_MenuKey( &s_joinserver_menu, key );
}

void M_Menu_JoinServer_f (void)
{
	JoinServer_MenuInit();
	M_PushMenu( &s_joinserver_menu );
}

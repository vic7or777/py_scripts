/*
Copyright (C) 1997-2001 Id Software, Inc.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

#include "ui_local.h"

/*
=======================================================================

VIDEO MENU

=======================================================================
*/

#define REF_SOFT	0
#define REF_OPENGL	1
#define REF_3DFX	2
#define REF_POWERVR	3
#define REF_VERITE	4

extern qboolean m_entersound;

/*
====================================================================

MENU INTERACTION

====================================================================
*/
#define SOFTWARE_MENU 0
#define OPENGL_MENU   1

static const char *resolutions[] = {
	"[320 240  ]",
	"[400 300  ]",
	"[512 384  ]",
	"[640 480  ]",
	"[800 600  ]",
	"[960 720  ]",
	"[1024 768 ]",
	"[1152 864 ]",
	"[1280 960 ]",
	"[1600 1200]",
	0
};

static const char *refs[] = {
	"[software      ]",
	"[default OpenGL]",
	"[3Dfx OpenGL   ]",
	"[PowerVR OpenGL]",
//		"[Rendition OpenGL]",
	0
};

static const char *yesno_names[] = {
	"no",
	"yes",
	0
};

typedef struct softwareMenu_s {
	menuframework_s	menu;
	menulist_s		mode_list;
	menulist_s  	stipple_box;
	menuaction_s	cancel_action;
	menuaction_s	defaults_action;
} softwareMenu_t;

typedef struct glMenu_s {
	menuframework_s	menu;
	menulist_s		mode_list;
	menuslider_s	tq_slider;
	menulist_s  	paletted_texture_box;
	menulist_s  	finish_box;
} glMenu_t;

typedef struct videoMenu_s {
	menulist_s	ref_list;
	menuslider_s	screensize_slider;
	menuslider_s	brightness_slider;
	menulist_s  	fs_box;
	menuaction_s	cancel_action;
	menuaction_s	defaults_action;
} videoMenu_t;

static softwareMenu_t	m_soft;
static glMenu_t			m_gl;
static videoMenu_t		m_video;

static void VideoMenu_InitSoft( void );
static void VideoMenu_InitGL( void );

static void VideoMenu_DriverCallbackSoft( void *unused ) {
	if( m_video.ref_list.curvalue == REF_SOFT ) {
		return;
	}

	m_entersound = qtrue;

	M_PopMenu();

	VideoMenu_InitGL();
	M_PushMenu( &m_gl.menu );

	m_entersound = qfalse;
	
}

static void VideoMenu_DriverCallbackGL( void *unused ) {
	if( m_video.ref_list.curvalue != REF_SOFT ) {
		return;
	}

	m_entersound = qtrue;

	M_PopMenu();

	VideoMenu_InitSoft();
	M_PushMenu( &m_soft.menu );

	m_entersound = qfalse;

}

static void ScreenSizeCallback( void *s ) {
	menuslider_s *slider = (menuslider_s *)s;

	Cvar_SetValue( "viewsize", slider->curvalue * 10 );
}

static void BrightnessCallback( void *s ) {
	menuslider_s *slider = (menuslider_s *)s;

	if( slider->generic.parent == &m_soft.menu ) {
		float gamma = (0.8 - (slider->curvalue / 10.0 - 0.5)) + 0.5;

		Cvar_SetValue( "vid_gamma", gamma );
	}
}

static void ResetDefaults( void *unused ) {
	m_entersound = qtrue;
	M_PopMenu();
	M_Menu_Video_f();
	m_entersound = qfalse;
}

static void VideoMenu_ApplyChangesSoft( void *unused ) {
	float gamma;

	/*
	** invert sense so greater = brighter, and scale to a range of 0.5 to 1.3
	*/
	gamma = (0.8 - (m_video.brightness_slider.curvalue / 10.0 - 0.5)) + 0.5;

	Cvar_Set( "vid_ref", "soft" );
	Cvar_SetValue( "vid_gamma", gamma );
	Cvar_SetValue( "vid_fullscreen", m_video.fs_box.curvalue );
	Cvar_SetValue( "sw_stipplealpha", m_soft.stipple_box.curvalue );
	Cvar_SetValue( "sw_mode", m_soft.mode_list.curvalue );

	Cbuf_AddText( "vid_restart\n" );

	M_ForceMenuOff();
}

static void VideoMenu_ApplyChangesGL( void *unused ) {
	float gamma;

	/*
	** invert sense so greater = brighter, and scale to a range of 0.5 to 1.3
	*/
	gamma = (0.8 - (m_video.brightness_slider.curvalue / 10.0 - 0.5)) + 0.5;

	Cvar_Set( "vid_ref", "gl" );
	Cvar_SetValue( "vid_gamma", gamma );
	Cvar_SetValue( "gl_picmip", 3 - m_gl.tq_slider.curvalue );
	Cvar_SetValue( "vid_fullscreen", m_video.fs_box.curvalue );
	Cvar_SetValue( "gl_ext_palettedtexture", m_gl.paletted_texture_box.curvalue );
	Cvar_SetValue( "gl_finish", m_gl.finish_box.curvalue );
	Cvar_SetValue( "gl_mode", m_gl.mode_list.curvalue );

	switch( m_video.ref_list.curvalue ) {
	case REF_OPENGL:
		Cvar_Set( "gl_driver", "opengl32" );
		break;
	case REF_3DFX:
		Cvar_Set( "gl_driver", "3dfxgl" );
		break;
	case REF_POWERVR:
		Cvar_Set( "gl_driver", "pvrgl" );
		break;
	case REF_VERITE:
		Cvar_Set( "gl_driver", "veritegl" );
		break;
	}

	Cbuf_AddText( "vid_restart\n" );

	M_ForceMenuOff();
}

/*
================
VID_MenuDraw
================
*/
void VID_MenuDraw( menuframework_s *self ) {
	int w, h;

	/*
	** draw the banner
	*/
	re.DrawGetPicSize( &w, &h, "m_banner_video" );
	re.DrawPic( viddef.width / 2 - w / 2, viddef.height /2 - 110, "m_banner_video" );

	/*
	** move cursor to a reasonable starting position
	*/
	Menu_AdjustCursor( self, 1 );

	/*
	** draw the menu
	*/
	Menu_Draw( self );
}

/*
================
VID_MenuKey
================
*/
static const char *VID_MenuKey( menuframework_s *self, int key ) {
	static const char *sound = "misc/menu1.wav";

	switch( key ) {
	case K_ESCAPE:
		M_PopMenu();
		return NULL;
	case K_KP_UPARROW:
	case K_UPARROW:
		self->cursor--;
		Menu_AdjustCursor( self, -1 );
		break;
	case K_KP_DOWNARROW:
	case K_DOWNARROW:
		self->cursor++;
		Menu_AdjustCursor( self, 1 );
		break;
	case K_KP_LEFTARROW:
	case K_LEFTARROW:
		Menu_SlideItem( self, -1 );
		break;
	case K_KP_RIGHTARROW:
	case K_RIGHTARROW:
		Menu_SlideItem( self, 1 );
		break;
	case K_KP_ENTER:
	case K_ENTER:
		Menu_SelectItem( self );
		break;
	}

	return sound;
}

static void VideoMenu_Init( void ) {
	memset( &m_video, 0, sizeof( m_video ) );

	m_video.ref_list.generic.type = MTYPE_SPINCONTROL;
	m_video.ref_list.generic.name = "driver";
	m_video.ref_list.generic.x = 0;
	m_video.ref_list.generic.y = 0;
	m_video.ref_list.generic.callback = NULL;
	m_video.ref_list.itemnames = refs;
	m_video.ref_list.curvalue = -1;

	m_video.screensize_slider.generic.type	= MTYPE_SLIDER;
	m_video.screensize_slider.generic.x		= 0;
	m_video.screensize_slider.generic.y		= 20;
	m_video.screensize_slider.generic.name	= "screen size";
	m_video.screensize_slider.minvalue = 3;
	m_video.screensize_slider.maxvalue = 12;
	m_video.screensize_slider.generic.callback = ScreenSizeCallback;
	m_video.screensize_slider.curvalue = Cvar_VariableIntegerValue( "viewsize" ) / 10;

	m_video.brightness_slider.generic.type	= MTYPE_SLIDER;
	m_video.brightness_slider.generic.x	= 0;
	m_video.brightness_slider.generic.y	= 30;
	m_video.brightness_slider.generic.name	= "brightness";
	m_video.brightness_slider.generic.callback = BrightnessCallback;
	m_video.brightness_slider.minvalue = 5;
	m_video.brightness_slider.maxvalue = 13;
	m_video.brightness_slider.curvalue = (1.3 - Cvar_VariableValue( "vid_gamma" ) + 0.5) * 10;

	m_video.fs_box.generic.type = MTYPE_SPINCONTROL;
	m_video.fs_box.generic.x = 0;
	m_video.fs_box.generic.y = 40;
	m_video.fs_box.generic.name = "fullscreen";
	m_video.fs_box.itemnames = yesno_names;
	m_video.fs_box.curvalue = Cvar_VariableIntegerValue( "vid_fullscreen" );

	m_video.defaults_action.generic.type = MTYPE_ACTION;
	m_video.defaults_action.generic.name = "reset to defaults";
	m_video.defaults_action.generic.x    = 0;
	m_video.defaults_action.generic.y    = 90;
	m_video.defaults_action.generic.callback = ResetDefaults;

	m_video.cancel_action.generic.type = MTYPE_ACTION;
	m_video.cancel_action.generic.name = "apply changes";
	m_video.cancel_action.generic.x    = 0;
	m_video.cancel_action.generic.y    = 100;
	m_video.cancel_action.generic.callback = NULL;
}

static void VideoMenu_InitSoft( void ) {
	m_video.ref_list.curvalue = REF_SOFT;
	m_video.ref_list.generic.callback = VideoMenu_DriverCallbackSoft;
	m_video.cancel_action.generic.callback = VideoMenu_ApplyChangesSoft;

	memset( &m_soft, 0, sizeof( m_soft ) );

	m_soft.menu.x = viddef.width * 0.50;

	m_soft.mode_list.generic.type = MTYPE_SPINCONTROL;
	m_soft.mode_list.generic.name = "video mode";
	m_soft.mode_list.generic.x = 0;
	m_soft.mode_list.generic.y = 10;
	m_soft.mode_list.itemnames = resolutions;
	m_soft.mode_list.curvalue = Cvar_VariableValue( "sw_mode" );

	m_soft.stipple_box.generic.type = MTYPE_SPINCONTROL;
	m_soft.stipple_box.generic.x	= 0;
	m_soft.stipple_box.generic.y	= 60;
	m_soft.stipple_box.generic.name	= "stipple alpha";
	m_soft.stipple_box.curvalue = Cvar_VariableIntegerValue( "sw_stipplealpha" );
	m_soft.stipple_box.itemnames = yesno_names;

	m_soft.menu.draw = VID_MenuDraw;
	m_soft.menu.key = NULL;

	Menu_AddItem( &m_soft.menu, (void *)&m_video.ref_list );
	Menu_AddItem( &m_soft.menu, (void *)&m_soft.mode_list );
	Menu_AddItem( &m_soft.menu, (void *)&m_video.screensize_slider );
	Menu_AddItem( &m_soft.menu, (void *)&m_video.brightness_slider );
	Menu_AddItem( &m_soft.menu, (void *)&m_video.fs_box );
	Menu_AddItem( &m_soft.menu, (void *)&m_soft.stipple_box );
	Menu_AddItem( &m_soft.menu, ( void * )&m_video.defaults_action );
	Menu_AddItem( &m_soft.menu, ( void * )&m_video.cancel_action );

	Menu_Center( &m_soft.menu );
	m_soft.menu.x -= 8;
}

/*
** VID_MenuInit
*/
static void VideoMenu_InitGL( void ) {
	char *driver;

	m_video.ref_list.curvalue = REF_OPENGL;
	m_video.ref_list.generic.callback = VideoMenu_DriverCallbackGL;
	m_video.cancel_action.generic.callback = VideoMenu_ApplyChangesGL;

	memset( &m_gl, 0, sizeof( m_gl ) );

	driver = Cvar_VariableString( "gl_driver" );
	if( !Q_stricmp( driver, "3dfxgl" ) ) {
		m_video.ref_list.curvalue = REF_3DFX;
	} else if( !Q_stricmp( driver, "pvrgl" ) ) {
		m_video.ref_list.curvalue = REF_POWERVR;
	}
	
	m_gl.menu.x = viddef.width * 0.50;

	m_gl.mode_list.generic.type = MTYPE_SPINCONTROL;
	m_gl.mode_list.generic.name = "video mode";
	m_gl.mode_list.generic.x = 0;
	m_gl.mode_list.generic.y = 10;
	m_gl.mode_list.itemnames = resolutions;
	m_gl.mode_list.curvalue = Cvar_VariableIntegerValue( "gl_mode" );

	m_gl.tq_slider.generic.type	= MTYPE_SLIDER;
	m_gl.tq_slider.generic.x		= 0;
	m_gl.tq_slider.generic.y		= 60;
	m_gl.tq_slider.generic.name	= "texture quality";
	m_gl.tq_slider.minvalue = 0;
	m_gl.tq_slider.maxvalue = 3;
	m_gl.tq_slider.curvalue = 3 - Cvar_VariableIntegerValue( "gl_picmip" );

	m_gl.paletted_texture_box.generic.type = MTYPE_SPINCONTROL;
	m_gl.paletted_texture_box.generic.x	= 0;
	m_gl.paletted_texture_box.generic.y	= 70;
	m_gl.paletted_texture_box.generic.name	= "8-bit textures";
	m_gl.paletted_texture_box.itemnames = yesno_names;
	m_gl.paletted_texture_box.curvalue = Cvar_VariableIntegerValue( "gl_ext_palettedtexture" );

	m_gl.finish_box.generic.type = MTYPE_SPINCONTROL;
	m_gl.finish_box.generic.x	= 0;
	m_gl.finish_box.generic.y	= 80;
	m_gl.finish_box.generic.name	= "sync every frame";
	m_gl.finish_box.curvalue = Cvar_VariableIntegerValue( "gl_finish" );
	m_gl.finish_box.itemnames = yesno_names;

	m_gl.menu.draw = VID_MenuDraw;
	m_gl.menu.key = NULL;

	Menu_AddItem( &m_gl.menu, (void *)&m_video.ref_list );
	Menu_AddItem( &m_gl.menu, (void *)&m_gl.mode_list );
	Menu_AddItem( &m_gl.menu, (void *)&m_video.screensize_slider );
	Menu_AddItem( &m_gl.menu, (void *)&m_video.brightness_slider );
	Menu_AddItem( &m_gl.menu, (void *)&m_video.fs_box );
	Menu_AddItem( &m_gl.menu, (void *)&m_gl.tq_slider );
	Menu_AddItem( &m_gl.menu, (void *)&m_gl.paletted_texture_box );
	Menu_AddItem( &m_gl.menu, (void *)&m_gl.finish_box );
	Menu_AddItem( &m_gl.menu, (void *)&m_video.defaults_action );
	Menu_AddItem( &m_gl.menu, (void *)&m_video.cancel_action );

	Menu_Center( &m_gl.menu );
	m_gl.menu.x -= 8;

}

void VID_MenuInit( void ) {

}

void M_Menu_Video_f( void ) {
	VideoMenu_Init();

	if( !Q_stricmp( Cvar_VariableString( "vid_ref" ), "soft" ) ) {
		VideoMenu_InitSoft();
		M_PushMenu( &m_soft.menu );
	} else {
		VideoMenu_InitGL();
		M_PushMenu( &m_gl.menu );
	}
	
}

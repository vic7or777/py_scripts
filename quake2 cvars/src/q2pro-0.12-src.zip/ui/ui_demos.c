/*
Copyright (C) 2003 Andrey Nazarov

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

#include "ui_local.h"

/*
=======================================================================

DEMOS MENU

=======================================================================
*/

#define DOUBLE_CLICK_DELAY	300

#define MAX_MENU_DEMOS	1024
#define MAX_DEMO_CLIENTS	32

#define FFILE_UP	1
#define FFILE_FOLDER	2
#define FFILE_DEMO	3

typedef struct m_demos_s {
	menuframework_s		menu;
	menulist_s		list;

	int				count;
	char		*names[MAX_MENU_DEMOS];
	int			types[MAX_MENU_DEMOS];
	int			maxLength;

	int		lastClick;

	// Demo file info
	qboolean mvd;
	char	gamedir[MAX_QPATH];
	char	mapname[MAX_QPATH];
	char	fullLevelName[MAX_QPATH];
	int		clientNum;
	char	*clients[MAX_DEMO_CLIENTS];
} m_demos_t;

static m_demos_t	m_demos;
static char			m_demos_browse[MAX_OSPATH];
static int			m_demos_selection;

static void Demos_MenuDraw( menuframework_s *self ) {
	int x, y;
	int i;
	char *pic;

	re.DrawPic( (viddef.width - 118) / 2, 10, "m_main_demos" );

	if( m_demos.mapname[0] ) {
		re.DrawStretchPic( viddef.width - 262, 60, 256, 192, "inventory" );
		if( re.RegisterPic( m_demos.mapname ) ) {
			pic = m_demos.mapname;
		} else {
			pic = "conback";
		}
		re.DrawStretchPic( viddef.width - 262 + 16 - 2, 60 + 16, 256-16*2+5, 192-16*2, pic );

		y = 60 + 192 + 10;
		x = viddef.width - 262 + 256/2;

		if( !m_demos.gamedir[0] ) {
			SCR_DrawString( x, y, m_demos.fullLevelName, DSF_CENTERX|DSF_HIGHLIGHT );
		} else {
			SCR_DrawString( x, y, va( "%s - %s", m_demos.fullLevelName, m_demos.gamedir ), DSF_CENTERX|DSF_HIGHLIGHT );
		}

		y += 16;

		x = viddef.width - 262 + 8;

		SCR_DrawString( x, y, "POV Name", DSF_HIGHLIGHT );
		y += 12;

		for( i=0 ; i<MAX_DEMO_CLIENTS ; i++ ) {
			if( !m_demos.clients[i] ) {
				continue;
			}
			SCR_DrawString( x, y, va( "  %c %s", (m_demos.mvd || i == m_demos.clientNum) ? 11 : ' ', m_demos.clients[i] ), 0 );
			y += 10;
			if( y > viddef.height - 32 ) {
				break;
			}
		}

	}

	SCR_DrawString( 10, 50, va( "Directory of %s", m_demos_browse ), DSF_HIGHLIGHT );

	SCR_DrawString( viddef.width / 2, viddef.height - 20, m_demos.names[m_demos.list.curvalue], DSF_HIGHLIGHT|DSF_CENTERX );

	Menu_Draw( self );
}

static void Demos_FreeInfo( void ) {
	int i;

	m_demos.gamedir[0] = 0;
	m_demos.mapname[0] = 0;
	m_demos.fullLevelName[0] = 0;

	for( i=0 ; i<MAX_DEMO_CLIENTS ; i++ ) {
		if( m_demos.clients[i] ) {
			Z_Free( m_demos.clients[i] );
			m_demos.clients[i] = 0;
		}
	}
}

static qboolean Demos_ReadNextMessage( sizebuf_t *msg, fileHandle_t hFile ) {
	// read msglen
	if( FS_Read( &msg->cursize, 4, hFile ) != 4 ) {
		return qfalse;
	}

	msg->cursize = LittleLong( msg->cursize );
	if( msg->cursize < 1 ) {
		return qfalse;
	}

	if( msg->cursize >= msg->maxsize ) {
		return qfalse;
	}

	// read packet data
	if( FS_Read( msg->data, msg->cursize, hFile ) != msg->cursize ) {
		return qfalse;
	}

	MSG_BeginReading( msg );

	return qtrue;
}

static void Demos_LoadInfo( int num ) {
	byte msgbuf[MAX_MVD_MSGLEN];
	sizebuf_t msg;
	char buffer[MAX_OSPATH];
	fileHandle_t hFile;
	int c;
	char *s, *p;

	Demos_FreeInfo();

	if( m_demos.types[num] != FFILE_DEMO ) {
		return;
	}

	Com_sprintf( buffer, sizeof( buffer ), "%s/%s", m_demos_browse + 1, m_demos.names[num] );

	FS_FOpenFileFullPath( buffer, &hFile, FS_READ );
	if( !hFile ) {
		return;
	}

	// init larger buffer for MVDs
	SZ_Init( &msg, msgbuf, sizeof( msgbuf ) );

	if( !Demos_ReadNextMessage( &msg, hFile ) ) {
		goto exit;
	}

	if( MSG_ReadByte( &msg ) != svc_serverdata ) {
		goto exit;
	}

	c = MSG_ReadLong( &msg );
/*
	if( c == PROTOCOL_VERSION) {
		m_demos.mvd = qfalse;
	} else if( c == PROTOCOL_VERSION_Q2PRO ) {
		m_demos.mvd = qtrue;
	} else {
		goto exit;
	}
*/
	m_demos.mvd = qfalse;
	if( c == PROTOCOL_VERSION_Q2PRO ) {
		m_demos.mvd = qtrue;
	}

	MSG_ReadLong( &msg );
	MSG_ReadByte( &msg );

	Q_strncpyz( m_demos.gamedir, MSG_ReadString( &msg ), sizeof( m_demos.gamedir ) );

	m_demos.clientNum = MSG_ReadShort( &msg );

	Q_strncpyz( m_demos.fullLevelName, MSG_ReadString( &msg ), sizeof( m_demos.fullLevelName ) );

	while( 1 ) {
		c = MSG_ReadByte( &msg );
		if( c == -1 ) {
			if( !Demos_ReadNextMessage( &msg, hFile ) ) {
				break;
			}
			continue;
		}
		if( c != svc_configstring ) {
			break;
		}
		c = MSG_ReadShort( &msg );
		s = MSG_ReadString( &msg );
		if( c >= CS_PLAYERSKINS && c < CS_PLAYERSKINS + MAX_DEMO_CLIENTS ) {
			Q_strncpyz( buffer, s, MAX_CLIENT_NAME );
			p = strchr( buffer, '\\' );
			if( p ) {
				*p = 0;
			}
			m_demos.clients[c - CS_PLAYERSKINS] = CopyString( buffer );
		} else if( c == CS_MODELS + 1 ) {
			if( strlen( s ) > 9 ) {
				Q_strncpyz( m_demos.mapname, s + 5, sizeof( m_demos.mapname ) ); // skip "maps/"
				m_demos.mapname[strlen( m_demos.mapname ) - 4] = 0; // cut off ".bsp"
			}
		}
	}

exit:
	FS_FCloseFile( hFile );


}


static char *Demos_BuildName( const char *base, const char *extenstion, int fileType ) {
	char buffer[MAX_STRING_CHARS];
	char name[MAX_QPATH];
	const char *type;
	char *s;
	int len;

	//if( fileType == FFILE_DEMO ) {
	//	COM_StripExtension( base, name, sizeof( name ) );
	//	base = name;
	//}
//	len = strlen( name );
//	if( len > 16 ) {
//		strcpy( name + 16 - 3, "..." );
//	}

	switch( fileType ) {
	case FFILE_UP:
		type = " UP";
		break;
	case FFILE_FOLDER:
		type = "DIR";
		break;
	case FFILE_DEMO:
		if( !Q_stricmpn( extenstion, ".mvd2", 5 ) ) {
			type = "MVD";
		} else {
			type = "DM2";
		}
		break;
	default:
		type = "";
		break;
	}

	Q_strncpyz( name, base, sizeof( name ) );
	/*s = COM_FileExtension( name );
	if( !Q_stricmp( s, ".gz" ) ) {
		*s = 0;
		s = COM_FileExtension( name );
	}
	*s = 0;*/

	strcpy( buffer, name );
	strcpy( buffer + strlen( name ) + 1, type );

	len = strlen( name ) + strlen( type ) + 2;
	s = Z_Malloc( len );
	memcpy( s, buffer, len );

	return s;

}

static void Demos_Scan( const char *path, const char *extenstion ) {
	int numFiles;
	char **list;
	int i;
	
	list = Sys_ListFiles( path, extenstion, NULL, -1, &numFiles );
	if( !list ) {
		return;
	}

	for( i=0 ; i<numFiles ; i++ ) {
		if( m_demos.count == MAX_MENU_DEMOS - 1 ) {
			break;
		}

		m_demos.names[m_demos.count] = Demos_BuildName( list[i], extenstion, FFILE_DEMO );
		m_demos.types[m_demos.count] = FFILE_DEMO;
		m_demos.count++;
	}

	FS_FreeFileList( list );
	
}

static void Demos_BuildList( const char *path ) {
	char fullpath[MAX_OSPATH];
	int numFiles;
	char **list;
	int pos;
	int i;

	// Construct full path
	Com_sprintf( fullpath, sizeof( fullpath ), "%s%s", Cvar_VariableString( "basedir" ), path );
	
	if( *path ) {
		m_demos.names[m_demos.count] = Demos_BuildName( "..", NULL, FFILE_UP );
		m_demos.types[m_demos.count] = FFILE_UP;
		m_demos.count++;
	}

	// List directories first
	list = Sys_ListFiles( fullpath, NULL, NULL, 1, &numFiles );
	if( list ) {
		for( i=0 ; i<numFiles ; i++ ) {
			if( m_demos.count == MAX_MENU_DEMOS - 1 ) {
				break;
			}
			m_demos.names[m_demos.count] = Demos_BuildName( list[i], NULL, FFILE_FOLDER );
			m_demos.types[m_demos.count] = FFILE_FOLDER;
			m_demos.count++;
		}

		FS_FreeFileList( list );
	}	

	pos = m_demos.count;

	Demos_Scan( fullpath, ".dm2" );
	Demos_Scan( fullpath, ".dm2.gz" );
	Demos_Scan( fullpath, ".mvd2" );
	Demos_Scan( fullpath, ".mvd2.gz" );

	// Sort demos, not directories
	if( m_demos.count - pos > 1 ) {
		qsort( m_demos.names + pos, m_demos.count - pos, sizeof( m_demos.names[0] ), SortStrcmp );
	}

	m_demos.names[m_demos.count] = NULL;
}

static void Demos_Free( void ) {
	int i;

	Demos_FreeInfo();

	for( i=0 ; i<m_demos.count ; i++ ) {
		Z_Free( m_demos.names[i] );
		m_demos.types[i] = 0;
	}

	m_demos.count = 0;
	m_demos.list.curvalue = 0;
}

static char *Demos_Action( void ) {
	char buffer[MAX_OSPATH];
	int i;

	switch( m_demos.types[m_demos.list.curvalue] ) {
	case FFILE_UP:
		buffer[0] = 0;
		i = strlen( m_demos_browse ) - 1;
		for( ; i>=0 ; i-- ) {
			if( m_demos_browse[i] == '/' ) {
				m_demos_browse[i] = 0;
				Q_strncpyz( buffer, m_demos_browse + i + 1, sizeof( buffer ) );
				break;
			}
		}
		Demos_Free();
		Demos_BuildList( m_demos_browse );

		if( !i ) {
			m_demos_browse[0] = '/';
			m_demos_browse[1] = 0;
		}

		// Move cursor to the previous directory
		if( buffer[0] ) {
			for( i=0 ; i<m_demos.count ; i++ ) {
				if( !Q_stricmp( m_demos.names[i], buffer ) ) {
					m_demos.list.curvalue = i;
					break;
				}
			}
		}
		return menu_out_sound;
	case FFILE_FOLDER:
		if( m_demos_browse[strlen( m_demos_browse ) - 1] != '/' ) {
			Q_strcat( m_demos_browse, sizeof( m_demos_browse ), "/" );
		}
		Q_strcat( m_demos_browse, sizeof( m_demos_browse ), m_demos.names[m_demos.list.curvalue] );
		Demos_Free();
		Demos_BuildList( m_demos_browse );
		return menu_in_sound;
	case FFILE_DEMO:
		Com_sprintf( buffer, sizeof( buffer ), "demo \"%s/%s\"\n", m_demos_browse, m_demos.names[m_demos.list.curvalue] );
		Cbuf_AddText( buffer );
		m_demos_selection = m_demos.list.curvalue;
		Demos_Free();
		M_PopMenu();
		return NULL;
	}

	return NULL;
}

int MenuList_HitTest( menulist_s *l, int mx, int my );
extern int m_mouse[2];

static const char *Demos_MenuKey( menuframework_s *self, int key ) {
	int i;

	switch( key ) {
	case K_ESCAPE:
		m_demos_selection = m_demos.list.curvalue;
		Demos_Free();
		M_PopMenu();
		break;
	case K_UPARROW:
	case K_KP_UPARROW:
	case K_MWHEELUP:
		if( m_demos.list.curvalue > 0 ) {
			m_demos.list.curvalue--;
			Demos_LoadInfo( m_demos.list.curvalue );
		}
		return NULL;
	case K_DOWNARROW:
	case K_KP_DOWNARROW:
	case K_MWHEELDOWN:
		if( m_demos.list.curvalue < m_demos.count - 1 ) {
			m_demos.list.curvalue++;
			Demos_LoadInfo( m_demos.list.curvalue );
		}
		return NULL;
	case K_HOME:
	case K_KP_HOME:
		m_demos.list.prestep = 0;
		return NULL;
	case K_END:
	case K_KP_END:
		m_demos.list.prestep = m_demos.count;
		return NULL;
	case K_PGUP:
	case K_KP_PGUP:
		m_demos.list.prestep -= m_demos.list.height / MLIST_SPACING;
		return NULL;
	case K_PGDN:
	case K_KP_PGDN:
		m_demos.list.prestep += m_demos.list.height / MLIST_SPACING;
		return NULL;
	case K_MOUSE1:
		i = MenuList_HitTest( &m_demos.list, m_mouse[0], m_mouse[1] );
		if( i == -1 ) {
			return NULL;
		}
		if( m_demos.list.curvalue == i &&
			Sys_Milliseconds() - m_demos.lastClick < DOUBLE_CLICK_DELAY )
		{
			return Demos_Action();
		}
		m_demos.lastClick = Sys_Milliseconds();
		m_demos.list.curvalue = i;
		Demos_LoadInfo( i );
		return NULL;
	case K_ENTER:
	case K_KP_ENTER:
		return Demos_Action();

	}
	return Default_MenuKey( self, key );
}


static void Demos_MenuInit( void ) {
	char *s;

	memset( &m_demos, 0, sizeof( m_demos ) );

	m_demos.menu.x = 0;
	m_demos.menu.y = 0;

	// Point to a nice location at startup
	if( !m_demos_browse[0] ) {
		s = Cvar_VariableString( "game" );
		if( !*s ) {
			s = BASEDIRNAME;
		}
		Com_sprintf( m_demos_browse, sizeof( m_demos_browse ), "/%s/demos", s );
		
	}

	Demos_BuildList( m_demos_browse );

	m_demos.list.generic.type	= MTYPE_LIST;
	m_demos.list.generic.flags  = QMF_LEFT_JUSTIFY;
	m_demos.list.generic.x		= 10;
	m_demos.list.generic.y		= 70;
	m_demos.list.width			= viddef.width - 20;
	m_demos.list.height			= viddef.height - 120;
	m_demos.list.generic.name	= NULL;
	m_demos.list.generic.callback = NULL;
	m_demos.list.numColoumns = 2;
	m_demos.list.coloumns[0] = (viddef.width - 44 - 262 + 8) / 8;//40;
	m_demos.list.coloumns[1] = 3;

	m_demos.list.itemnames = m_demos.names;
	if( m_demos_selection < m_demos.count ) {
		m_demos.list.curvalue = m_demos_selection;
		m_demos.list.prestep = m_demos_selection;
		Demos_LoadInfo( m_demos_selection );
	}

	m_demos.menu.draw = Demos_MenuDraw;
	m_demos.menu.key = Demos_MenuKey;

	Menu_AddItem( &m_demos.menu, (void *)&m_demos.list );

	Menu_SetStatusBar( &m_demos.menu, NULL );

}

void M_Menu_Demos_f( void ) {
	Demos_MenuInit();
	M_PushMenu( &m_demos.menu );
}

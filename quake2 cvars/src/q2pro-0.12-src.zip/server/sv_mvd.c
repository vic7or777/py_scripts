/*
Copyright (C) 2003 Andrey Nazarov

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

#include "server.h"
#include "../zlib/zlib.h"

typedef struct mvd_s {
	void		*demofile;
	char		filename[MAX_OSPATH];

	qboolean	compressed;
	qboolean	nodelta;
	qboolean	autorecording;

	// multicast and unicast datagrams acclumulated last frame
	sizebuf_t	multicast;
	byte		multicast_buf[MAX_MVD_MSGLEN];

	//
	// delta encoder buffers
	//
	deltaState_t	delta;
} mvd_t;

static mvd_t		mvd;

sizebuf_t	mvd_message;
byte		mvd_message_buffer[MAX_MVD_MSGLEN];

#define MVD_FWRITE(data, len)	(mvd.compressed ? gzwrite( mvd.demofile, data, len ) : fwrite( data, 1, len, mvd.demofile ))

static cvar_t	*mvd_autoRecord;
static cvar_t	*mvd_fileName;

/*
=============
MVD_WriteToFile
=============
*/
static void MVD_WriteToFile( sizebuf_t *msg ) {
	int len;

	if( !msg ) {
		// write demo EOF marker
		len = -1;
		if( MVD_FWRITE( &len, 4 ) != 4 ) {
			Com_Error( ERR_DROP, "MVD_WriteToFile: write error" );
		}
		return;
	}

	len = LittleLong( msg->cursize );
	if( MVD_FWRITE( &len, 4 ) != 4 ) {
		Com_Error( ERR_DROP, "MVD_WriteToFile: write error" );
	}	
	if( MVD_FWRITE( msg->data, msg->cursize ) != msg->cursize ) {
		Com_Error( ERR_DROP, "MVD_WriteToFile: write error" );
	}
}

/*
==================
MVD_PlayerIsActive
==================
*/
static qboolean MVD_PlayerIsActive( int playerNum ) {
	edict_t *ent = EDICT_NUM( playerNum + 1 );

	if( !ent->inuse ) {
		return qfalse;
	}

	if( !ent->client ) {
		return qfalse;
	}

	// HACK: make sure player_state_t is valid
	if( !ent->client->ps.fov ) {
		return qfalse;
	}

	// HACK: if PM_FREEZE, assume intermission is running
	if( ent->client->ps.pmove.pm_type == PM_FREEZE ) {
		return qtrue;
	}

	// if set to invisible, skip
	if( ent->svflags & SVF_NOCLIENT ) {
		return qfalse;
	}

	if( ent->s.modelindex || ent->s.effects || ent->s.sound || ent->s.event ) {
		return qtrue;
	}

	return qfalse;

}

static void MVD_Flush( void ) {
	SZ_Write( &mvd_message, mvd.multicast.data, mvd.multicast.cursize );
	SZ_Clear( &mvd.multicast );

	if( mvd_message.cursize ) {
		MVD_WriteToFile( &mvd_message );
	}

	SZ_Clear( &mvd_message );
}

/*
==================
MVD_RecordFrame

Save everything in the world, including all playerStates,
delta compress the data
==================
*/
void MVD_RecordFrame( void ) {
	edict_t *ent;
	entity_state_t *es;
	player_state_t *ps;
	int i;

	if( !mvd.demofile ) {
		return;
	}

	for( i=0 ; i<maxclients->integer ; i++ ) {
		if( MVD_PlayerIsActive( i ) ) {
			break;
		}
	}

	// don't write any frames on empty server
	if( i == maxclients->integer ) {
		return;
	}

	Delta_BeginFrame( &mvd.delta, &mvd_message );



	for( i=1 ; i<ge->num_edicts ; i++ ) {
		ent = EDICT_NUM( i );

		if( ent->inuse && !(ent->svflags & SVF_NOCLIENT) &&
			(ent->s.modelindex || ent->s.effects || ent->s.sound || ent->s.event) )
		{
			es = Delta_AllocEntity();

			memcpy( es, &ent->s, sizeof( *es ) );
			es->number = i;

/*			// TODO: clear origin, we can extract it from player_state_t
			if( i-1 < maxclients->value ) {
				VectorClear( es->origin );
				VectorClear( es->old_origin );
				VectorClear( es->angles );
			}
*/

		}
	}

	for( i=0 ; i<maxclients->integer ; i++ ) {
		if( MVD_PlayerIsActive( i ) ) {
			ps = Delta_AllocPlayer();

			ent = EDICT_NUM( i + 1 );
			memcpy( ps, &ent->client->ps, sizeof( *ps ) );
			ps->stats[STAT_PLAYERNUM] = i;

			// FIXME: we don't need this data in demo
			VectorClear( ps->pmove.velocity );
			ps->pmove.pm_time = 0;
			ps->pmove.pm_flags = 0;

		}
	}

	SZ_Init( &mvd_message, mvd_message_buffer, sizeof( mvd_message_buffer ) );

	Delta_FinishFrame();

	MVD_Flush();

}

/*
==============
MVD_Multicast
==============
*/
void MVD_Multicast( const void *data, int length ) {
	if( !mvd.demofile ) {
		return;
	}

	SZ_Write( &mvd.multicast, data, length );
}

/*
==============
MVD_Unicast
==============
*/
void MVD_Unicast( int clientNum, const void *data, int length ) {
	if( !mvd.demofile ) {
		return;
	}

	MSG_WriteByte( &mvd.multicast, svc_unicast );
	MSG_WriteByte( &mvd.multicast, clientNum );
	MSG_WriteShort( &mvd.multicast, length );
	SZ_Write( &mvd.multicast, data, length );
}

/*
==============
MVD_StartRecord

Writes level header for MVD
==============
*/
void MVD_StartRecord( void *demofile, const char *filename, qboolean compressed, qboolean nodelta ) {
	entity_state_t *ent;
	int i;
	char *string;

	memset( &mvd, 0, sizeof( mvd ) );

	mvd.demofile = demofile;
	Q_strncpyz( mvd.filename, filename, sizeof( mvd.filename ) );
	mvd.compressed = compressed;
	mvd.nodelta = nodelta;

	// don't use zero frameNum
	mvd.delta.frameNum = 1;
	mvd.delta.localClientNum = maxclients->integer;
	
	// setup a buffer to catch all multicasts
	SZ_Init( &mvd.multicast, mvd.multicast_buf, sizeof( mvd.multicast_buf ) );
	mvd.multicast.allowoverflow = qtrue;

	//
	// write a single giant fake message with all the startup info
	//
	SZ_Init( &mvd_message, mvd_message_buffer, sizeof( mvd_message_buffer ) );

	//
	// serverdata needs to go over for all types of servers
	// to make sure the protocol is right, and to set the gamedir
	//
	MSG_WriteByte( &mvd_message, svc_serverdata );
	MSG_WriteLong( &mvd_message, PROTOCOL_VERSION_Q2PRO );
	MSG_WriteLong( &mvd_message, svs.spawncount );
	MSG_WriteByte( &mvd_message, ATR_MVD );
	MSG_WriteString( &mvd_message, Cvar_VariableString( "gamedir" ) );
	MSG_WriteShort( &mvd_message, -1 );
	// send full levelname
	MSG_WriteString( &mvd_message, SB_GetString( &sv.configStrings, CS_NAME ) );

	for( i=0 ; i<MAX_CONFIGSTRINGS ; i++ ) {
		string = SB_GetString( &sv.configStrings, i );
		if( string[0] ) {
			MSG_WriteByte( &mvd_message, svc_configstring );
			MSG_WriteShort( &mvd_message, i );
			MSG_WriteString( &mvd_message, string );
		}
	}

	for( i=1, ent=sv.baselines+1 ; i<MAX_EDICTS ; i++, ent++ ) {
		if( ent->modelindex || ent->effects || ent->sound || ent->event ) {
			mvd.delta.baselines[i] = *ent;
			MSG_WriteByte( &mvd_message, svc_spawnbaseline );
			MSG_WriteDeltaEntity( NULL, ent, &mvd_message, qtrue, qfalse );
		}
	}

	MSG_WriteByte( &mvd_message, svc_stufftext );
	MSG_WriteString( &mvd_message, "precache\n" );

	// write it to the demo file
	MVD_WriteToFile( &mvd_message );

	// the rest of the demo file will be individual frames
}

/*
==============
MVD_WriteHeader
==============
*/
/*
static void MVD_WriteHeader( void ) {
	if( !mvd.demofile ) {
		return;
	}

	SZ_Init( &mvd_message, mvd_message_buffer, sizeof( mvd_message_buffer ) );
	MSG_WriteByte( &mvd_message, svc_print );
	MSG_WriteByte( &mvd_message, PRINT_HIGH );
	MSG_WriteString( &mvd_message, "This multi-view demo cannot be played back by normal Quake2 client.\n" );
	MSG_WriteByte( &mvd_message, svc_disconnect );

	MVD_WriteToFile( &mvd_message );
}
*/

/*
==============
MVD_StopRecord

Stops server MVD recording.
==============
*/
void MVD_StopRecord( void ) {
	if( !mvd.demofile ) {
		return;
	}

	MVD_Flush();
	MVD_WriteToFile( NULL );

	if( mvd.compressed ) {
		gzclose( mvd.demofile );
	} else {
		fclose( mvd.demofile );
	}
	mvd.demofile = NULL;

	// don't bother with empty demo files
	if( mvd.delta.frameNum < 10 ) {
		Com_Printf( "Removing empty demofile %s\n", mvd.filename );
		if( remove( mvd.filename ) ) {
			Com_Printf( "Failed to remove\n" );
		}
	}
}

/*
==============
MVD_StartAutoRecord
==============
*/
static void MVD_StartAutoRecord( void ) {
	void *demofile;
	const char *name;
	char path[MAX_OSPATH];
	qboolean compressed;

	if( mvd.demofile ) {
		return;
	}

	name = Cmd_MacroExpandString( mvd_fileName->string );
	if( !name ) {
		return;
	}

	Com_sprintf( path, sizeof( path ), "%s/%s", FS_Gamedir(), name );
	FS_CreatePath( path );

	compressed = !Q_stricmp( path + strlen( path ) - 3, ".gz" );
	
	demofile = compressed ? gzopen( path, "wb" ) : fopen( path, "wb" );
	if( !demofile ) {
		Com_Printf( "ERROR: Couldn't open %s\n", path );
		return;
	}

	Com_DPrintf( "Auto recording MVD to %s\n", path );

	MVD_StartRecord( demofile, path, compressed, qfalse );
	mvd.autorecording = qtrue;
}

/*
==============
MVD_ChangeLevel

Restart server MVD recording.
==============
*/
void MVD_ChangeLevel( void ) {
	char filename[MAX_OSPATH];

	if( sv.state != ss_game ) {
		return;
	}

	if( !mvd.demofile ) {
		if( mvd_autoRecord->integer ) {
			MVD_StartAutoRecord();
		}
		return;
	}

	if( mvd_autoRecord->integer && mvd.autorecording ) {
		MVD_StopRecord();
		MVD_StartAutoRecord();
		return;
	}

	MVD_Flush();

	Q_strncpyz( filename, mvd.filename, sizeof( filename ) );
	MVD_StartRecord( mvd.demofile, filename, mvd.compressed, mvd.nodelta );
}

/*
==============
MVD_Record_f

Begins server MVD recording.
Every entity, every playerinfo and every message will be recorded.
==============
*/
static void MVD_Record_f( void ) {
	char	name[MAX_OSPATH];
	FILE	*demofile;
	qboolean nodelta;
	qboolean compressed;
	int i;

	if( Cmd_Argc() < 2 ) {
		Com_Printf( "Usage: %s <filename> [-c] [-n]\n", Cmd_Argv( 0 ) );
		return;
	}

	if( mvd.demofile ) {
		Com_Printf( "Already recording MVD.\n" );
		return;
	}

	if( sv.state != ss_game ) {
		Com_Printf( "Game server is not active.\n" );
		return;
	}

	compressed = qfalse;
	nodelta = qfalse;
	for( i=2 ; i<Cmd_Argc() ; i++ ) {
		if( !strcmp( Cmd_Argv( i ), "-c" ) ) {
			compressed = qtrue;
		} else if( !strcmp( Cmd_Argv( i ), "-n" ) ) {
			nodelta = qtrue;
		}
	}

	//
	// open the demo file
	//
	Com_sprintf( name, sizeof( name ), "%s/demos/%s", FS_Gamedir(), Cmd_Argv( 1 ) );
	if( !strstr( name, ".mvd2" ) ) {
		Q_strcat( name, sizeof( name ), ".mvd2" );
	}
	if( compressed && !strstr( name, ".gz" ) ) {
		Q_strcat( name, sizeof( name ), ".gz" );
	}

	FS_CreatePath( name );
	if( compressed ) {
		demofile = gzopen( name, "wb" );
	} else {
		demofile = fopen( name, "wb" );
	}
	if( !demofile ) {
		Com_Printf( "ERROR: Couldn't open %s\n", name );
		return;
	}


	Com_Printf( "Recording %sMVD to %s\n", nodelta ? "nodela'ed " : "", name );

//	MVD_WriteHeader();
	MVD_StartRecord( demofile, name, compressed, nodelta );

}


/*
==============
MVD_Stop_f

Ends server MVD recording
==============
*/
static void MVD_Stop_f( void ) {
	if( !mvd.demofile ) {
		Com_Printf( "Not recording a MVD.\n" );
		return;
	}

	MVD_StopRecord();

	Com_Printf( "MVD recording completed.\n" );
}


/*
==============
MVD_Init
==============
*/
void MVD_Init( void ) {
	mvd_autoRecord = Cvar_Get( "mvd_autoRecord", "0", CVAR_SERVERINFO );
	mvd_fileName = Cvar_Get( "mvd_fileName", "automvds/$port$/$mapname$-$com_date$-$com_time$.mvd2.gz", 0 );

	Cmd_AddCommand( "mvdrecord", MVD_Record_f );
	Cmd_AddCommand( "mvdstop", MVD_Stop_f );


}




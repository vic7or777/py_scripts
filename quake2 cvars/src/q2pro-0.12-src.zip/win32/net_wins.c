/*
Copyright (C) 1997-2001 Id Software, Inc.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/
// net_wins.c

#include "winsock2.h"
#include "wsipx.h"
#include "../qcommon/qcommon.h"

#define	MAX_LOOPBACK	64

typedef struct {
	byte	data[MAX_MSGLEN];
	int		datalen;
	int		sentTime;
} loopmsg_t;

typedef struct {
	loopmsg_t	msgs[MAX_LOOPBACK];
	int			get;
	int			send;
} loopback_t;

static cvar_t	*net_noudp;
static cvar_t	*net_noipx;
static cvar_t	*net_ip;
static cvar_t	*net_port;
static cvar_t	*net_clientPort;
static cvar_t	*net_lag;

static loopback_t	loopbacks[2];
static int			ip_sockets[2];
static int			ipx_sockets[2];

//=============================================================================

/*
====================
NET_ErrorString
====================
*/
static char *NET_ErrorString( void ) {
	int		code;

	code = WSAGetLastError ();
	switch( code ) {
	case S_OK: return "NO ERROR";
	case WSAEINTR: return "WSAEINTR";
	case WSAEBADF: return "WSAEBADF";
	case WSAEACCES: return "WSAEACCES";
	case WSAEFAULT: return "WSAEFAULT";
	case WSAEINVAL: return "WSAEINVAL";
	case WSAEMFILE: return "WSAEMFILE";
	case WSAEWOULDBLOCK: return "WSAEWOULDBLOCK";
	case WSAEINPROGRESS: return "WSAEINPROGRESS";
	case WSAEALREADY: return "WSAEALREADY";
	case WSAENOTSOCK: return "WSAENOTSOCK";
	case WSAEDESTADDRREQ: return "WSAEDESTADDRREQ";
	case WSAEMSGSIZE: return "WSAEMSGSIZE";
	case WSAEPROTOTYPE: return "WSAEPROTOTYPE";
	case WSAENOPROTOOPT: return "WSAENOPROTOOPT";
	case WSAEPROTONOSUPPORT: return "WSAEPROTONOSUPPORT";
	case WSAESOCKTNOSUPPORT: return "WSAESOCKTNOSUPPORT";
	case WSAEOPNOTSUPP: return "WSAEOPNOTSUPP";
	case WSAEPFNOSUPPORT: return "WSAEPFNOSUPPORT";
	case WSAEAFNOSUPPORT: return "WSAEAFNOSUPPORT";
	case WSAEADDRINUSE: return "WSAEADDRINUSE";
	case WSAEADDRNOTAVAIL: return "WSAEADDRNOTAVAIL";
	case WSAENETDOWN: return "WSAENETDOWN";
	case WSAENETUNREACH: return "WSAENETUNREACH";
	case WSAENETRESET: return "WSAENETRESET";
	case WSAECONNABORTED: return "WSAECONNABORTED";
	case WSAECONNRESET: return "WSAECONNRESET";
	case WSAENOBUFS: return "WSAENOBUFS";
	case WSAEISCONN: return "WSAEISCONN";
	case WSAENOTCONN: return "WSAENOTCONN";
	case WSAESHUTDOWN: return "WSAESHUTDOWN";
	case WSAETOOMANYREFS: return "WSAETOOMANYREFS";
	case WSAETIMEDOUT: return "WSAETIMEDOUT";
	case WSAECONNREFUSED: return "WSAECONNREFUSED";
	case WSAELOOP: return "WSAELOOP";
	case WSAENAMETOOLONG: return "WSAENAMETOOLONG";
	case WSAEHOSTDOWN: return "WSAEHOSTDOWN";
	case WSAEHOSTUNREACH: return "WSAEHOSTUNREACH";
	case WSAENOTEMPTY: return "WSAENOTEMPTY";
	case WSAEPROCLIM: return "WSAEPROCLIM";
	case WSAEUSERS: return "WSAEUSERS";
	case WSAEDQUOT: return "WSAEDQUOT";
	case WSAESTALE: return "WSAESTALE";
	case WSAEREMOTE: return "WSAEREMOTE";
	case WSASYSNOTREADY: return "WSASYSNOTREADY";
	case WSAVERNOTSUPPORTED: return "WSAVERNOTSUPPORTED";
	case WSANOTINITIALISED: return "WSANOTINITIALISED";
	case WSAEDISCON: return "WSAEDISCON";
	case WSAENOMORE: return "WSAENOMORE";
	case WSAECANCELLED: return "WSAECANCELLED";
	case WSAEINVALIDPROCTABLE: return "WSAEINVALIDPROCTABLE";
	case WSAEINVALIDPROVIDER: return "WSAEINVALIDPROVIDER";
	case WSAEPROVIDERFAILEDINIT: return "WSAEPROVIDERFAILEDINIT";
	case WSASYSCALLFAILURE: return "WSASYSCALLFAILURE";
	case WSASERVICE_NOT_FOUND: return "WSASERVICE_NOT_FOUND";
	case WSATYPE_NOT_FOUND: return "WSATYPE_NOT_FOUND";
	case WSA_E_NO_MORE: return "WSA_E_NO_MORE";
	case WSA_E_CANCELLED: return "WSA_E_CANCELLED";
	case WSAEREFUSED: return "WSAEREFUSED";
	case WSAHOST_NOT_FOUND: return "WSAHOST_NOT_FOUND";
	case WSATRY_AGAIN: return "WSATRY_AGAIN";
	case WSANO_RECOVERY: return "WSANO_RECOVERY";
	case WSANO_DATA: return "WSANO_DATA";
	}

	return "UNKNOWN ERROR";
}

/*
===================
NetadrToSockadr
===================
*/
static void NetadrToSockadr( const netadr_t *a, struct sockaddr *s ) {
	memset( s, 0, sizeof( *s ) );

	switch( a->type ) {
	case NA_BROADCAST:
		((struct sockaddr_in *)s)->sin_family = AF_INET;
		((struct sockaddr_in *)s)->sin_port = a->port;
		((struct sockaddr_in *)s)->sin_addr.s_addr = INADDR_BROADCAST;
		break;
	case NA_IP:
		((struct sockaddr_in *)s)->sin_family = AF_INET;
		((struct sockaddr_in *)s)->sin_addr.s_addr = *(int *)&a->ip;
		((struct sockaddr_in *)s)->sin_port = a->port;
		break;
	case NA_IPX:
		((struct sockaddr_ipx *)s)->sa_family = AF_IPX;
		memcpy( ((struct sockaddr_ipx *)s)->sa_netnum, &a->ipx[0], 4 );
		memcpy( ((struct sockaddr_ipx *)s)->sa_nodenum, &a->ipx[4], 6 );
		((struct sockaddr_ipx *)s)->sa_socket = a->port;
		break;
	case NA_BROADCAST_IPX:
		((struct sockaddr_ipx *)s)->sa_family = AF_IPX;
		memset( ((struct sockaddr_ipx *)s)->sa_netnum, 0, 4 );
		memset( ((struct sockaddr_ipx *)s)->sa_nodenum, 0xff, 6 );
		((struct sockaddr_ipx *)s)->sa_socket = a->port;
		break;
	default:
		Com_Error( ERR_FATAL, "NetadrToSockadr: bad address type" );
		break;
	}
}

/*
===================
SockadrToNetadr
===================
*/
static void SockadrToNetadr( const struct sockaddr *s, netadr_t *a ) {
	memset( a, 0, sizeof( *a ) );

	switch( s->sa_family ) {
	case AF_INET:
		a->type = NA_IP;
		*(int *)&a->ip = ((struct sockaddr_in *)s)->sin_addr.s_addr;
		a->port = ((struct sockaddr_in *)s)->sin_port;
		break;
	case AF_IPX:
		a->type = NA_IPX;
		memcpy( &a->ipx[0], ((struct sockaddr_ipx *)s)->sa_netnum, 4 );
		memcpy( &a->ipx[4], ((struct sockaddr_ipx *)s)->sa_nodenum, 6 );
		a->port = ((struct sockaddr_ipx *)s)->sa_socket;
		break;
	default:
		//Com_Error( ERR_FATAL, "SockadrToNetadr: bad address type" );
		break;
	}
}

/*
===================
NET_CompareAdr
===================
*/
qboolean NET_CompareAdr( const netadr_t *a, const netadr_t *b ) {
	if( a->type != b->type ) {
		return qfalse;
	}

	switch( a->type ) {
	case NA_LOOPBACK:
		return qtrue;
	case NA_IP:
	case NA_BROADCAST:
		if( a->ip[0] == b->ip[0] &&
			a->ip[1] == b->ip[1] &&
			a->ip[2] == b->ip[2] &&
			a->ip[3] == b->ip[3] &&
			a->port == b->port )
		{
			return qtrue;
		}
		return qfalse;
	case NA_IPX:
	case NA_BROADCAST_IPX:
		if( !memcmp( a->ipx, b->ipx, sizeof( a->ipx ) ) && a->port == b->port ) {
			return qtrue;
		}
		return qfalse;
	default:
		Com_Error( ERR_FATAL, "NET_CompareAdr: bad address type" );
		break;
	}

	return qfalse;
}

/*
===================
NET_CompareBaseAdr

Compares without the port
===================
*/
qboolean NET_CompareBaseAdr( const netadr_t *a, const netadr_t *b ) {
	if( a->type != b->type ) {
		return qfalse;
	}

	switch( a->type ) {
	case NA_LOOPBACK:
		return qtrue;
	case NA_IP:
	case NA_BROADCAST:
		if( a->ip[0] == b->ip[0] &&
			a->ip[1] == b->ip[1] &&
			a->ip[2] == b->ip[2] &&
			a->ip[3] == b->ip[3] )
		{
			return qtrue;
		}
		return qfalse;
	case NA_IPX:
	case NA_BROADCAST_IPX:
		if( !memcmp( a->ipx, b->ipx, sizeof( a->ipx ) ) ) {
			return qtrue;
		}
		return qfalse;
	default:
		Com_Error( ERR_FATAL, "NET_CompareAdr: bad address type" );
		break;
	}

	return qfalse;
}

/*
===================
NET_AdrToString
===================
*/
char *NET_AdrToString( const netadr_t *a ) {
	static	char	s[64];

	switch( a->type ) {
	case NA_LOOPBACK:
		Com_sprintf( s, sizeof( s ), "loopback" );
		return s;
	case NA_IP:
	case NA_BROADCAST:
		Com_sprintf( s, sizeof( s ), "%i.%i.%i.%i:%i", a->ip[0], a->ip[1], a->ip[2], a->ip[3], ntohs( a->port ) );
		return s;
	case NA_IPX:
	case NA_BROADCAST_IPX:
		Com_sprintf( s, sizeof( s ), "%02x%02x%02x%02x:%02x%02x%02x%02x%02x%02x:%i", a->ipx[0], a->ipx[1], a->ipx[2], a->ipx[3], a->ipx[4], a->ipx[5], a->ipx[6], a->ipx[7], a->ipx[8], a->ipx[9], ntohs( a->port ) );
		return s;
	default:
		Com_Error( ERR_FATAL, "NET_AdrToString: bad address type" );
		break;
	}

	return NULL;
}


/*
=============
NET_StringToAdr

localhost
idnewt
idnewt:28000
192.246.40.70
192.246.40.70:28000
=============
*/
#define DO(src,dest)	\
	copy[0] = s[src];	\
	copy[1] = s[src + 1];	\
	sscanf (copy, "%x", &val);	\
	((struct sockaddr_ipx *)sadr)->dest = val

static qboolean	NET_StringToSockaddr (const char *s, struct sockaddr *sadr)
{
	struct hostent	*h;
	char	*colon;
	int		val;
	char	copy[128];
	
	memset (sadr, 0, sizeof(*sadr));

	if ((strlen(s) >= 23) && (s[8] == ':') && (s[21] == ':'))	// check for an IPX address
	{
		((struct sockaddr_ipx *)sadr)->sa_family = AF_IPX;
		copy[2] = 0;
		DO(0, sa_netnum[0]);
		DO(2, sa_netnum[1]);
		DO(4, sa_netnum[2]);
		DO(6, sa_netnum[3]);
		DO(9, sa_nodenum[0]);
		DO(11, sa_nodenum[1]);
		DO(13, sa_nodenum[2]);
		DO(15, sa_nodenum[3]);
		DO(17, sa_nodenum[4]);
		DO(19, sa_nodenum[5]);
		sscanf (&s[22], "%u", &val);
		((struct sockaddr_ipx *)sadr)->sa_socket = htons((unsigned short)val);
	}
	else
	{
		((struct sockaddr_in *)sadr)->sin_family = AF_INET;
		
		((struct sockaddr_in *)sadr)->sin_port = 0;

		strcpy (copy, s);
		// strip off a trailing :port if present
		for (colon = copy ; *colon ; colon++)
			if (*colon == ':')
			{
				*colon = 0;
				((struct sockaddr_in *)sadr)->sin_port = htons((short)atoi(colon+1));	
			}
		
		if (copy[0] >= '0' && copy[0] <= '9')
		{
			*(int *)&((struct sockaddr_in *)sadr)->sin_addr = inet_addr(copy);
		}
		else
		{
			if (! (h = gethostbyname(copy)) )
				return 0;
			*(int *)&((struct sockaddr_in *)sadr)->sin_addr = *(int *)h->h_addr_list[0];
		}
	}
	
	return qtrue;
}

#undef DO

/*
=============
NET_StringToAdr

localhost
idnewt
idnewt:28000
192.246.40.70
192.246.40.70:28000
=============
*/
qboolean NET_StringToAdr( const char *s, netadr_t *a ) {
	struct sockaddr sadr;
	
	if( !Q_stricmp( s, "localhost" ) ) {
		memset( a, 0, sizeof( *a ) );
		a->type = NA_LOOPBACK;
		return qtrue;
	}

	if( !NET_StringToSockaddr( s, &sadr ) )
		return qfalse;
	
	SockadrToNetadr( &sadr, a );

	return qtrue;
}

/*
=============
NET_IsLocalAddress
=============
*/
qboolean NET_IsLocalAddress( const netadr_t *adr ) {
	if( adr->type == NA_LOOPBACK ) {
		return qtrue;
	}
	return qfalse;
}

/*
=============================================================================

LOOPBACK BUFFERS FOR LOCAL PLAYER

=============================================================================
*/

/*
=============
NET_GetLoopPacket
=============
*/
static qboolean NET_GetLoopPacket( netsrc_t sock, sizebuf_t *buf ) {
	loopback_t	*loop;
	loopmsg_t *loopmsg;

	loop = &loopbacks[sock];

	if( loop->send - loop->get > MAX_LOOPBACK - 1 ) {
		loop->get = loop->send - MAX_LOOPBACK + 1;
	}

	if( loop->get >= loop->send ) {
		return qfalse;
	}

	loopmsg = &loop->msgs[loop->get & (MAX_LOOPBACK-1)];

	if( net_lag->integer < 0 ) {
		Cvar_Set( "net_lag", "0" );
	} else if( net_lag->integer > 300 ) {
		Cvar_Set( "net_lag", "300" );
	}

	if( Sys_Milliseconds() - loopmsg->sentTime < net_lag->integer ) {
		return qfalse;
	}

	loop->get++;

	SZ_Clear( buf );
	SZ_Write( buf, loopmsg->data, loopmsg->datalen );

	return qtrue;

}

/*
=============
NET_SendLoopPacket
=============
*/
static void NET_SendLoopPacket( netsrc_t sock, int length, const void *data ) {
	int		i;
	loopback_t	*loop;

	loop = &loopbacks[sock^1];

	i = loop->send & (MAX_LOOPBACK-1);
	loop->send++;

	memcpy( loop->msgs[i].data, data, length );
	loop->msgs[i].datalen = length;
	loop->msgs[i].sentTime = Sys_Milliseconds();
}

//=============================================================================

/*
=============
NET_GetPacket
=============
*/
qboolean NET_GetPacket( netsrc_t sock, netadr_t *net_from, sizebuf_t *net_message ) {
	int 	ret;
	struct sockaddr from;
	int		fromlen;
	int		net_socket;
	int		protocol;
	int		err;

	if( NET_GetLoopPacket( sock, net_message ) ) {
		memset( net_from, 0, sizeof( *net_from ) );
		net_from->type = NA_LOOPBACK;
		return qtrue;
	}

	for( protocol=0 ; protocol<2 ; protocol++ ) {
		if( protocol == 0 )
			net_socket = ip_sockets[sock];
		else
			net_socket = ipx_sockets[sock];

		if( !net_socket )
			continue;

		fromlen = sizeof( from );
		ret = recvfrom( net_socket, net_message->data, net_message->maxsize,
			0, (struct sockaddr *)&from, &fromlen );

		SockadrToNetadr( &from, net_from );

		if( ret == -1 ) {
			err = WSAGetLastError();

			switch( err ) {
			case WSAEWOULDBLOCK:
			case WSAECONNRESET:
				break;
			case WSAEMSGSIZE:
				Com_Printf( "WARNING: Oversize packet from %s\n", NET_AdrToString( net_from ) );
				break;
			default:
				Com_Printf( "NET_GetPacket ERROR: %s from %s\n", NET_ErrorString(), NET_AdrToString( net_from ) );
				break;
			}

			continue;
		}

		if( ret == net_message->maxsize ) {
			Com_Printf( "WARNING: Oversize packet from %s\n", NET_AdrToString( net_from ) );
			continue;
		}

		net_message->cursize = ret;
		return qtrue;
	}

	return qfalse;
}

//=============================================================================

/*
=============
NET_SendPacket
=============
*/
void NET_SendPacket( netsrc_t sock, int length, const void *data, const netadr_t *to ) {
	int		ret;
	struct sockaddr	addr;
	int		net_socket;

	switch( to->type ) {
	case NA_LOOPBACK:
		NET_SendLoopPacket( sock, length, data );
		return;
	case NA_IP:
	case NA_BROADCAST:
		net_socket = ip_sockets[sock];
		break;
	case NA_IPX:
	case NA_BROADCAST_IPX:
		net_socket = ipx_sockets[sock];
		break;
	default:
		Com_Error( ERR_FATAL, "NET_SendPacket: bad address type" );
		break;
	}	

	if( !net_socket )
		return;

	NetadrToSockadr( to, &addr );

	ret = sendto( net_socket, data, length, 0, &addr, sizeof( addr ) );
	if( ret == -1 ) {
		int err = WSAGetLastError();

		// wouldblock is silent
		if( err == WSAEWOULDBLOCK ) {
			return;
		}

		if( err == WSAECONNRESET ) {
			return;
		}

		// some PPP links dont allow broadcasts
		if( err == WSAEADDRNOTAVAIL && (to->type == NA_BROADCAST || to->type == NA_BROADCAST_IPX) )
			return;

		Com_Printf( "NET_SendPacket ERROR: %s to %s\n", NET_ErrorString(), NET_AdrToString( to ) );
		
	}
}


//=============================================================================

/*
====================
NET_Socket
====================
*/
static int NET_IPSocket( const char *net_interface, int port ) {
	int					newsocket;
	struct sockaddr_in	address;
	qboolean			_true = qtrue;
	int					i = 1;
	int					err;

	if( !net_interface || !net_interface[0] ) {
		net_interface = "localhost";
	}

	Com_Printf( "Opening IP socket: %s:%i\n", net_interface, port );

	if( (newsocket = socket( PF_INET, SOCK_DGRAM, IPPROTO_UDP )) == -1 ) {
		err = WSAGetLastError();
		if( err != WSAEAFNOSUPPORT )
			Com_Printf( "WARNING: UDP_OpenSocket: socket: %s", NET_ErrorString() );
		return 0;
	}

	// make it non-blocking
	if( ioctlsocket( newsocket, FIONBIO, (unsigned long *)&_true ) == -1 ) {
		closesocket( newsocket );
		Com_Printf( "WARNING: UDP_OpenSocket: ioctl FIONBIO: %s\n", NET_ErrorString() );
		return 0;
	}

	// make it broadcast capable
	if( setsockopt( newsocket, SOL_SOCKET, SO_BROADCAST, (char *)&i, sizeof( i ) ) == -1 ) {
		Com_Printf( "WARNING: UDP_OpenSocket: setsockopt SO_BROADCAST: %s\n", NET_ErrorString() );
		closesocket( newsocket );
		return 0;
	}

	if( !Q_stricmp( net_interface, "localhost" ) )
		address.sin_addr.s_addr = INADDR_ANY;
	else
		NET_StringToSockaddr( net_interface, (struct sockaddr *)&address );

	if( port == PORT_ANY )
		address.sin_port = 0;
	else
		address.sin_port = htons( (unsigned short)port );

	address.sin_family = AF_INET;

	if( bind( newsocket, (void *)&address, sizeof( address ) ) == -1 ) {
		Com_Printf( "WARNING: UDP_OpenSocket: bind: %s\n", NET_ErrorString() );
		closesocket( newsocket );
		return 0;
	}

	return newsocket;
}


/*
====================
NET_OpenIP
====================
*/
static void NET_OpenIP( void ) {
	int		port;

	port = Cvar_VariableValue( "ip_hostport" );
	if( !port ) {
		port = Cvar_VariableValue( "hostport" );
		if( !port ) {
			port = net_port->integer;
		}
	}
	ip_sockets[NS_SERVER] = NET_IPSocket( net_ip->string, port );

	if( dedicated && dedicated->integer ) {
		if( !ip_sockets[NS_SERVER] ) {
			Com_Error( ERR_FATAL, "Couldn't allocate dedicated server IP port" );
		}

		// dedicated servers don't need client ports
		return;
	}

	if( !ip_sockets[NS_SERVER] ) {
		Com_Printf( "WARNING: Couldn't allocate server IP port\n" );
	}

	port = Cvar_VariableValue( "ip_clientport" );
	if( !port ) {
		port = net_clientPort->integer;
	}
	ip_sockets[NS_CLIENT] = NET_IPSocket( net_ip->string, port );
	if( !ip_sockets[NS_CLIENT] ) {
		ip_sockets[NS_CLIENT] = NET_IPSocket( net_ip->string, PORT_ANY );
	}

	if( !ip_sockets[NS_CLIENT] ) {
		Com_Printf( "WARNING: Couldn't allocate client IP port\n" );
	}
	
}


/*
====================
IPX_Socket
====================
*/
static int NET_IPXSocket( int port ) {
	int					newsocket;
	struct sockaddr_ipx	address;
	int					_true = 1;
	int					err;

	if( (newsocket = socket( PF_IPX, SOCK_DGRAM, NSPROTO_IPX )) == -1 ) {
		err = WSAGetLastError();
		if( err != WSAEAFNOSUPPORT )
			Com_Printf( "WARNING: IPX_Socket: socket: %s\n", NET_ErrorString() );
		return 0;
	}

	// make it non-blocking
	if( ioctlsocket( newsocket, FIONBIO, &_true ) == -1 ) {
		Com_Printf( "WARNING: IPX_Socket: ioctl FIONBIO: %s\n", NET_ErrorString() );
		closesocket( newsocket );
		return 0;
	}

	// make it broadcast capable
	if( setsockopt( newsocket, SOL_SOCKET, SO_BROADCAST, (char *)&_true, sizeof( _true ) ) == -1 ) {
		Com_Printf( "WARNING: IPX_Socket: setsockopt SO_BROADCAST: %s\n", NET_ErrorString() );
		closesocket( newsocket );
		return 0;
	}

	address.sa_family = AF_IPX;
	memset( address.sa_netnum, 0, 4 );
	memset( address.sa_nodenum, 0, 6 );
	if( port == PORT_ANY )
		address.sa_socket = 0;
	else
		address.sa_socket = htons( (unsigned short)port );

	if( bind( newsocket, (void *)&address, sizeof( address ) ) == -1 ) {
		Com_Printf( "WARNING: IPX_Socket: bind: %s\n", NET_ErrorString() );
		closesocket( newsocket );
		return 0;
	}

	return newsocket;
}


/*
====================
NET_OpenIPX
====================
*/
static void NET_OpenIPX( void ) {
	int		port;

	port = Cvar_VariableValue( "ipx_hostport" );
	if( !port ) {
		port = Cvar_VariableValue( "hostport" );
		if( !port ) {
			port = net_port->integer;
		}
	}
	ipx_sockets[NS_SERVER] = NET_IPXSocket( port );

	if( !ipx_sockets[NS_SERVER] ) {
		Com_DPrintf( "WARNING: Couldn't allocate server IPX port\n" );
	}
	
	// dedicated servers don't need client ports
	if( dedicated && dedicated->integer ) {
		return;
	}

	port = Cvar_VariableValue( "ipx_clientport" );
	if( !port ) {
		port = net_clientPort->integer;
	}
	ipx_sockets[NS_CLIENT] = NET_IPXSocket( port );
	if( !ipx_sockets[NS_CLIENT] ) {
		ipx_sockets[NS_CLIENT] = NET_IPXSocket( PORT_ANY );
	}

	if( !ipx_sockets[NS_CLIENT] ) {
		Com_DPrintf( "WARNING: Couldn't allocate client IPX port\n" );
	}
	
}

// sleeps msec or until net socket is ready
void NET_Sleep(int msec)
{
    struct timeval timeout;
	fd_set	fdset;
	extern cvar_t *dedicated;
	int i;

	if (!dedicated || !dedicated->integer)
		return; // we're not a server, just run full speed

	FD_ZERO(&fdset);
	i = 0;
	if (ip_sockets[NS_SERVER]) {
		FD_SET(ip_sockets[NS_SERVER], &fdset); // network socket
		i = ip_sockets[NS_SERVER];
	}
	if (ipx_sockets[NS_SERVER]) {
		FD_SET(ipx_sockets[NS_SERVER], &fdset); // network socket
		if (ipx_sockets[NS_SERVER] > i)
			i = ipx_sockets[NS_SERVER];
	}
	timeout.tv_sec = msec/1000;
	timeout.tv_usec = (msec%1000)*1000;
	select(i+1, &fdset, NULL, NULL, &timeout);
}

//===================================================================

static void NET_Restart_f( void ) {
	NET_Shutdown();
	NET_Init();
}

/*
====================
NET_Init
====================
*/
void NET_Init( void ) {
	WSADATA		winsockdata;
	int		r;
	char *errmsg;

	r = WSAStartup( MAKEWORD( 1, 1 ), &winsockdata );
	if( r ) {
		errmsg = va( "Winsock initialization failed, returned %i", r );
		if( dedicated && dedicated->integer ) {
			Com_Error( ERR_FATAL, "%s", errmsg );
		} else {
			Com_Printf( "WARNING: %s\n", errmsg );
		}
		return;
	}

	Com_Printf( "Winsock Initialized\n" );

	net_noudp = Cvar_Get( "noudp", "0", CVAR_LATCH );
	net_noipx = Cvar_Get( "noipx", "0", CVAR_LATCH );

	net_ip = Cvar_Get( "ip", "localhost", CVAR_LATCH );
	net_port = Cvar_Get( "port", va( "%i", PORT_SERVER ), CVAR_LATCH );
	net_clientPort = Cvar_Get( "clientport", va( "%i", PORT_CLIENT ), CVAR_LATCH );
	net_lag = Cvar_Get( "net_lag", "0", 0 );

	Cmd_AddCommand( "net_restart", NET_Restart_f );
	
	if( !net_noudp->integer ) {
		NET_OpenIP();
	}
	if( !net_noipx->integer ) {
		NET_OpenIPX();
	}
}


/*
====================
NET_Shutdown
====================
*/
void NET_Shutdown( void ) {
	int i;

	// shut down any existing sockets
	for( i=0 ; i<2 ; i++ ) {
		if( ip_sockets[i] ) {
			closesocket( ip_sockets[i] );
			ip_sockets[i] = 0;
		}
		if( ipx_sockets[i] ) {
			closesocket( ipx_sockets[i] );
			ipx_sockets[i] = 0;
		}
	}

	WSACleanup ();

	Cmd_RemoveCommand( "net_restart" );
}




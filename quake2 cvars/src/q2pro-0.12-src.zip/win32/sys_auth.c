#include <windows.h>

#define SECURITY_MODULE_NAME	"q2pro.dll"
#define SECURITY_ENTRY_POINT	"GetSecurityAPI"

static HMODULE hSecurityModule;
static void *entryPoint;

void Sys_FreeSecurityModule( void ) {
	if( !hSecurityModule ) {
		return;
	}

	FreeLibrary( hSecurityModule );
	hSecurityModule = NULL;
	entryPoint = NULL;
}

void *Sys_LoadSecurityModule( void ) {
	if( hSecurityModule ) {
		return entryPoint;
	}

	hSecurityModule = LoadLibrary( SECURITY_MODULE_NAME );
	if( !hSecurityModule ) {
		return NULL;
	}

	entryPoint = (void *)GetProcAddress( hSecurityModule, SECURITY_ENTRY_POINT );
	if( !entryPoint ) {
		Sys_FreeSecurityModule();
	}

	return entryPoint;

}


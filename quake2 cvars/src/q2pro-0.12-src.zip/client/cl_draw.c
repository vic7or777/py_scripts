/*
Copyright (C) 2003 Andrey Nazarov

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

#include "client.h"

//
// cl_draw.c - draw all 2D elements during active gameplay
//

void SCR_ExecuteLayoutString( char *s );
void SCR_DrawInventory( void );
void SCR_DrawPause( void );
void SCR_DrawNet( void );
void SCR_CheckDrawCenterString( void );

static cvar_t *scr_draw2D;

/*
=================
SCR_AdjustFrom640
=================
*/
void SCR_AdjustFrom640( float *x, float *y, float *w, float *h, qboolean refdef ) {
	float xscale;
	float yscale;
	float xofs;
	float yofs;

	if( refdef ) {
		xscale = cl.refdef.width / 640.0f;
		yscale = cl.refdef.height / 480.0f;
		xofs = cl.refdef.x;
		yofs = cl.refdef.y;
	} else {
		xscale = viddef.width / 640.0f;
		yscale = viddef.height / 480.0f;
		xofs = 0;
		yofs = 0;
	}

	if( x ) {
		*x *= xscale;
		*x += xofs;
	}

	if( y ) {
		*y *= yscale;
		*y += yofs;
	}

	if( w ) {
		*w *= xscale;
	}

	if( h ) {
		*h *= yscale;
	}

}

/*
==============
SCR_DrawRect
==============
*/
void SCR_DrawRect( const vrect_t *rect, int width, int color ) {
	// left
	re.DrawFill( rect->x, rect->y, width, rect->height, color );
	// top
	re.DrawFill( rect->x, rect->y, rect->width, width, color );
	// bottom
	re.DrawFill( rect->x, rect->y + rect->height - width, rect->width, width, color );
	// right
	re.DrawFill( rect->x + rect->width - width, rect->y, width, rect->height, color );
}

/*
==============
SCR_DrawString
==============
*/
void SCR_DrawString( int xpos, int ypos, const char *string, int flags ) {
	int x;
	int y;
	int len;

	len = strlen( string );

	if( flags & DSF_CENTERX ) {
		x = xpos - (len << 2);
	} else if( flags & DSF_RIGHT ) {
		x = xpos - (len << 3);
	} else {
		x = xpos;
	}

	if( flags & DSF_CENTERY ) {
		y = ypos - (1 << 2);
	} else if( flags & DSF_TOP ) {
		y = ypos - (1 << 3);
	} else {
		y = ypos;
	}

	if( flags & DSF_SELECTED ) {
		re.DrawFill( x - 1, y, (len << 3) + 2, 10, 16 );
	}

	if( flags & DSF_HIGHLIGHT ) {
		DrawAltString( x, y, string );
	} else {
		DrawString( x, y, string );
	}

	if( flags & DSF_UNDERLINE ) {
		re.DrawFill( x, y + 9, len << 3, 1, 0xDF );
	}
}

/*
===============================================================================

CONNECTION / LOADING SCREEN

===============================================================================
*/

static char scr_loadingString[MAX_STRING_CHARS];

/*
==============
SCR_LoadingString
==============
*/
void SCR_LoadingString( const char *string ) {
	Q_strncpyz( scr_loadingString, string, sizeof( scr_loadingString ) );
	SCR_UpdateScreen();
}

/*
==============
SCR_DrawLoading
==============
*/
static void SCR_DrawLoading( void ) {
	char *p;
	char *s;
	char buffer[MAX_STRING_CHARS];
	int y = 10;
	int x = viddef.width >> 1;

	if( cls.state < ca_challenging || cls.state > ca_loading ) {
		return;
	}

	re.DrawFill( 0, 0, viddef.width, viddef.height, 0x00 );

	if( cl.mapname[0] ) {
		Com_sprintf( buffer, sizeof( buffer ), "%s", cl.mapname );
		if( re.RegisterPic( buffer ) ) {
			re.DrawStretchPic( 0, 0, viddef.width, viddef.height, buffer );
		}
	}

	Com_sprintf( buffer, sizeof( buffer ), "%s %s", cls.demoplayback ? "Playing back" : "Connecting to", cls.servername );
	SCR_DrawString( x, y, buffer, DSF_HIGHLIGHT|DSF_CENTERX );
	y += 16;

	s = cl.configstrings[CS_NAME];
	if( *s ) {
		SCR_DrawString( x, y, s, DSF_HIGHLIGHT|DSF_CENTERX );
	}
	y += 32;

	switch( cls.state ) {
	case ca_challenging:
		Com_sprintf( buffer, sizeof( buffer ), "Challenging... %i", cls.connectCount );
		SCR_DrawString( x, y, buffer, DSF_CENTERX );
		break;
	case ca_connecting:
		Com_sprintf( buffer, sizeof( buffer ), "Connecting... %i", cls.connectCount );
		SCR_DrawString( x, y, buffer, DSF_CENTERX );
		break;
	case ca_connected:
		switch( cls.loadState ) {
		case LS_RECEIVING_SERVERDATA:
			SCR_DrawString( x, y, "Receiving server data...", DSF_CENTERX );
			break;
		case LS_RECEIVING_CONFIGSTRINGS:
			SCR_DrawString( x, y, "Receiving configstrings...", DSF_CENTERX );
			break;
		case LS_RECEIVING_BASELINES:
			SCR_DrawString( x, y, "Receiving baselines...", DSF_CENTERX );
			break;
		case LS_AWAITING_FRAME:
			SCR_DrawString( x, y, "Spawning...", DSF_CENTERX );
			break;
		default:
			Com_Error( ERR_DROP, "SCR_DrawLoading: bad cls.loadState %i", cls.loadState );
			break;
		}
		break;
	case ca_loading:
		Com_sprintf( buffer, sizeof( buffer ), "Loading... %s", scr_loadingString );
		SCR_DrawString( x, y, buffer, DSF_CENTERX );
		break;
	default:
		Com_Error( ERR_DROP, "SCR_DrawLoading: bad cls.state %i", cls.state );
		break;
	}
	y += 32;

	if( cls.state > ca_connected ) {
		return;
	}
	
	if( cls.messageString[0] ) {
		Q_strncpyz( buffer, cls.messageString, sizeof( buffer ) );

		s = buffer;
		while( *s ) {
			p = strchr( s, '\n' ); 
			if( p ) {
				*p = 0;
			}

			SCR_DrawString( x, y, s, DSF_CENTERX|DSF_HIGHLIGHT );

			if( !p ) {
				break;
			}
			y += 8;
			s = p + 1;
		}
	}

}

/*
===============================================================================

LAGOMETER

===============================================================================
*/

#define LAG_SAMPLES 64
#define LAG_MASK	(LAG_SAMPLES-1)

#define LAG_MAXPING		400

#define LAG_WIDTH	48.0f
#define LAG_HEIGHT	48.0f

typedef struct lagometer_s {
	int ping[LAG_SAMPLES];
	int inSize[LAG_SAMPLES];
	int inTime[LAG_SAMPLES];
	int inPacketNum;

	int outSize[LAG_SAMPLES];
	int outTime[LAG_SAMPLES];
	int outPacketNum;
} lagometer_t;

static cvar_t *scr_drawLagometer;

static lagometer_t		scr_lagometer;

/*
==============
SCR_ClearLagometer
==============
*/
void SCR_ClearLagometer( void ) {
	memset( &scr_lagometer, 0, sizeof( scr_lagometer ) );
}

/*
==============
SCR_AddLagometerPacketInfo
==============
*/
void SCR_AddLagometerPacketInfo( void ) {
	int ping;
	int i;

	if( cls.netchan.dropped ) {
		ping = -1000;
	} else {
		i = cls.netchan.incoming_acknowledged & (CMD_BACKUP-1);
		ping = cls.realtime - cl.cmd_time[i];
		if( ping > 999 ) {
			ping = 999;
		}
		if( cl.delta.surpressCount ) {
			ping = -ping;
		}
	}

	i = scr_lagometer.inPacketNum & LAG_MASK;
	scr_lagometer.inTime[i] = cls.realtime;
	scr_lagometer.ping[i] = ping;
	scr_lagometer.inSize[i] = net_message.cursize;

	scr_lagometer.inPacketNum++;

}

/*
==============
SCR_AddLagometerOutPacketInfo
==============
*/
void SCR_AddLagometerOutPacketInfo( int size ) {
	int i;

	i = scr_lagometer.outPacketNum & LAG_MASK;
	scr_lagometer.outTime[i] = cls.realtime;
	scr_lagometer.outSize[i] = size;

	scr_lagometer.outPacketNum++;
}

/*
==============
SCR_DrawLagometer
==============
*/
static void SCR_DrawLagometer( void ) {
	int x;
	int y;
	int i;
	int j;
	int v;
	int count;
	int ping;
	float size;
	char string[8];
	int color;
	int startTime, endTime;

	if( scr_drawLagometer->integer < 1 ) {
		return;
	}

	if( cls.demoplayback ) {
		return;
	}

	x = viddef.width - LAG_WIDTH;
	y = viddef.height - LAG_HEIGHT;

//	re.DrawFill( x, y, LAG_WIDTH, LAG_HEIGHT, 0x04 );

	ping = 0;
	count = 0;
	for( i=0 ; i<LAG_WIDTH ; i++ ) {
		j = scr_lagometer.inPacketNum - i - 1;
		if( j < 0 ) {
			break;
		}
		j &= LAG_MASK;

		v = scr_lagometer.ping[j];
		if( v == -1000 ) {
			re.DrawFill( x + LAG_WIDTH - i, y, 1, LAG_HEIGHT, 0xF2 );
		} else {
			color = 0xD5;
			if( v < 0 ) {
				v = -v;
				color = 0xDC;
			}
			if( i < LAG_SAMPLES/8 ) {
				ping += v;
				count++;
			}

			v *= LAG_HEIGHT / LAG_MAXPING;
			if( v > LAG_HEIGHT ) {
				v = LAG_HEIGHT;
			}

			re.DrawFill( x + LAG_WIDTH - i, y + LAG_HEIGHT - v, 1, LAG_HEIGHT, color );
		

		}
	}

//
// draw ping
//
	if( scr_drawLagometer->integer < 2 ) {
		return;
	}

	i = count ? ping / count : 0;
	Com_sprintf( string, sizeof( string ), "%i", i );
	SCR_DrawString( viddef.width - LAG_WIDTH/2, viddef.height - LAG_HEIGHT + 22, string, DSF_CENTERX );


//
// draw download speed
//
	if( scr_drawLagometer->integer < 3 ) {
		return;
	}

	i = scr_lagometer.inPacketNum - LAG_SAMPLES/8 + 1;
	if( i < 0 ) {
		i = 0;
	}

	startTime = scr_lagometer.inTime[i & LAG_MASK];
	endTime = scr_lagometer.inTime[(scr_lagometer.inPacketNum - 1) & LAG_MASK];

	size = 0.0f;
	if( startTime != endTime ) {
		for( ; i<scr_lagometer.inPacketNum ; i++ ) {
			size += scr_lagometer.inSize[i & LAG_MASK];
		}

		size /= endTime - startTime;
		size *= 1000.0f / 1024.0f;
	}
	Com_sprintf( string, sizeof( string ), "%1.2f", size );
	SCR_DrawString( viddef.width - LAG_WIDTH/2, viddef.height - LAG_HEIGHT + 12, string, DSF_CENTERX );

//
// draw upload speed
//
	i = scr_lagometer.outPacketNum - LAG_SAMPLES/8 + 1;
	if( i < 0 ) {
		i = 0;
	}

	startTime = scr_lagometer.outTime[i & LAG_MASK];
	endTime = scr_lagometer.outTime[(scr_lagometer.outPacketNum - 1) & LAG_MASK];

	size = 0.0f;
	if( startTime != endTime ) {
		for( ; i<scr_lagometer.outPacketNum ; i++ ) {
			size += scr_lagometer.outSize[i & LAG_MASK];
		}

		size /= endTime - startTime;
		size *= 1000.0f / 1024.0f;
	}
	Com_sprintf( string, sizeof( string ), "%1.2f", size );
	SCR_DrawString( viddef.width - LAG_WIDTH/2, viddef.height - LAG_HEIGHT + 2, string, DSF_CENTERX );
}

/*
===============================================================================

CHAT HUD

===============================================================================
*/

#define MAX_CHAT_LENGTH		128
#define MAX_CHAT_LINES		16
#define CHAT_MASK			(MAX_CHAT_LINES-1)

typedef struct chatMessage_s {
	char	text[MAX_CHAT_LENGTH];
	int		time;
} chatMessage_t;

static cvar_t *scr_drawChatLines;
static cvar_t *scr_drawChatTime;
static cvar_t *scr_drawChatX;
static cvar_t *scr_drawChatY;

static chatMessage_t	scr_chatMsgs[MAX_CHAT_LINES];
static int				scr_numChatMsgs;

/*
==============
SCR_ClearChatHUD_f
==============
*/
void SCR_ClearChatHUD_f( void ) {
	memset( scr_chatMsgs, 0, sizeof( scr_chatMsgs ) );
	scr_numChatMsgs = 0;
}

/*
==============
SCR_AddToChatHUD
==============
*/
void SCR_AddToChatHUD( const char *string ) {
	chatMessage_t *msg;
	char *p;

	msg = &scr_chatMsgs[scr_numChatMsgs & CHAT_MASK];
	scr_numChatMsgs++;

	Q_strncpyz( msg->text, string, sizeof( msg->text ) );
	msg->time = cls.realtime;

	// clamp to single line
	p = strchr( msg->text, '\n' );
	if( p ) {
		*p = 0;
	}
}

/*
==============
SCR_DrawChatHUD
==============
*/
void SCR_DrawChatHUD( void ) {
	int numLines = scr_drawChatLines->integer;
	int time = scr_drawChatTime->value * 1000;
	chatMessage_t *msg;
	float x, y;
	int i;

	// never draw in splitscreen mode
	if( !cl.fullScreenRendering ) {
		return;
	}

	if( numLines < 1 ) {
		return;
	}

	if( time < 0 ) {
		time = 0;
	}

	if( numLines > MAX_CHAT_LINES - 1 ) {
		numLines = MAX_CHAT_LINES - 1;
	}

	x = scr_drawChatX->value;
	y = scr_drawChatY->value;

	SCR_AdjustFrom640( &x, &y, NULL, NULL, qfalse );
	
	for( i=scr_numChatMsgs-1 ; i>=0 && i>scr_numChatMsgs-numLines-1 ; i-- ) {
		msg = &scr_chatMsgs[i & CHAT_MASK];
		if( time && cls.realtime - msg->time > time ) {
			break;
		}

		y -= 8;
		SCR_DrawString( x, y, msg->text, DSF_LEFT|DSF_HIGHLIGHT );
	}
}

/*
===============================================================================

HUD CLOCK

===============================================================================
*/

static cvar_t *scr_drawClock;
static cvar_t *scr_drawClockX;
static cvar_t *scr_drawClockY;
static cvar_t *scr_drawClockFlags;

/*
==============
SCR_DrawClock
==============
*/
static void SCR_DrawClock( void ) {
	char string[16];
	float x;
	float y;
	time_t	clock;
	struct tm	*localTime;

	if( !scr_drawClock->integer ) {
		return;
	}

	time( &clock );
	localTime = localtime( &clock );

	Com_sprintf( string, sizeof( string ), "%i:%02i:%02i", scr_drawClock->integer > 1 ? localTime->tm_hour % 12 : localTime->tm_hour, localTime->tm_min, localTime->tm_sec );

	x = scr_drawClockX->value;
	y = scr_drawClockY->value;

	SCR_AdjustFrom640( &x, &y, NULL, NULL, qfalse );

	SCR_DrawString( x, y, string, scr_drawClockFlags->integer );
}

/*
===============================================================================

FPS COUNTER

===============================================================================
*/

#define FPS_COUNTS	8

static cvar_t *scr_drawFPS;
static cvar_t *scr_drawFPSX;
static cvar_t *scr_drawFPSY;
static cvar_t *scr_drawFPSFlags;

/*
==============
SCR_DrawFPS
==============
*/
static void SCR_DrawFPS( void ) {
	static int frameCount;
	static int frameTimes[FPS_COUNTS];
	static int prevTime;
	int time;
	char string[16];
	float x;
	float y;
	int i;

	if( !scr_drawFPS->integer ) {
		return;
	}

	if( scr_drawFPS->integer == 1 ) {
		time = Sys_Milliseconds();//cls.realtime;
		frameTimes[frameCount & (FPS_COUNTS-1)] = time - prevTime;
		prevTime = time;

		frameCount++;

		time = 0;
		for( i=0 ; i<FPS_COUNTS ; i++ ) {
			time += frameTimes[i];
		}

		if( time ) {
			time = 1000 * FPS_COUNTS / time;
		}
	} else {
		time = 1 / cls.frametime;
	}

	Com_sprintf( string, sizeof( string ), "%ifps", time );
	
	x = scr_drawFPSX->value;
	y = scr_drawFPSY->value;

	SCR_AdjustFrom640( &x, &y, NULL, NULL, qfalse );

	SCR_DrawString( x, y, string, scr_drawFPSFlags->integer );

}

/*
===============================================================================

CROSSHAIR

===============================================================================
*/

static cvar_t *scr_drawCrosshairNames;
static cvar_t *scr_drawCrosshairNamesX;
static cvar_t *scr_drawCrosshairNamesY;
static cvar_t *scr_drawCrosshairNamesFlags;

/*
=================
SCR_ScanForCrosshairEntity
=================
*/
static void SCR_ScanForCrosshairEntity( void ) {
	trace_t		trace, worldtrace;
	vec3_t		end;
	entity_state_t	*ent;
	int			i, x, zd, zu;
	int			headnode;
	int			num;
	vec3_t		bmins, bmaxs;
	vec3_t forward;

	AngleVectors( cl.refdef.viewangles, forward, NULL, NULL );
	VectorMA( cl.refdef.vieworg, 131072, forward, end );

	worldtrace = CM_BoxTrace( cl.refdef.vieworg, end, vec3_origin, vec3_origin, 0, MASK_SOLID );

	for( i=0 ; i<cl.frame.numEntityStates ; i++ ) {
		num = (cl.frame.firstEntityState + i) & (MAX_PARSE_ENTITIES-1);
		ent = &cl.delta.entityStates[num];

		if( ent->number == cl.playernum+1 ) {
			continue;
		}

		if( ent->modelindex != 255 ) {
			continue; // not a player
		}

		if( ent->frame >= 173 || ent->frame <= 0 ) {
			continue; // player is dead
		}

		if( !ent->solid || ent->solid == 31 ) {
			continue; // not solid or bmodel
		}

		x = 8*(ent->solid & 31);
		zd = 8*((ent->solid>>5) & 31);
		zu = 8*((ent->solid>>10) & 63) - 32;

		bmins[0] = bmins[1] = -x;
		bmaxs[0] = bmaxs[1] = x;
		bmins[2] = -zd;
		bmaxs[2] = zu;

		headnode = CM_HeadnodeForBox( bmins, bmaxs );

		trace = CM_TransformedBoxTrace( cl.refdef.vieworg, end,
			vec3_origin, vec3_origin, headnode, MASK_PLAYERSOLID,
				ent->origin, vec3_origin );

		if( trace.allsolid || trace.startsolid || trace.fraction < worldtrace.fraction ) {
			cl.crosshairPlayer = &cl.clientinfo[ent->skinnum & 0xFF];
			cl.crosshairTime = cls.realtime;
			break;
		}
	}
}


/*
=================
SCR_DrawCrosshair
=================
*/
static void SCR_DrawCrosshair( void ) {
	float x;
	float y;

	// only draw for active view
	if( cl.activeView->playerNum != cl.playernum ) {
		return;
	}

	if( crosshair->integer ) {
		if( crosshair->modified ) {
			crosshair->modified = qfalse;
			SCR_TouchPics();
		}

		if( crosshair_pic[0] ) {
			x = cl.refdef.x + ((cl.refdef.width - crosshair_width)>>1);
			y = cl.refdef.y + ((cl.refdef.height - crosshair_height)>>1);

			re.DrawPic( x, y, crosshair_pic );
		}
	}

	if( scr_drawCrosshairNames->value < 0 ) {
		Cvar_Set( "scr_drawCrosshairNames", "0" );
	} else if( scr_drawCrosshairNames->value > 5 ) {
		Cvar_Set( "scr_drawCrosshairNames", "5" );
	}

	if( !scr_drawCrosshairNames->value ) {
		return;
	}

	SCR_ScanForCrosshairEntity();

	if( cls.realtime - cl.crosshairTime > 1000 * scr_drawCrosshairNames->value ) {
		return;
	}

	if( !cl.crosshairPlayer ) {
		return;
	}

	x = scr_drawCrosshairNamesX->value;
	y = scr_drawCrosshairNamesY->value;

	SCR_AdjustFrom640( &x, &y, NULL, NULL, qtrue );

	SCR_DrawString( x, y, cl.crosshairPlayer->name, scr_drawCrosshairNamesFlags->integer );
	
}

/*
================
SCR_DrawDemo
================
*/
static cvar_t *scr_drawDemo;

static void SCR_DrawDemo( void ) {
	char *string;
	int x;
	int y;
	int width;
	vrect_t rect;

	if( !cls.demoplayback ) {
		return;
	}

	if( !scr_drawDemo->integer ) {
		return;
	}

	re.DrawFill( 0, viddef.height - 8, viddef.width, 8, 0 );
	re.DrawFill( 0, viddef.height - 8, viddef.width * cls.demofilePercent, 8, 4 );
	SCR_DrawString( viddef.width / 2, viddef.height - 8, va( "%0.1f%%", cls.demofilePercent * 100.0f ), DSF_CENTERX );

	if( cl.playernum < 0 ) {
		string = "OBSERVING";
	} else {
		string = cl.clientinfo[cl.playernum].name;
		if( !string[0] ) {
			return;
		}
	}

	width = strlen( string ) << 3;
	x = cl.refdef.x + ((cl.refdef.width - width )>>1);
	y = cl.refdef.y + cl.refdef.height / 10;

	rect.x = x - 2;
	rect.y = y - 2;
	rect.width = width + 4;
	rect.height = 8 + 4;

	if( cl.playernum == cl.activeView->playerNum ) {
		SCR_DrawRect( &rect, 1, 0xDF );
	}

	DrawString( x, y, string );
}


/*
=================
SCR_CalcViewRects
=================
*/
void SCR_CalcViewRects( void ) {
	int numViews;
	playerView_t *view;
	int i;
	vrect_t *rects[4];
	vrect_t vrect;

	vrect = scr_vrect;

	// Add space for progress bar
	if( cls.demoplayback && scr_drawDemo->integer ) {
		vrect.height -= 8;
	}

	if( cl.fullScreenRendering ) {
		cl.activeView->rect = vrect;
		return;
	}

	numViews = 0;
	for( i=0, view=cl.views ; i<MAX_MULTI_VIEWS ; i++, view++ ) {
		if( !view->inuse ) {
			continue;
		}

		rects[numViews++] = &view->rect;
	}


	switch( numViews ) {
	case 1:
		cl.fullScreenRendering = qtrue; // FIXME
		rects[0]->x = vrect.x;
		rects[0]->y = vrect.y;
		rects[0]->width = vrect.width;
		rects[0]->height = vrect.height;
		break;
	case 2:
		rects[0]->x = vrect.x;
		rects[0]->y = vrect.y;
		rects[0]->width = vrect.width;
		rects[0]->height = vrect.height/2;

		rects[1]->x = vrect.x;
		rects[1]->y = vrect.y + vrect.height/2;
		rects[1]->width = vrect.width;
		rects[1]->height = vrect.height/2;
		break;
	case 3:
		rects[0]->x = vrect.x;
		rects[0]->y = vrect.y;
		rects[0]->width = vrect.width/2;
		rects[0]->height = vrect.height/2;

		rects[1]->x = vrect.x + vrect.width/2;
		rects[1]->y = vrect.y;
		rects[1]->width = vrect.width/2;
		rects[1]->height = vrect.height/2;

		rects[2]->x = vrect.x;
		rects[2]->y = vrect.y + vrect.height/2;
		rects[2]->width = vrect.width;
		rects[2]->height = vrect.height/2;
		break;
	case 4:
		rects[0]->x = vrect.x;
		rects[0]->y = vrect.y;
		rects[0]->width = vrect.width/2;
		rects[0]->height = vrect.height/2;

		rects[1]->x = vrect.x + vrect.width/2;
		rects[1]->y = vrect.y;
		rects[1]->width = vrect.width/2;
		rects[1]->height = vrect.height/2;

		rects[2]->x = vrect.x;
		rects[2]->y = vrect.y + vrect.height/2;
		rects[2]->width = vrect.width/2;
		rects[2]->height = vrect.height/2;

		rects[3]->x = vrect.x + vrect.width/2;
		rects[3]->y = vrect.y + vrect.height/2;
		rects[3]->width = vrect.width/2;
		rects[3]->height = vrect.height/2;
		break;
	}


}





/*
=================
CL_MouseMove
=================
*/
static int scr_mouse[2];

void CL_MouseMove( int mx, int my ) {
	playerView_t *view;
	int i;

	if( cl.fullScreenRendering ) {
		return;
	}

	scr_mouse[0] += mx;
	scr_mouse[1] += my;

	clamp( scr_mouse[0], 0, viddef.width - 32 );
	clamp( scr_mouse[1], 0, viddef.height - 32 );

	if( !mx && !my )  {
		return;
	}

	for( i=0, view=cl.views ; i<MAX_MULTI_VIEWS ; i++, view++ ) {
		if( !view->inuse ) {
			continue;
		}

		if( scr_mouse[0] > view->rect.x && scr_mouse[0] < view->rect.x + view->rect.width &&
			scr_mouse[1] > view->rect.y && scr_mouse[1] < view->rect.y + view->rect.height )
		{
			cl.activeView = view;
			break;
		}
	}

}

/*
=================
SCR_DrawCursor
=================
*/
static void SCR_DrawCursor( void ) {
	if( cl.fullScreenRendering ) {
		return;
	}

	re.DrawPic( scr_mouse[0], scr_mouse[1], "cursor" );
}

/*
=================
SCR_Draw2D
=================
*/
void SCR_Draw2D( void ) {
	if( cls.state != ca_active ) {
		SCR_DrawLoading();
		return;
	}

	if( !scr_draw2D->integer ) {
		return;
	}

	SCR_DrawLagometer();
	SCR_DrawNet();
	SCR_CheckDrawCenterString();
	SCR_DrawPause();
	SCR_DrawFPS();
	SCR_DrawClock();
	SCR_DrawCursor();
	SCR_DrawChatHUD();
}

/*
=================
SCR_Draw2DPlayerState
=================
*/
static void SCR_Draw2DPlayerState( void ) {
	if( !scr_draw2D->integer ) {
		return;
	}

	SCR_DrawDemo();

	SCR_DrawCrosshair();

	if( cl.playernum == -1 ) {
		return;
	}

	// draw status bar
	SCR_ExecuteLayoutString( cl.configstrings[CS_STATUSBAR] );

	// draw layout
	if( cl.playerstate->stats[STAT_LAYOUTS] & 1 ) {
		SCR_ExecuteLayoutString( cl.layout );
	}

	// draw inventory
	if( cl.playerstate->stats[STAT_LAYOUTS] & 2 ) {
		SCR_DrawInventory();
	}
	
}

/*
=================
SCR_DrawPlayerView
=================
*/
static void SCR_DrawPlayerView( playerView_t *view, float separation ) {
	cl.playernum = view->playerNum;

	if( cl.playernum < 0 ) {
		cl.playerstate = &cl.demoPlayerState;
	} else {
		if( cl.players[cl.playernum].serverFrame != cl.frame.serverFrame ) {
			//Com_Error( ERR_DROP, "SCR_DrawPlayerView: inactive player" );
			re.DrawFill( view->rect.x, view->rect.y, view->rect.width, view->rect.height, 0x00 );
		}

		cl.playerstate = &cl.players[cl.playernum].current;
	}

	cl.refdef.x = view->rect.x;
	cl.refdef.y = view->rect.y;
	cl.refdef.width = view->rect.width;
	cl.refdef.height = view->rect.height;

#if 0
	if( !cl.fullScreenRendering ) {
		cl.refdef.x++;
		cl.refdef.y++;
		cl.refdef.width -= 2;
		cl.refdef.height -= 2;
	}
#endif

	V_RenderView( separation );

	SCR_Draw2DPlayerState();


}

/*
================
SCR_DrawActiveFrame
================
*/
void SCR_DrawActiveFrame( float separation ) {
	int i;
	playerView_t *view;

	if( cls.state != ca_active ) {
		return;
	}

	SCR_CalcViewRects();

	if( con.currentHeight == 1.0f ) {
		return;
	}

	if( cl.fullScreenRendering ) {
		SCR_DrawPlayerView( cl.activeView, separation );
		return;
	}


	for( i=0, view=cl.views ; i<MAX_MULTI_VIEWS ; i++, view++ ) {
		if( !view->inuse ) {
			continue;
		}

		SCR_DrawPlayerView( view, separation );

		if( view == cl.activeView ) {
			SCR_DrawRect( &view->rect, 1, 0xDF );
		}
#if 0
		else {
			SCR_DrawRect( &view->rect, 2, 0x00 );
		}
#endif

		
	}

			
}

/*
================
SCR_InitDraw
================
*/
void SCR_InitDraw( void ) {
	scr_draw2D = Cvar_Get( "scr_draw2D", "1", 0 );

	scr_drawCrosshairNames = Cvar_Get( "scr_drawCrosshairNames", "0", 0 );
	scr_drawCrosshairNamesX = Cvar_Get( "scr_drawCrosshairNamesX", "320", 0 );
	scr_drawCrosshairNamesY = Cvar_Get( "scr_drawCrosshairNamesY", "250", 0 );
	scr_drawCrosshairNamesFlags = Cvar_Get( "scr_drawCrosshairNamesFlags", "16", 0 );

	scr_drawFPS = Cvar_Get( "scr_drawFPS", "0", 0 );
	scr_drawFPSX = Cvar_Get( "scr_drawFPSX", "640", 0 );
	scr_drawFPSY = Cvar_Get( "scr_drawFPSY", "85", 0 );
	scr_drawFPSFlags = Cvar_Get( "scr_drawFPSFlags", "2", 0 );

	scr_drawClock = Cvar_Get( "scr_drawClock", "0", 0 );
	scr_drawClockX = Cvar_Get( "scr_drawClockX", "0", 0 );
	scr_drawClockY = Cvar_Get( "scr_drawClockY", "480", 0 );
	scr_drawClockFlags = Cvar_Get( "scr_drawClockFlags", "72", 0 );

	scr_drawLagometer = Cvar_Get( "scr_drawLagometer", "0", 0 );

	scr_drawChatLines = Cvar_Get( "scr_drawChatLines", "0", 0 );
	scr_drawChatTime = Cvar_Get( "scr_drawChatTime", "0", 0 );
	scr_drawChatX = Cvar_Get( "scr_drawChatX", "0", 0 );
	scr_drawChatY = Cvar_Get( "scr_drawChatY", "420", 0 );

	scr_drawDemo = Cvar_Get( "scr_drawDemo", "1", 0 );

	Cmd_AddCommand( "clearchat", SCR_ClearChatHUD_f );
}


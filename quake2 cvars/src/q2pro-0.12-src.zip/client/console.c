/*
Copyright (C) 1997-2001 Id Software, Inc.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/
// console.c

#include "client.h"

console_t	con;

cvar_t		*con_notifytime;

static cvar_t *con_compSort;
static cvar_t *con_clock;
static cvar_t *con_height;
static cvar_t *con_speed;
static cvar_t *con_chat;



#define CON_HISTORY_SIZE	32
#define CON_HISTORY_MASK	(CON_HISTORY_SIZE-1)

static int con_inputLine;
static int con_historyLine;

static inputField_t con_inputLines[CON_HISTORY_SIZE];

static inputField_t con_chatField;

qboolean chat_team;
		

void DrawString (int x, int y, const char *s)
{
	while (*s && x < viddef.width)
	{
		re.DrawChar (x, y, *s);
		x+=8;
		s++;
	}
}

void DrawAltString (int x, int y, const char *s)
{
	while (*s && x < viddef.width)
	{
		re.DrawChar (x, y, *s ^ 0x80);
		x+=8;
		s++;
	}
}


void Key_ClearTyping (void)
{
//	key_lines[edit_line][1] = 0;	// clear any typing
//	key_linepos = 1;
	IF_Init( &con_inputLines[con_inputLine], con.linewidth );
}

/*
================
Con_ToggleConsole_f
================
*/
void Con_ToggleConsole_f( void ) {
	if( cl.attractLoop == ATR_NORMAL ) {
		Cbuf_AddText( "killserver\n" );
		return;
	}

	Key_ClearTyping();
	Con_ClearNotify_f();

	if( cls.key_dest & KEY_CONSOLE ) {
		cls.key_dest &= ~KEY_CONSOLE;
		Cvar_Set( "paused", "0" );
		return;
	} 

	cls.key_dest |= KEY_CONSOLE;

	cls.key_dest &= ~KEY_MESSAGE; // FIXME: old q2 behaviour

	if( Cvar_VariableValue( "maxclients" ) == 1 && Com_ServerState() )
		Cvar_Set( "paused", "1" );
	
}

void Con_Close( void ) {
	cls.key_dest &= ~KEY_CONSOLE;
	con.currentHeight = 0;

	Key_ClearTyping();
	Con_ClearNotify_f();

	Cvar_Set( "paused", "0" );
}

/*
================
Con_ToggleChat_f
================
*/
void Con_ToggleChat_f (void)
{
/*
	Key_ClearTyping ();

	if (cls.key_dest == key_console)
	{
		if (cls.state == ca_active)
		{
			M_ForceMenuOff ();
			cls.key_dest = key_game;
		}
	}
	else
		cls.key_dest = key_console;
	
	Con_ClearNotify_f ();
*/
}

/*
================
Con_Clear_f
================
*/
void Con_Clear_f (void)
{
	memset (con.text, ' ', CON_TEXTSIZE);
	con.display = con.current;
}

						
/*
================
Con_Dump_f

Save the console contents out to a file
================
*/
void Con_Dump_f (void)
{
	int		l, x;
	char	*line;
	FILE	*f;
	char	buffer[1024];
	char	name[MAX_OSPATH];

	if (Cmd_Argc() != 2)
	{
		Com_Printf ("usage: condump <filename>\n");
		return;
	}

	Com_sprintf (name, sizeof(name), "%s/%s.txt", FS_Gamedir(), Cmd_Argv(1));

	Com_Printf ("Dumped console text to %s.\n", name);
	FS_CreatePath (name);
	f = fopen (name, "w");
	if (!f)
	{
		Com_Printf ("ERROR: couldn't open.\n");
		return;
	}

	// skip empty lines
	for (l = con.current - con.totallines + 1 ; l <= con.current ; l++)
	{
		line = con.text + (l%con.totallines)*con.linewidth;
		for (x=0 ; x<con.linewidth ; x++)
			if (line[x] != ' ')
				break;
		if (x != con.linewidth)
			break;
	}

	// write the remaining lines
	buffer[con.linewidth] = 0;
	for ( ; l <= con.current ; l++)
	{
		line = con.text + (l%con.totallines)*con.linewidth;
		strncpy (buffer, line, con.linewidth);
		for (x=con.linewidth-1 ; x>=0 ; x--)
		{
			if (buffer[x] == ' ')
				buffer[x] = 0;
			else
				break;
		}
		for (x=0; buffer[x]; x++)
			buffer[x] &= 0x7f;

		fprintf (f, "%s\n", buffer);
	}

	fclose (f);
}

						
/*
================
Con_ClearNotify_f
================
*/
void Con_ClearNotify_f (void)
{
	int		i;
	
	for (i=0 ; i<NUM_CON_TIMES ; i++)
		con.times[i] = 0;
}

						
/*
================
Con_MessageMode_f
================
*/
void Con_MessageMode_f (void)
{
	chat_team = qfalse;
	cls.key_dest |= KEY_MESSAGE;
}

/*
================
Con_MessageMode2_f
================
*/
void Con_MessageMode2_f (void)
{
	chat_team = qtrue;
	cls.key_dest |= KEY_MESSAGE;
}

/*
================
Con_CheckResize

If the line width has changed, reformat the buffer.
================
*/
void Con_CheckResize (void)
{
	int		i, j, width, oldwidth, oldtotallines, numlines, numchars;
	char	tbuf[CON_TEXTSIZE];

	width = (viddef.width >> 3) - 2;

	if (width == con.linewidth)
		return;

	if (width < 1)			// video hasn't been initialized yet
	{
		width = 38;
		con.linewidth = width;
		con.totallines = CON_TEXTSIZE / con.linewidth;
		memset (con.text, ' ', CON_TEXTSIZE);
	}
	else
	{
		oldwidth = con.linewidth;
		con.linewidth = width;
		oldtotallines = con.totallines;
		con.totallines = CON_TEXTSIZE / con.linewidth;
		numlines = oldtotallines;

		if (con.totallines < numlines)
			numlines = con.totallines;

		numchars = oldwidth;
	
		if (con.linewidth < numchars)
			numchars = con.linewidth;

		memcpy (tbuf, con.text, CON_TEXTSIZE);
		memset (con.text, ' ', CON_TEXTSIZE);

		for (i=0 ; i<numlines ; i++)
		{
			for (j=0 ; j<numchars ; j++)
			{
				con.text[(con.totallines - 1 - i) * con.linewidth + j] =
						tbuf[((con.current - i + oldtotallines) %
							  oldtotallines) * oldwidth + j];
			}
		}

		Con_ClearNotify_f ();
	}

	con.current = con.totallines - 1;
	con.display = con.current;

	for( i=0 ; i<CON_HISTORY_SIZE ; i++  ) {
		con_inputLines[i].width = con.linewidth;
		//IF_Init( &con_inputLines[i], con.linewidth );
	}

	con_chatField.width = con.linewidth;
	//IF_Init( &con_chatField, con.linewidth );
}


/*
================
Con_Init
================
*/
void Con_Init (void)
{
	con.linewidth = -1;

	Con_CheckResize ();
	
	Com_Printf ("Console initialized.\n");

//
// register our commands
//
	con_notifytime = Cvar_Get ("con_notifytime", "3", 0);
	con_compSort = Cvar_Get( "con_compSort", "0", 0 );
	con_clock = Cvar_Get( "con_clock", "1", 0 );
	con_height = Cvar_Get( "con_height", "0.5", 0 );
	con_speed = Cvar_Get( "scr_conspeed", "3", 0 );
	con_chat = Cvar_Get( "con_chat", "0", 0 );

	Cmd_AddCommand ("toggleconsole", Con_ToggleConsole_f);
	Cmd_AddCommand ("togglechat", Con_ToggleChat_f);
	Cmd_AddCommand ("messagemode", Con_MessageMode_f);
	Cmd_AddCommand ("messagemode2", Con_MessageMode2_f);
	Cmd_AddCommand ("clear", Con_Clear_f);
	Cmd_AddCommand ("clearnotify", Con_ClearNotify_f);
	Cmd_AddCommand ("condump", Con_Dump_f);
	con.initialized = qtrue;
}


/*
===============
Con_Linefeed
===============
*/
void Con_Linefeed (void)
{
	con.x = 0;
	if (con.display == con.current)
		con.display++;
	con.current++;
	memset (&con.text[(con.current%con.totallines)*con.linewidth]
	, ' ', con.linewidth);
}

/*
================
Con_Print

Handles cursor positioning, line wrapping, etc
All console printing must go through this in order to be logged to disk
If no console is visible, the text will appear at the top of the game window
================
*/
void Con_Print (char *txt)
{
	int		y;
	int		c, l;
	static int	cr;
	int		mask;

	if (!con.initialized)
		return;

	if (txt[0] == 1 || txt[0] == 2)
	{
		mask = 128;		// go to colored text
		txt++;
	}
	else
		mask = 0;


	while ( (c = *txt) )
	{
	// count word length
		for (l=0 ; l< con.linewidth ; l++)
			if ( txt[l] <= ' ')
				break;

	// word wrap
		if (l != con.linewidth && (con.x + l > con.linewidth) )
			con.x = 0;

		txt++;

		if (cr)
		{
			con.current--;
			cr = qfalse;
		}

		
		if (!con.x)
		{
			Con_Linefeed ();
		// mark time for transparent overlay
			if (con.current >= 0)
				con.times[con.current % NUM_CON_TIMES] = cls.realtime;
		}

		switch (c)
		{
		case '\n':
			con.x = 0;
			break;

		case '\r':
			con.x = 0;
			cr = 1;
			break;

		default:	// display character and advance
			y = con.current % con.totallines;
			con.text[y*con.linewidth+con.x] = c | mask | con.ormask;
			con.x++;
			if (con.x >= con.linewidth)
				con.x = 0;
			break;
		}
		
	}
}


/*
==============
Con_CenteredPrint
==============
*/
void Con_CenteredPrint (char *text)
{
	int		l;
	char	buffer[1024];

	l = strlen(text);
	l = (con.linewidth-l)/2;
	if (l < 0)
		l = 0;
	memset (buffer, ' ', l);
	strcpy (buffer+l, text);
	strcat (buffer, "\n");
	Con_Print (buffer);
}

/*
==============================================================================

DRAWING

==============================================================================
*/

/*
================
Con_DrawInput

The input line scrolls horizontally if typing goes beyond the right edge
================
*/
void Con_DrawInput( void ) {
	int x, y;

	if( !(cls.key_dest & KEY_CONSOLE) )
		return;		// don't draw anything
	
	x = 8;
	y = con.vislines - 22;

// draw command prompt
	re.DrawChar( x, y, ']' );
	x += 8;

// draw it
	IF_Draw( &con_inputLines[con_inputLine], x, y );
}


/*
================
Con_DrawNotify

Draws the last few lines of output transparently over the game top
================
*/
void Con_DrawNotify (void)
{
	int		x, v;
	char	*text;
	int		i;
	int		time;
	int		skip;

	v = 0;
	for (i= con.current-NUM_CON_TIMES+1 ; i<=con.current ; i++)
	{
		if (i < 0)
			continue;
		time = con.times[i % NUM_CON_TIMES];
		if (time == 0)
			continue;
		time = cls.realtime - time;
		if (time > con_notifytime->value*1000)
			continue;
		text = con.text + (i % con.totallines)*con.linewidth;
		
		for (x = 0 ; x < con.linewidth ; x++)
			re.DrawChar ( (x+1)<<3, v, text[x]);

		v += 8;
	}


	if (cls.key_dest & KEY_MESSAGE)
	{
		if (chat_team)
		{
			DrawString (8, v, "say_team:");
			skip = 11;
		}
		else
		{
			DrawString (8, v, "say:");
			skip = 5;
		}

		IF_Draw( &con_chatField, skip*8, v );

		v += 8;

	}
	
	if (v)
	{
		SCR_AddDirtyPoint (0,0);
		SCR_AddDirtyPoint (viddef.width-1, v);
	}
}

/*
================
Con_DrawConsole

Draws the console with the solid background
================
*/
void Con_DrawSolidConsole( void ) {
	int				i, j, x, y, n;
	int				rows;
	char			*text;
	int				row;
	int				lines;
	char			version[64];
	char			dlbar[1024];
	time_t	clock;
	struct tm	*localTime;

	lines = viddef.height * con.currentHeight;
	if (lines <= 0)
		return;

	if (lines > viddef.height)
		lines = viddef.height;

// draw the background
	//re.DrawStretchPic (0, lines-viddef.height, viddef.width, viddef.height, "conback");
	re.DrawStretchPic (0, 0, viddef.width, lines, "conback");
	re.DrawFill( 0, lines, viddef.width, 2, 0xB4 );
	SCR_AddDirtyPoint (0,0);
	SCR_AddDirtyPoint (viddef.width-1,lines-1);

// draw clock
	if( con_clock->integer ) {
		time( &clock );
		localTime = localtime( &clock );

		Com_sprintf( version, sizeof( version ), "%i:%02i:%02i", localTime->tm_hour, localTime->tm_min, localTime->tm_sec );
		SCR_DrawString( viddef.width, lines - 20, version, DSF_RIGHT|DSF_HIGHLIGHT );
	}

// draw version
	Com_sprintf( version, sizeof( version ), "q2pro v%4.2f", VERSION );
	SCR_DrawString( viddef.width, lines - 12, version, DSF_RIGHT|DSF_HIGHLIGHT );


// draw the text
	con.vislines = lines;

	rows = (lines-22)>>3;		// rows of text to draw

	y = lines - 30;


// draw from the bottom up
	if (con.display != con.current)
	{
	// draw arrows to show the buffer is backscrolled
		for (x=0 ; x<con.linewidth ; x+=4)
			re.DrawChar ( (x+1)<<3, y, '^');
	
		y -= 8;
		rows--;
	}
	
	row = con.display;
	for (i=0 ; i<rows ; i++, y-=8, row--)
	{
		if (row < 0)
			break;
		if (con.current - row >= con.totallines)
			break;		// past scrollback wrap point
			
		text = con.text + (row % con.totallines)*con.linewidth;

		for (x=0 ; x<con.linewidth ; x++)
			re.DrawChar ( (x+1)<<3, y, text[x]);
	}

//ZOID
	// draw the download bar
	// figure out width
	if (cls.download) {
		if ((text = strrchr(cls.downloadname, '/')) != NULL)
			text++;
		else
			text = cls.downloadname;

		x = con.linewidth - ((con.linewidth * 7) / 40);
		y = x - strlen(text) - 8;
		i = con.linewidth/3;
		if (strlen(text) > i) {
			y = x - i - 11;
			strncpy(dlbar, text, i);
			dlbar[i] = 0;
			strcat(dlbar, "...");
		} else
			strcpy(dlbar, text);
		strcat(dlbar, ": ");
		i = strlen(dlbar);
		dlbar[i++] = '\x80';
		// where's the dot go?
		if (cls.downloadpercent == 0)
			n = 0;
		else
			n = y * cls.downloadpercent / 100;
			
		for (j = 0; j < y; j++)
			if (j == n)
				dlbar[i++] = '\x83';
			else
				dlbar[i++] = '\x81';
		dlbar[i++] = '\x82';
		dlbar[i] = 0;

		sprintf(dlbar + strlen(dlbar), " %02d%%", cls.downloadpercent);

		// draw it
		y = con.vislines-12;
		for (i = 0; i < strlen(dlbar); i++)
			re.DrawChar ( (i+1)<<3, y, dlbar[i]);
	}
//ZOID

// draw the input prompt, user text, and cursor if desired
	Con_DrawInput ();
}

//=============================================================================

/*
==================
Con_RunConsole

Scroll it up or down
==================
*/
void Con_RunConsole( void ) {
	if( con_height->value < 0.1 ) {
		Cvar_Set( "con_height", "0.1" );
	} else if( con_height->value > 1 ) {
		Cvar_Set( "con_height", "1" );
	}

// decide on the height of the console
	if( cls.key_dest & KEY_CONSOLE ) {
		con.destHeight = con_height->value;		// half screen
	} else {
		con.destHeight = 0;				// none visible
	}

	if( con.currentHeight > con.destHeight ) {
		con.currentHeight -= con_speed->value * cls.frametime;
		if( con.currentHeight < con.destHeight ) {
			con.currentHeight = con.destHeight;
		}
	} else if( con.currentHeight < con.destHeight ) {
		con.currentHeight += con_speed->value * cls.frametime;
		if( con.currentHeight > con.destHeight ) {
			con.currentHeight = con.destHeight;
		}
	}
}

/*
==================
SCR_DrawConsole
==================
*/
void Con_DrawConsole( void ) {
	Con_CheckResize();

	Con_DrawSolidConsole();
	
	if( cls.state == ca_active && !(cls.key_dest & (KEY_MENU|KEY_CONSOLE)) )
		Con_DrawNotify();	// only draw notify in game
	
}


/*
==============================================================================

			LINE TYPING INTO THE CONSOLE

==============================================================================
*/

//
// COMMAND COMPLETION
//
// Both Q3 and QFusion styles supported
//

#define MAX_MATCHES		2048

static char *	con_matches[MAX_MATCHES];
static char *	con_sortedMatches[MAX_MATCHES];
static int		con_numMatches;
static int		con_numCommands;
static int		con_numCvars;
static int		con_numAliases;

/*
====================
ListCallbackFunc
====================
*/
static qboolean ListCallbackFunc( const char *match, int param ) {
	if( con_numMatches >= MAX_MATCHES ) {
		return qfalse;
	}

	switch( param ) {
	case 1:
		con_numCommands++;
		break;
	case 2:
		con_numCvars++;
		break;
	case 3:
		con_numAliases++;
		break;
	default:
		Com_Error( ERR_FATAL, "Invalid param passed to ListCallbackFunc" );
		break;
	}

	con_matches[con_numMatches++] = CopyString( match );

	return qtrue;

}



/*
====================
Con_CompleteCommand
====================
*/
static void Con_CompleteCommand( void ) {
	inputField_t *inputLine = &con_inputLines[con_inputLine];
	char *text;
	char *partial;
	int i;
	char *first;
	char *last;

	text = inputLine->text;
	if( *text == '\\' || *text == '/' ) {
		text++;
	}
	if( *text == '\0' ) {
		return;
	}

	Cmd_TokenizeString( text, qfalse );
	partial = Cmd_Argv( 0 );

	if( *partial == '\0' ) {
		return;
	}

	con_numMatches = 0;
	con_numCommands = 0;
	con_numCvars = 0;
	con_numAliases = 0;

	Cmd_ListPartial( partial, 1, ListCallbackFunc );
	Cvar_ListPartial( partial, 2, ListCallbackFunc );
	Cmd_ListPartialAliases( partial, 3, ListCallbackFunc );

	if( !con_numMatches ) {
		return; // nothing found
	}

	if( con_numMatches == 1 ) {
		// we have finished completion!
		Com_sprintf( inputLine->text, sizeof( inputLine->text ), "\\%s %s", con_matches[0], Cmd_Args() );
		inputLine->cursorPos = strlen( inputLine->text );
	} else {
		for( i=0 ; i<con_numMatches ; i++ ) {
			con_sortedMatches[i] = con_matches[i];
		}

		qsort( con_sortedMatches, con_numMatches, sizeof( con_sortedMatches[0] ), SortStrcmp );

		inputLine->text[0] = '\\';
		inputLine->cursorPos = 1;

		// copy matching part to the edit line
		first = con_sortedMatches[0];
		last = con_sortedMatches[con_numMatches - 1];
		do {
			inputLine->text[inputLine->cursorPos++] = *first;

			first++;
			last++;
		} while( *first && *first == *last );

		inputLine->text[inputLine->cursorPos] = 0;

		// copy additional arguments, if any
		Q_strcat( inputLine->text, sizeof( inputLine->text ), " " );
		Q_strcat( inputLine->text, sizeof( inputLine->text ), Cmd_Args() );

		if( !con_compSort->value ) {
			// Q3 style, just print as solid list
			Com_Printf( "]\\%s\n", partial );

			for( i=0 ; i<con_numMatches ; i++ ) {
				Com_Printf( "%s\n", con_sortedMatches[i] );
			}
		} else {
			// QFusion style, resort matches and display them separately
			int offset = 0;

			if( con_numCommands ) {
				qsort( con_matches + offset, con_numCommands, sizeof( con_matches[0] ), SortStrcmp );

				Com_Printf( "\n" );
				Com_Printf( "%i possible command%s:\n", con_numCommands, (con_numCommands % 10) != 1 ? "s" : "" );

				for( i=0 ; i<con_numCommands ; i++ ) {
					Com_Printf( "%s\n", con_matches[offset + i] );
				}
				offset += con_numCommands;
			}

			if( con_numCvars ) {
				qsort( con_matches + offset, con_numCvars, sizeof( con_matches[0] ), SortStrcmp );

				Com_Printf( "\n" );
				Com_Printf( "%i possible variable%s:\n", con_numCvars, (con_numCvars % 10) != 1 ? "s" : "" );

				for( i=0 ; i<con_numCvars ; i++ ) {
					Com_Printf( "%s\n", con_matches[offset + i] );
				}
				offset += con_numCvars;
			}

			if( con_numAliases ) {
				qsort( con_matches + offset, con_numAliases, sizeof( con_matches[0] ), SortStrcmp );

				Com_Printf( "\n" );
				Com_Printf( "%i possible alias%s:\n", con_numAliases, (con_numAliases % 10) != 1 ? "es" : "" );

				for( i=0 ; i<con_numAliases ; i++ ) {
					Com_Printf( "%s\n", con_matches[offset + i] );
				}
				offset += con_numAliases;
			}
		}
	}

	// free them
	for( i=0 ; i<con_numMatches ; i++ ) {
		Z_Free( con_matches[i] );
	}

}

/*
====================
Key_Console

Interactive line editing and console scrollback
====================
*/
void Key_Console( int key ) {
	inputField_t *inputLine = &con_inputLines[con_inputLine];

	switch( key ) {
	case K_KP_SLASH:
		key = '/';
		break;
	case K_KP_MINUS:
		key = '-';
		break;
	case K_KP_PLUS:
		key = '+';
		break;
	case K_KP_HOME:
		key = '7';
		break;
	case K_KP_UPARROW:
		key = '8';
		break;
	case K_KP_PGUP:
		key = '9';
		break;
	case K_KP_LEFTARROW:
		key = '4';
		break;
	case K_KP_5:
		key = '5';
		break;
	case K_KP_RIGHTARROW:
		key = '6';
		break;
	case K_KP_END:
		key = '1';
		break;
	case K_KP_DOWNARROW:
		key = '2';
		break;
	case K_KP_PGDN:
		key = '3';
		break;
	case K_KP_INS:
		key = '0';
		break;
	case K_KP_DEL:
		key = '.';
		break;
	}

	if( (toupper( key ) == 'V' && Key_IsDown( K_CTRL )) ||
		 ((key == K_INS || key == K_KP_INS) && Key_IsDown( K_SHIFT )) )
	{
		char *cbd;
		
		if( (cbd = Sys_GetClipboardData()) != 0 ) {
			int i;

			strtok( cbd, "\n\r\b" );

			for( i=0 ; cbd[i] ; i++ ) {
				IF_CharEvent( inputLine, cbd[i] );
			}
			free( cbd );
		}

		return;
	}

	if( key == 'l' && Key_IsDown( K_CTRL ) ) {
		Con_Clear_f();
		return;
	}

	if( key == K_ENTER || key == K_KP_ENTER ) {
		
		// backslash text are commands, else chat
		if( inputLine->text[0] == '\\' || inputLine->text[0] == '/' ) {
			Cbuf_AddText( inputLine->text + 1 );	// skip slash
		} else {
			if( cls.state == ca_active && con_chat->integer ) {
				Cbuf_AddText( va( "cmd say \"%s\"", inputLine->text ) );
			} else {
				Cbuf_AddText( inputLine->text );
			}
		}
		Cbuf_AddText( "\n" );

		Com_Printf( "]%s\n", inputLine->text );

		con_inputLine = (con_inputLine + 1) & CON_HISTORY_MASK;
		con_historyLine = con_inputLine;
		IF_Init( &con_inputLines[con_inputLine], con.linewidth );
	
		if( cls.state == ca_disconnected ) {
			SCR_UpdateScreen ();	// force an update, because the command
									// may take some time
		}
		return;
	}

	if( key == K_TAB ) {
		Con_CompleteCommand ();
		return;
	}

	if( key == K_UPARROW || key == K_KP_UPARROW || (key == 'p' && Key_IsDown( K_CTRL )) ) {
		do {
			con_historyLine = (con_historyLine - 1) & CON_HISTORY_MASK;
		} while( con_historyLine != con_inputLine && !con_inputLines[con_historyLine].text[0] );

		if( con_historyLine == con_inputLine ) {
			con_historyLine = (con_inputLine + 1) & CON_HISTORY_MASK;
			return;
		}

		IF_Init( inputLine, con.linewidth );
		strcpy( inputLine->text, con_inputLines[con_historyLine].text );
		inputLine->cursorPos = strlen( inputLine->text );
		return;
	}

	if( key == K_DOWNARROW || key == K_KP_DOWNARROW || (key == 'n' && Key_IsDown( K_CTRL )) ) {
		if( con_historyLine == con_inputLine ) {
			return;
		}

		do {
			con_historyLine = (con_historyLine + 1) & CON_HISTORY_MASK;
		} while( con_historyLine != con_inputLine && !con_inputLines[con_historyLine].text[0] );

		IF_Init( inputLine, con.linewidth );
		if( con_historyLine != con_inputLine ) {
			strcpy( inputLine->text, con_inputLines[con_historyLine].text );
			inputLine->cursorPos = strlen( inputLine->text );
		}
		return;
	}


	if( key == K_PGUP || key == K_KP_PGUP || key == K_MWHEELUP ) {
		if( Key_IsDown( K_CTRL ) ) {
			con.display -= 6;
		} else {
			con.display -= 2;
		}
		return;
	}

	if( key == K_PGDN || key == K_KP_PGDN || key == K_MWHEELDOWN ) {
		if( Key_IsDown( K_CTRL ) ) {
			con.display += 6;
		} else {
			con.display += 2;
		}
		if( con.display > con.current ) {
			con.display = con.current;
		}
		return;
	}


	if( (key == K_HOME || key == K_KP_HOME) && Key_IsDown( K_CTRL ) ) {
		con.display = con.current - con.totallines + 10;
		return;
	}

	if( (key == K_END || key == K_KP_END) && Key_IsDown( K_CTRL ) ) {
		con.display = con.current;
		return;
	}

	IF_KeyEvent( inputLine, key );

}

/*
====================
Key_Console

Interactive line editing and console scrollback
====================
*/
void Key_Message( int key ) {
	switch( key ) {
	case K_KP_SLASH:
		key = '/';
		break;
	case K_KP_MINUS:
		key = '-';
		break;
	case K_KP_PLUS:
		key = '+';
		break;
	case K_KP_HOME:
		key = '7';
		break;
	case K_KP_UPARROW:
		key = '8';
		break;
	case K_KP_PGUP:
		key = '9';
		break;
	case K_KP_LEFTARROW:
		key = '4';
		break;
	case K_KP_5:
		key = '5';
		break;
	case K_KP_RIGHTARROW:
		key = '6';
		break;
	case K_KP_END:
		key = '1';
		break;
	case K_KP_DOWNARROW:
		key = '2';
		break;
	case K_KP_PGDN:
		key = '3';
		break;
	case K_KP_INS:
		key = '0';
		break;
	case K_KP_DEL:
		key = '.';
		break;
	}

	if( (toupper( key ) == 'V' && Key_IsDown( K_CTRL )) ||
		 ((key == K_INS || key == K_KP_INS) && Key_IsDown( K_SHIFT )) )
	{
		char *cbd;
		
		if( (cbd = Sys_GetClipboardData()) != 0 ) {
			int i;

			strtok( cbd, "\n\r\b" );

			for( i=0 ; cbd[i] ; i++ ) {
				IF_CharEvent( &con_chatField, cbd[i] );
			}
			free( cbd );
		}

		return;
	}

	if( key == 'l' && Key_IsDown( K_CTRL ) ) {
//		Con_Clear_f();
		return;
	}

	if( key == K_ENTER || key == K_KP_ENTER ) {
		Cbuf_AddText( chat_team ? "say_team \"" : "say \"" );
		Cbuf_AddText( con_chatField.text );
		Cbuf_AddText( "\"\n" );
	
		cls.key_dest &= ~KEY_MESSAGE;
		IF_Init( &con_chatField, con.linewidth );
		return;
	}

	if( key == K_ESCAPE ) {
		cls.key_dest &= ~KEY_MESSAGE;
		IF_Init( &con_chatField, con.linewidth );
		return;
	}

	IF_KeyEvent( &con_chatField, key );
}





/*
Copyright (C) 2003 Andrey Nazarov

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

//
// cl_locs.c
//

#include "client.h"

#define MAX_LOCATIONS	512

typedef struct {
	vec3_t	origin;
	char *	name;
} location_t;

static char *		cl_locNames[MAX_LOCATIONS];
static int			cl_numLocNames;

static location_t	cl_locations[MAX_LOCATIONS];
static int			cl_numLocations;

static cvar_t *		loc_draw;
static cvar_t *		loc_trace;
static cvar_t *		loc_dist;

int FS_FileLength( FILE *f );

/*
==============
LOC_AllocName

TODO: add hash table?
==============
*/
static char *LOC_AllocName( const char *name ) {
	int i;
	char *string;

	for( i=0 ; i<cl_numLocNames ; i++ ) {
		if( !strcmp( cl_locNames[i], name ) ) {
			return cl_locNames[i];
		}
	}

	if( cl_numLocNames == MAX_LOCATIONS ) {
		Com_Error( ERR_DROP, "LOC_AllocName: none free" );
	}

	string = CopyString( name );

	cl_locNames[cl_numLocNames++] = string;

	return string;
}

/*
==============
LOC_LoadLocations
==============
*/
void LOC_LoadLocations( void ) {
	char path[MAX_QPATH];
	char *buffer;
	char *s;
	char *p;
	int line;
	location_t *loc;

	if( cl_numLocations ) {
		Com_Error( ERR_DROP, "LOC_LoadLocations: not freed old locs" );
	}

	if( atoi( cl.configstrings[CS_MAXCLIENTS] ) < 2 ) {
		return;
	}

	// load from main directory
	Com_sprintf( path, sizeof( path ), "locs/%s.loc", cl.mapname );

	FS_LoadFile( path, &buffer );
	if( !buffer ) {
		Com_Printf( "WARNING: Couldn't load %s\n", path );
		return;
	}

	s = buffer;
	line = 0;

	while( *s ) {
		p = strchr( s, '\n' );
		if( p ) {
			*p = 0;
		}

		Cmd_TokenizeString( s, qfalse );
		line++;

		if( Cmd_Argc() < 4 ) {
			Com_Printf( "WARNING: line %i uncompleted\n", line );
		} else {
			if( cl_numLocations == MAX_LOCATIONS ) {
				Com_Printf( "WARNING: too many locations!\n" );
				break;
			}
			loc = &cl_locations[cl_numLocations++];
			loc->origin[0] = atof( Cmd_Argv( 0 ) ) * 0.125f;
			loc->origin[1] = atof( Cmd_Argv( 1 ) ) * 0.125f;
			loc->origin[2] = atof( Cmd_Argv( 2 ) ) * 0.125f;
			loc->name = LOC_AllocName( Cmd_ArgsFrom( 3 ) );
		}

		if( !p ) {
			break;
		}

		s = p + 1;
	}

	Com_Printf( "Loaded %i locations from %s\n", cl_numLocations, path );

	FS_FreeFile( buffer );

}

/*
==============
LOC_FreeLocations
==============
*/
void LOC_FreeLocations( void ) {
	int i;

	for( i=0; i<cl_numLocNames ; i++ ) {
		Z_Free( cl_locNames[i] );
	}

	cl_numLocations = 0;
	cl_numLocNames = 0;
}

/*
==============
LOC_FindClosestLocation
==============
*/
static int LOC_FindClosestLocation( vec3_t pos ) {
	int i;
	location_t *loc;
	vec3_t dir;
	float dist;
	float minDist;
	int nearestNum;
	trace_t trace;

	if( !cl_numLocations ) {
		return -1;
	}

	minDist = -1;
	nearestNum = -1;

	for( i=0, loc=cl_locations ; i<cl_numLocations ; i++, loc++ ) {
		VectorSubtract( pos, loc->origin, dir );
		dist = VectorLength( dir );

		if( dist > loc_dist->value ) {
			continue;
		}

		if( loc_trace->integer ) {
			trace = CL_WorldTrace( pos, vec3_origin, vec3_origin, loc->origin );
			if( trace.fraction != 1.0f ) {
				continue;
			}
		}
		
		if( dist < minDist || minDist == -1 ) {
			minDist = dist;
			nearestNum = i;
		}
	}

	return nearestNum;
}

/*
==============
LOC_AddLocationsToScene
==============
*/
void LOC_AddLocationsToScene( void ) {
	int i;
	location_t *loc;
	vec3_t dir;
	float dist;
	entity_t ent;
	int nearestNum;

	if( !loc_draw->integer ) {
		return;
	}

	if( cls.demoplayback ) {
		return;
	}

	memset( &ent, 0, sizeof( ent ) );
	ent.model = re.RegisterModel( "models/items/c_head/tris.md2" );
	ent.skin = re.RegisterSkin( "models/items/c_head/skin.pcx" );

	nearestNum = LOC_FindClosestLocation( cl.playerEntityOrigin );
	if( nearestNum == -1 ) {
		return;
	}

	for( i=0, loc=cl_locations ; i<cl_numLocations ; i++, loc++ ) {
		VectorSubtract( cl.refdef.vieworg, loc->origin, dir );
		dist = VectorLength( dir );

		if( dist > loc_dist->integer ) {
			continue;
		}

		VectorCopy( loc->origin, ent.origin );

		if( i == nearestNum ) {
			ent.origin[2] += 10.0f * sin( cl.time * 0.01f );
			V_AddLight( loc->origin, 200, 1, 1, 1 );
		}

		V_AddEntity( &ent );

	}

}

/*
==============
LOC_Here_m
==============
*/
static qboolean LOC_Here_m( char *buffer, int bufferSize ) {
	int index;

	if( cls.state != ca_active ) {
		return qfalse;
	}

	if( cls.demoplayback ) {
		return qfalse;
	}

	index = LOC_FindClosestLocation( cl.playerEntityOrigin );
	if( index != -1 ) {
		Q_strncpyz( buffer, cl_locations[index].name, bufferSize );
	} else {
		Q_strncpyz( buffer, "unknown", bufferSize );
	}

	return qtrue;
}

/*
==============
LOC_There_m
==============
*/
static qboolean LOC_There_m( char *buffer, int bufferSize ) {
	int index;
	vec3_t pos;
	trace_t trace;

	if( cls.state != ca_active ) {
		return qfalse;
	}

	if( cls.demoplayback ) {
		return qfalse;
	}

	VectorMA( cl.playerEntityOrigin, 8192, cl.v_forward, pos );
	trace = CL_WorldTrace( cl.playerEntityOrigin, vec3_origin, vec3_origin, pos );

	index = LOC_FindClosestLocation( trace.endpos );
	if( index != -1 ) {
		Q_strncpyz( buffer, cl_locations[index].name, bufferSize );
	} else {
		Q_strncpyz( buffer, "unknown", bufferSize );
	}

	return qtrue;
}

/*
==============
LOC_Init
==============
*/
void LOC_Init( void ) {
//	loc_enable = Cvar_Get( "loc_enable", "0", 0 );
	loc_trace = Cvar_Get( "loc_trace", "0", 0 );
	loc_draw = Cvar_Get( "loc_draw", "0", 0 );
	loc_dist = Cvar_Get( "loc_dist", "500", 0 );

	Cmd_AddMacro( "loc_here", LOC_Here_m );
	Cmd_AddMacro( "loc_there", LOC_There_m );

}
	



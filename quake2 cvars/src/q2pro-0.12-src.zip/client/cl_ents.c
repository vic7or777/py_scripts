/*
Copyright (C) 1997-2001 Id Software, Inc.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/
// cl_ents.c -- entity parsing and management

#include "client.h"

extern cvar_t *		fov;
extern cvar_t *		cl_demoLocalFOV;
extern cvar_t *		cl_thirdPerson;
extern cvar_t *		cl_thirdPersonAngle;
extern cvar_t *		cl_thirdPersonRange;
extern cvar_t *		cl_drawBBox;

extern	qhandle_t cl_mod_powerscreen;

//PGM
int	vidref_val;
//PGM

#if 0

static qboolean BBoxIsVisible( const vec3_t bmins, const vec3_t bmaxs, const vec3_t origin, const vec3_t start ) {
	vec3_t absmin, absmax;
	vec3_t bottom[4];
	vec3_t top[4];
	trace_t trace;
	int i;
	
	VectorAdd( bmins, origin, absmin );
	VectorAdd( bmaxs, origin, absmax );

	VectorSet( bottom[0], absmin[0], absmin[1], absmin[2] );
	VectorSet( bottom[1], absmin[0], absmax[1], absmin[2] );
	VectorSet( bottom[2], absmax[0], absmax[1], absmin[2] );
	VectorSet( bottom[3], absmax[0], absmin[1], absmin[2] );

	VectorSet( top[0], absmin[0], absmin[1], absmax[2] );
	VectorSet( top[1], absmin[0], absmax[1], absmax[2] );
	VectorSet( top[2], absmax[0], absmax[1], absmax[2] );
	VectorSet( top[3], absmax[0], absmin[1], absmax[2] );

	for( i=0 ; i<4 ; i++ ) {
		trace = CM_BoxTrace( start, top[i], vec3_origin, vec3_origin, 0, CONTENTS_SOLID );
		if( trace.fraction == 1.0f ) {
			return qtrue;
		}
	}

	for( i=0 ; i<4 ; i++ ) {
		trace = CM_BoxTrace( start, bottom[i], vec3_origin, vec3_origin, 0, CONTENTS_SOLID );
		if( trace.fraction == 1.0f ) {
			return qtrue;
		}
	}
	
	return qfalse;
}

/*
==================
CL_CheckEntity
==================
*/
void CL_CheckEntity( centity_t *ent ) {
	vec3_t origin, start, vel;
	int i;
	int x = 0, zd = 0, zu = 0;
	vec3_t bmins, bmaxs;

	if( cls.demoplayback ) {
		return;
	}

	if( ent->current.solid == 31 ) {
		return;
	}

	if( ent->current.renderfx & (RF_FRAMELERP|RF_BEAM) ) {
		return;
	}

	// FIXME: don't affect entity trails...
//	if( ent->current.effects & (EF_ROCKET|EF_BLASTER|EF_TRACKER|EF_GIB|EF_GRENADE|EF_FLIES|EF_BFG|EF_TRAP|EF_FLAG1|EF_FLAG2|EF_TAGTRAIL|EF_TRACKERTRAIL|EF_TRACKER|EF_GREENGIB|EF_IONRIPPER|EF_PLASMA) ) {
//		return;
//	}

	// Calculate mins/maxs
	if( ent->current.solid ) {
		x = 8*(ent->current.solid & 31);
		zd = 8*((ent->current.solid>>5) & 31);
		zu = 8*((ent->current.solid>>10) & 63) - 32;
	}

	if( x < 32 ) { x = 32; }
	if( zd < 2 ) { zd = 2; }
	if( zu < 32 ) { zu = 32; }

	bmins[0] = bmins[1] = -x;
	bmaxs[0] = bmaxs[1] = x;
	bmins[2] = -zd;
	bmaxs[2] = zu;

	// Extrapolate entity origin
	for( i=0 ; i<3 ; i++ ) {
		origin[i] = ent->current.origin[i] + 0.5f * (ent->current.origin[i] - ent->prev.origin[i]);
	}

	// Test current position
	VectorCopy( cl.refdef.vieworg, start );

	if( BBoxIsVisible( bmins, bmaxs, origin, start ) ) {
		return;
	}

	for( i=0 ; i<3 ; i++ ) {
		vel[i] = cl.players[cl.clientNum].current.pmove.velocity[i] * 0.125f;
	}

	// Extrapolate view origin
	VectorMA( cl.refdef.vieworg, 0.1f, vel, start );

	if( BBoxIsVisible( bmins, bmaxs, origin, start ) ) {
		return;
	}

	ent->visible = qfalse;
}

#endif

/*
=========================================================================

FRAME PARSING

=========================================================================
*/

/*
==================
CL_DeltaEntity

Parses deltas from the given base and adds the resulting entity
to the current frame
==================
*/
void CL_DeltaEntityCallback( deltaFrame_t *frame, entity_state_t *old, entity_state_t *state ) {
	centity_t	*ent;

	ent = &cl_entities[state->number];

	// some data changes will force no lerping
	if (state->modelindex != ent->current.modelindex
		|| state->modelindex2 != ent->current.modelindex2
		|| state->modelindex3 != ent->current.modelindex3
		|| state->modelindex4 != ent->current.modelindex4
		|| abs(state->origin[0] - ent->current.origin[0]) > 512
		|| abs(state->origin[1] - ent->current.origin[1]) > 512
		|| abs(state->origin[2] - ent->current.origin[2]) > 512
		|| state->event == EV_PLAYER_TELEPORT
		|| state->event == EV_OTHER_TELEPORT
		)
	{
		ent->serverframe = -99;
	}

	if (ent->serverframe != frame->serverFrame - 1)
	{	// wasn't in last update, so initialize some things
		ent->trailcount = 1024;		// for diminishing rocket / grenade trails
		// duplicate the current state so lerping doesn't hurt anything
		ent->prev = *state;
		if (state->event == EV_OTHER_TELEPORT)
		{
			VectorCopy (state->origin, ent->prev.origin);
			VectorCopy (state->origin, ent->lerp_origin);
		}
		else
		{
			VectorCopy (state->old_origin, ent->prev.origin);
			VectorCopy (state->old_origin, ent->lerp_origin);
		}
	}
	else
	{	// shuffle the last state to previous
		ent->prev = ent->current;
	}

	ent->serverframe = frame->serverFrame;
	ent->current = *state;

	ent->visible = qtrue;
	//CL_CheckEntity( ent );
}



/*
==================
CL_DeltaPlayer
==================
*/
static void CL_DeltaPlayerCallback( deltaFrame_t *frame, player_state_t *old, player_state_t *state ) {
	cplayer_t		*player;
	int playerNum = state->stats[STAT_PLAYERNUM];

	// KeyGrip may set clientNum to -1
	if( playerNum == CLIENTNUM_NONE ) {
		if( !cls.demoplayback ) {
			Com_Error( ERR_DROP, "CLIENTNUM_NONE expected in demos only" );
		}
		playerNum = CLIENTNUM_FREE;
	}

	player = &cl.players[playerNum];
	player->cent = &cl_entities[playerNum + 1];

	// see if the player entity was teleported this frame
	if( abs( state->pmove.origin[0] - player->current.pmove.origin[0] ) > 256*8
		|| abs( state->pmove.origin[1] - player->current.pmove.origin[1] ) > 256*8
		|| abs( state->pmove.origin[2] - player->current.pmove.origin[2] ) > 256*8 )
	{
		player->serverFrame = -999;		// don't interpolate
	}

	if( player->serverFrame != frame->serverFrame - 1 ) {
		// wasn't in last update, so initialize some things
		player->prev = *state;
	} else {
		// shuffle the last state to previous
		player->prev = player->current;
	}

	player->current = *state;
	player->serverFrame = frame->serverFrame;

	
}

/*
==================
CL_FireEntityEvents

==================
*/
static void CL_FireEntityEvents( void ) {
	entity_state_t		*s1;
	int					pnum, num;

	for( pnum=0 ; pnum<cl.frame.numEntityStates ; pnum++ ) {
		num = (cl.frame.firstEntityState + pnum) & PARSE_ENTITIES_MASK;
		s1 = &cl.delta.entityStates[num];
		if( s1->event ) {
			CL_EntityEvent( s1 );
		}

		// EF_TELEPORTER acts like an event, but is not cleared each frame
		if( s1->effects & EF_TELEPORTER )
			CL_TeleporterParticles( s1 );
	}
}

/*
================
CL_SetActiveState
================
*/
void CL_SetActiveState( void ) {
	cl.time = cl.serverTime; // set time, necessary for demos
	cls.state = ca_active;
	cls.loadState = LS_ACTIVE;
	if( !cls.demoplayback ) {
		player_state_t *ps = &cl.players[cl.clientNum].current; 

		cl.predicted_origin[0] = ps->pmove.origin[0]*0.125;
		cl.predicted_origin[1] = ps->pmove.origin[1]*0.125;
		cl.predicted_origin[2] = ps->pmove.origin[2]*0.125;
		VectorCopy( ps->viewangles, cl.predicted_angles );
	}
	
	SCR_ClearLagometer();
	SCR_ClearChatHUD_f();
	SCR_EndLoadingPlaque ();	// get rid of loading plaque

	if( !cls.demoplayback ) {
		Cmd_ExecTrigger( "#cl_enterLevel" );
	}

	if( cls.demoplayback ) {
		return;
	}

	// Security module does all stuff, if loaded
	if( cls.security ) {
		cls.security->SendCommand( PRINT_ONCONNECT, NULL );
		return;
	}

	if( NET_IsLocalAddress( &cls.serverAddress ) ) {
		return;
	}

	Com_sprintf( cl.replyString, sizeof( cl.replyString ), "q2pro v%4.2f - security module NOT loaded", VERSION );
	cl.replyTime = cls.realtime + 1000 + (rand() & 1) * 1000;
}



/*
================
CL_ParseFrame
================
*/
void CL_ParseFrame( void ) {
	deltaFrame_t		*frame;
	int			ping;

	cl.delta.deltaEntityCallback = CL_DeltaEntityCallback;
	cl.delta.deltaPlayerCallback = CL_DeltaPlayerCallback;
	cl.delta.protocol = cls.serverProtocol;
	cl.delta.localClientNum = cl.clientNum;
	cl.delta.debug = cl_shownet->integer > 2;
	frame = Delta_ParseFrame( &cl.delta, &net_message );
	
	ping = 999;
		
	if( frame->valid ) {
		cl.frame = *frame;
		cl.serverTime = cl.frame.serverFrame * 100;

		// getting a valid frame message ends the connection process
		if( cls.state != ca_active ) {
			CL_SetActiveState();
		}

		if( cl.frame.deltaFrame < 1 ) {
			cls.demowaiting = qfalse; // we can start recording now
		}
	
		// fire entity events
		CL_FireEntityEvents();

		// check if client we are chasing is not longer active
		CL_CheckActiveClients();

		CL_CheckPredictionError();

		ping = Sys_Milliseconds() - cl.cmd_time[cls.netchan.incoming_acknowledged & (CMD_BACKUP-1)];

	}

	if( cl_shownet->integer == 3 ) {
		Com_Printf( "   frame:%i  delta:%i  ping:%i\n", frame->serverFrame, frame->deltaFrame, ping );
	}


}

/*
==========================================================================

INTERPOLATE BETWEEN FRAMES TO GET RENDERING PARMS

==========================================================================
*/

qhandle_t S_RegisterSexedModel (entity_state_t *ent, char *base)
{
	int				n;
	char			*p;
	qhandle_t		mdl;
	char			model[MAX_QPATH];
	char			buffer[MAX_QPATH];

	// determine what model the client is using
	model[0] = 0;
	n = CS_PLAYERSKINS + ent->number - 1;
	if (cl.configstrings[n][0])
	{
		p = strchr(cl.configstrings[n], '\\');
		if (p)
		{
			p += 1;
			strcpy(model, p);
			p = strchr(model, '/');
			if (p)
				*p = 0;
		}
	}
	// if we can't figure it out, they're male
	if (!model[0])
		strcpy(model, "male");

	Com_sprintf (buffer, sizeof(buffer), "players/%s/%s", model, base+1);
	mdl = re.RegisterModel(buffer);
	if (!mdl) {
		// not found, try default weapon model
		Com_sprintf (buffer, sizeof(buffer), "players/%s/weapon.md2", model);
		mdl = re.RegisterModel(buffer);
		if (!mdl) {
			// no, revert to the male model
			Com_sprintf (buffer, sizeof(buffer), "players/%s/%s", "male", base+1);
			mdl = re.RegisterModel(buffer);
			if (!mdl) {
				// last try, default male weapon.md2
				Com_sprintf (buffer, sizeof(buffer), "players/male/weapon.md2");
				mdl = re.RegisterModel(buffer);
			}
		} 
	}

	return mdl;
}

void CL_DrawPlayerBBox( const entity_state_t *state, vec3_t origin ) {
	vec3_t bottom[4];
	vec3_t top[4];
	entity_t ent;
	int x, zd, zu;
	vec3_t bmins, bmaxs;
	vec3_t absmin, absmax;
	int i;

	if( !cl_drawBBox->integer ) {
		return;
	}

	if( state->modelindex != 255 ) {
		return; // not a player
	}

	if( state->frame >= 173 ) {
		return; // player is dead
	}

	if( !state->solid || state->solid == 31 ) {
		return; // not solid or bmodel
	}
	
	x = 8*(state->solid & 31);
	zd = 8*((state->solid>>5) & 31);
	zu = 8*((state->solid>>10) & 63) - 32;

	bmins[0] = bmins[1] = -x;
	bmaxs[0] = bmaxs[1] = x;
	bmins[2] = -zd;
	bmaxs[2] = zu;

	VectorAdd( bmins, origin, absmin );
	VectorAdd( bmaxs, origin, absmax );

	VectorSet( bottom[0], absmin[0], absmin[1], absmin[2] );
	VectorSet( bottom[1], absmin[0], absmax[1], absmin[2] );
	VectorSet( bottom[2], absmax[0], absmax[1], absmin[2] );
	VectorSet( bottom[3], absmax[0], absmin[1], absmin[2] );

	VectorSet( top[0], absmin[0], absmin[1], absmax[2] );
	VectorSet( top[1], absmin[0], absmax[1], absmax[2] );
	VectorSet( top[2], absmax[0], absmax[1], absmax[2] );
	VectorSet( top[3], absmax[0], absmin[1], absmax[2] );

	memset( &ent, 0, sizeof( ent ) );
	ent.flags = RF_TRANSLUCENT|RF_BEAM;
	ent.alpha = 1.0f;
	ent.skinnum = 0xf2f2f0f0;
	ent.frame = 2;

	VectorCopy( bottom[0], ent.origin );
	VectorCopy( bottom[1], ent.oldorigin );
	V_AddEntity( &ent );

	VectorCopy( bottom[1], ent.origin );
	VectorCopy( bottom[2], ent.oldorigin );
	V_AddEntity( &ent );

	VectorCopy( bottom[2], ent.origin );
	VectorCopy( bottom[3], ent.oldorigin );
	V_AddEntity( &ent );

	VectorCopy( bottom[3], ent.origin );
	VectorCopy( bottom[0], ent.oldorigin );
	V_AddEntity( &ent );

	VectorCopy( top[0], ent.origin );
	VectorCopy( top[1], ent.oldorigin );
	V_AddEntity( &ent );

	VectorCopy( top[1], ent.origin );
	VectorCopy( top[2], ent.oldorigin );
	V_AddEntity( &ent );

	VectorCopy( top[2], ent.origin );
	VectorCopy( top[3], ent.oldorigin );
	V_AddEntity( &ent );

	VectorCopy( top[3], ent.origin );
	VectorCopy( top[0], ent.oldorigin );
	V_AddEntity( &ent );

	for( i=0 ; i<4 ; i++ ) {
		VectorCopy( bottom[i], ent.origin );
		VectorCopy( top[i], ent.oldorigin );
		V_AddEntity( &ent );
	}

}

// PMM - used in shell code 
extern int Developer_searchpath (int who);
// pmm
/*
===============
CL_AddPacketEntities

===============
*/
static void CL_AddPacketEntities( void ) {
	entity_t			ent;
	entity_state_t		*s1;
	float				autorotate;
	int					i;
	int					pnum;
	centity_t			*cent;
	int					autoanim;
	clientinfo_t		*ci;
	unsigned int		effects, renderfx;

	// bonus items rotate at a fixed rate
	autorotate = anglemod(cl.time/10);

	// brush models can auto animate their frames
	autoanim = 2*cl.time/1000;

	memset (&ent, 0, sizeof(ent));

	for (pnum = 0 ; pnum<cl.frame.numEntityStates ; pnum++)
	{
		s1 = &cl.delta.entityStates[(cl.frame.firstEntityState+pnum)&(MAX_PARSE_ENTITIES-1)];

		cent = &cl_entities[s1->number];

		if( !cent->visible ) {
			continue;
		}

		effects = s1->effects;
		renderfx = s1->renderfx;

			// set frame
		if (effects & EF_ANIM01)
			ent.frame = autoanim & 1;
		else if (effects & EF_ANIM23)
			ent.frame = 2 + (autoanim & 1);
		else if (effects & EF_ANIM_ALL)
			ent.frame = autoanim;
		else if (effects & EF_ANIM_ALLFAST)
			ent.frame = cl.time / 100;
		else
			ent.frame = s1->frame;

		// quad and pent can do different things on client
		if (effects & EF_PENT)
		{
			effects &= ~EF_PENT;
			effects |= EF_COLOR_SHELL;
			renderfx |= RF_SHELL_RED;
		}

		if (effects & EF_QUAD)
		{
			effects &= ~EF_QUAD;
			effects |= EF_COLOR_SHELL;
			renderfx |= RF_SHELL_BLUE;
		}
//======
// PMM
		if (effects & EF_DOUBLE)
		{
			effects &= ~EF_DOUBLE;
			effects |= EF_COLOR_SHELL;
			renderfx |= RF_SHELL_DOUBLE;
		}

		if (effects & EF_HALF_DAMAGE)
		{
			effects &= ~EF_HALF_DAMAGE;
			effects |= EF_COLOR_SHELL;
			renderfx |= RF_SHELL_HALF_DAM;
		}
// pmm
//======
		ent.oldframe = cent->prev.frame;
		ent.backlerp = 1.0 - cl.lerpfrac;

		if (renderfx & (RF_FRAMELERP|RF_BEAM))
		{	// step origin discretely, because the frames
			// do the animation properly
			VectorCopy (cent->current.origin, ent.origin);
			VectorCopy (cent->current.old_origin, ent.oldorigin);
		}
		else
		{	// interpolate origin
			for (i=0 ; i<3 ; i++)
			{
				ent.origin[i] = ent.oldorigin[i] = cent->prev.origin[i] + cl.lerpfrac * 
					(cent->current.origin[i] - cent->prev.origin[i]);
			}
		}

		// create a new entity
	
		// tweak the color of beams
		if ( renderfx & RF_BEAM )
		{	// the four beam colors are encoded in 32 bits of skinnum (hack)
			ent.alpha = 0.30;
			ent.skinnum = (s1->skinnum >> ((rand() % 4)*8)) & 0xff;
			ent.model = NULL;
		}
		else
		{
			// set skin
			if (s1->modelindex == 255)
			{	// use custom player skin
				ent.skinnum = 0;
				ci = &cl.clientinfo[s1->skinnum & 0xff];
				ent.skin = ci->skin;
				ent.model = ci->model;
				if (!ent.skin || !ent.model)
				{
					ent.skin = cl.baseclientinfo.skin;
					ent.model = cl.baseclientinfo.model;
				}

//============
//PGM
				if (renderfx & RF_USE_DISGUISE)
				{
					if(!strncmp((char *)ent.skin, "players/male", 12))
					{
						ent.skin = re.RegisterSkin ("players/male/disguise.pcx");
						ent.model = re.RegisterModel ("players/male/tris.md2");
					}
					else if(!strncmp((char *)ent.skin, "players/female", 14))
					{
						ent.skin = re.RegisterSkin ("players/female/disguise.pcx");
						ent.model = re.RegisterModel ("players/female/tris.md2");
					}
					else if(!strncmp((char *)ent.skin, "players/cyborg", 14))
					{
						ent.skin = re.RegisterSkin ("players/cyborg/disguise.pcx");
						ent.model = re.RegisterModel ("players/cyborg/tris.md2");
					}
				}
//PGM
//============
			}
			else
			{
				ent.skinnum = s1->skinnum;
				ent.skin = NULL;
				ent.model = cl.model_draw[s1->modelindex];
			}
		}

		// only used for black hole model right now, FIXME: do better
		if (renderfx == RF_TRANSLUCENT)
			ent.alpha = 0.70;

		// render effects (fullbright, translucent, etc)
		if ((effects & EF_COLOR_SHELL))
			ent.flags = 0;	// renderfx go on color shell entity
		else
			ent.flags = renderfx;

		// calculate angles
		if (effects & EF_ROTATE)
		{	// some bonus items auto-rotate
			ent.angles[0] = 0;
			ent.angles[1] = autorotate;
			ent.angles[2] = 0;
		}
		// RAFAEL
		else if (effects & EF_SPINNINGLIGHTS)
		{
			ent.angles[0] = 0;
			ent.angles[1] = anglemod(cl.time/2) + s1->angles[1];
			ent.angles[2] = 180;
			{
				vec3_t forward;
				vec3_t start;

				AngleVectors (ent.angles, forward, NULL, NULL);
				VectorMA (ent.origin, 64, forward, start);
				V_AddLight (start, 100, 1, 0, 0);
			}
		}
		else
		{	// interpolate angles
			float	a1, a2;

			for (i=0 ; i<3 ; i++)
			{
				a1 = cent->current.angles[i];
				a2 = cent->prev.angles[i];
				ent.angles[i] = LerpAngle (a2, a1, cl.lerpfrac);
			}
		}

		if( s1->number == cl.playernum + 1 ) {
			VectorCopy( cl.playerEntityOrigin, ent.origin );
			VectorCopy( cl.playerEntityOrigin, ent.oldorigin );
			VectorCopy( cl.playerEntityAngles, ent.angles );

			if( ent.angles[PITCH] > 180 ) {
				ent.angles[PITCH] -= 360;
			}

			ent.angles[PITCH] = ent.angles[PITCH] / 3;

			if( !cl.thirdPersonView ) {
				ent.flags |= RF_VIEWERMODEL;	// only draw from mirrors
				// FIXME: still pass to refresh

				if (effects & EF_FLAG1)
					V_AddLight (ent.origin, 225, 1.0, 0.1, 0.1);
				else if (effects & EF_FLAG2)
					V_AddLight (ent.origin, 225, 0.1, 0.1, 1.0);
				else if (effects & EF_TAGTRAIL)						//PGM
					V_AddLight (ent.origin, 225, 1.0, 1.0, 0.0);	//PGM
				else if (effects & EF_TRACKERTRAIL)					//PGM
					V_AddLight (ent.origin, 225, -1.0, -1.0, -1.0);	//PGM

				continue;
			}

		}

		CL_DrawPlayerBBox( s1, ent.origin );

		// if set to invisible, skip
		if (!s1->modelindex)
			continue;

		if (effects & EF_BFG)
		{
			ent.flags |= RF_TRANSLUCENT;
			ent.alpha = 0.30;
		}

		// RAFAEL
		if (effects & EF_PLASMA)
		{
			ent.flags |= RF_TRANSLUCENT;
			ent.alpha = 0.6;
		}

		if (effects & EF_SPHERETRANS)
		{
			ent.flags |= RF_TRANSLUCENT;
			// PMM - *sigh*  yet more EF overloading
			if (effects & EF_TRACKERTRAIL)
				ent.alpha = 0.6;
			else
				ent.alpha = 0.3;
		}
//pmm

		// add to refresh list
		V_AddEntity (&ent);


		// color shells generate a seperate entity for the main model
		if (effects & EF_COLOR_SHELL)
		{
			// PMM - at this point, all of the shells have been handled
			// if we're in the rogue pack, set up the custom mixing, otherwise just
			// keep going
//			if(Developer_searchpath(2) == 2)
//			{
				// all of the solo colors are fine.  we need to catch any of the combinations that look bad
				// (double & half) and turn them into the appropriate color, and make double/quad something special
				if (renderfx & RF_SHELL_HALF_DAM)
				{
					if(Developer_searchpath(2) == 2)
					{
						// ditch the half damage shell if any of red, blue, or double are on
						if (renderfx & (RF_SHELL_RED|RF_SHELL_BLUE|RF_SHELL_DOUBLE))
							renderfx &= ~RF_SHELL_HALF_DAM;
					}
				}

				if (renderfx & RF_SHELL_DOUBLE)
				{
					if(Developer_searchpath(2) == 2)
					{
						// lose the yellow shell if we have a red, blue, or green shell
						if (renderfx & (RF_SHELL_RED|RF_SHELL_BLUE|RF_SHELL_GREEN))
							renderfx &= ~RF_SHELL_DOUBLE;
						// if we have a red shell, turn it to purple by adding blue
						if (renderfx & RF_SHELL_RED)
							renderfx |= RF_SHELL_BLUE;
						// if we have a blue shell (and not a red shell), turn it to cyan by adding green
						else if (renderfx & RF_SHELL_BLUE)
							// go to green if it's on already, otherwise do cyan (flash green)
							if (renderfx & RF_SHELL_GREEN)
								renderfx &= ~RF_SHELL_BLUE;
							else
								renderfx |= RF_SHELL_GREEN;
					}
				}
//			}
			// pmm
			ent.flags = renderfx | RF_TRANSLUCENT;
			ent.alpha = 0.30;
			V_AddEntity (&ent);
		}

		ent.skin = NULL;		// never use a custom skin on others
		ent.skinnum = 0;
		ent.flags = 0;
		ent.alpha = 0;

		// duplicate for linked models
		if (s1->modelindex2)
		{
			if (s1->modelindex2 == 255)
			{	// custom weapon
				ci = &cl.clientinfo[s1->skinnum & 0xff];
				i = (s1->skinnum >> 8); // 0 is default weapon model
				if (!cl_vwep->integer || i > MAX_CLIENTWEAPONMODELS - 1)
					i = 0;
				ent.model = ci->weaponmodel[i];
				if (!ent.model) {
					if (i != 0)
						ent.model = ci->weaponmodel[0];
					if (!ent.model)
						ent.model = cl.baseclientinfo.weaponmodel[0];
				}
			}
			else
				ent.model = cl.model_draw[s1->modelindex2];

			// PMM - check for the defender sphere shell .. make it translucent
			// replaces the previous version which used the high bit on modelindex2 to determine transparency
			if (!Q_strcasecmp (cl.configstrings[CS_MODELS+(s1->modelindex2)], "models/items/shell/tris.md2"))
			{
				ent.alpha = 0.32;
				ent.flags = RF_TRANSLUCENT;
			}
			// pmm

			V_AddEntity (&ent);

			//PGM - make sure these get reset.
			ent.flags = 0;
			ent.alpha = 0;
			//PGM
		}
		if (s1->modelindex3)
		{
			ent.model = cl.model_draw[s1->modelindex3];
			V_AddEntity (&ent);
		}
		if (s1->modelindex4)
		{
			ent.model = cl.model_draw[s1->modelindex4];
			V_AddEntity (&ent);
		}

		if ( effects & EF_POWERSCREEN )
		{
			ent.model = cl_mod_powerscreen;
			ent.oldframe = 0;
			ent.frame = 0;
			ent.flags |= (RF_TRANSLUCENT | RF_SHELL_GREEN);
			ent.alpha = 0.30;
			V_AddEntity (&ent);
		}

		// add automatic particle trails
		if ( (effects&~EF_ROTATE) )
		{
			if (effects & EF_ROCKET)
			{
				CL_RocketTrail (cent->lerp_origin, ent.origin, cent);
				V_AddLight (ent.origin, 200, 1, 1, 0);
			}
			// PGM - Do not reorder EF_BLASTER and EF_HYPERBLASTER. 
			// EF_BLASTER | EF_TRACKER is a special case for EF_BLASTER2... Cheese!
			else if (effects & EF_BLASTER)
			{
//				CL_BlasterTrail (cent->lerp_origin, ent.origin);
//PGM
				if (effects & EF_TRACKER)	// lame... problematic?
				{
					CL_BlasterTrail2 (cent->lerp_origin, ent.origin);
					V_AddLight (ent.origin, 200, 0, 1, 0);		
				}
				else
				{
					CL_BlasterTrail (cent->lerp_origin, ent.origin);
					V_AddLight (ent.origin, 200, 1, 1, 0);
				}
//PGM
			}
			else if (effects & EF_HYPERBLASTER)
			{
				if (effects & EF_TRACKER)						// PGM	overloaded for blaster2.
					V_AddLight (ent.origin, 200, 0, 1, 0);		// PGM
				else											// PGM
					V_AddLight (ent.origin, 200, 1, 1, 0);
			}
			else if (effects & EF_GIB)
			{
				CL_DiminishingTrail (cent->lerp_origin, ent.origin, cent, effects);
			}
			else if (effects & EF_GRENADE)
			{
				CL_DiminishingTrail (cent->lerp_origin, ent.origin, cent, effects);
			}
			else if (effects & EF_FLIES)
			{
				CL_FlyEffect (cent, ent.origin);
			}
			else if (effects & EF_BFG)
			{
				static int bfg_lightramp[6] = {300, 400, 600, 300, 150, 75};

				if (effects & EF_ANIM_ALLFAST)
				{
					CL_BfgParticles (&ent);
					i = 200;
				}
				else
				{
					i = bfg_lightramp[s1->frame];
				}
				V_AddLight (ent.origin, i, 0, 1, 0);
			}
			// RAFAEL
			else if (effects & EF_TRAP)
			{
				ent.origin[2] += 32;
				CL_TrapParticles (&ent);
				i = (rand()%100) + 100;
				V_AddLight (ent.origin, i, 1, 0.8, 0.1);
			}
			else if (effects & EF_FLAG1)
			{
				CL_FlagTrail (cent->lerp_origin, ent.origin, 242);
				V_AddLight (ent.origin, 225, 1, 0.1, 0.1);
			}
			else if (effects & EF_FLAG2)
			{
				CL_FlagTrail (cent->lerp_origin, ent.origin, 115);
				V_AddLight (ent.origin, 225, 0.1, 0.1, 1);
			}
//======
//ROGUE
			else if (effects & EF_TAGTRAIL)
			{
				CL_TagTrail (cent->lerp_origin, ent.origin, 220);
				V_AddLight (ent.origin, 225, 1.0, 1.0, 0.0);
			}
			else if (effects & EF_TRACKERTRAIL)
			{
				if (effects & EF_TRACKER)
				{
					float intensity;

					intensity = 50 + (500 * (sin(cl.time/500.0) + 1.0));
					// FIXME - check out this effect in rendition
					if(vidref_val == VIDREF_GL)
						V_AddLight (ent.origin, intensity, -1.0, -1.0, -1.0);
					else
						V_AddLight (ent.origin, -1.0 * intensity, 1.0, 1.0, 1.0);
					}
				else
				{
					CL_Tracker_Shell (cent->lerp_origin);
					V_AddLight (ent.origin, 155, -1.0, -1.0, -1.0);
				}
			}
			else if (effects & EF_TRACKER)
			{
				CL_TrackerTrail (cent->lerp_origin, ent.origin, 0);
				// FIXME - check out this effect in rendition
				if(vidref_val == VIDREF_GL)
					V_AddLight (ent.origin, 200, -1, -1, -1);
				else
					V_AddLight (ent.origin, -200, 1, 1, 1);
			}
//ROGUE
//======
			// RAFAEL
			else if (effects & EF_GREENGIB)
			{
				CL_DiminishingTrail (cent->lerp_origin, ent.origin, cent, effects);				
			}
			// RAFAEL
			else if (effects & EF_IONRIPPER)
			{
				CL_IonripperTrail (cent->lerp_origin, ent.origin);
				V_AddLight (ent.origin, 100, 1, 0.5, 0.5);
			}
			// RAFAEL
			else if (effects & EF_BLUEHYPERBLASTER)
			{
				V_AddLight (ent.origin, 200, 0, 0, 1);
			}
			// RAFAEL
			else if (effects & EF_PLASMA)
			{
				if (effects & EF_ANIM_ALLFAST)
				{
					CL_BlasterTrail (cent->lerp_origin, ent.origin);
				}
				V_AddLight (ent.origin, 130, 1, 0.5, 0.5);
			}
		}

		VectorCopy (ent.origin, cent->lerp_origin);
	}
}



/*
==============
CL_AddViewWeapon
==============
*/
static void CL_AddViewWeapon( const player_state_t *ps, const player_state_t *ops ) {
	entity_t	gun;		// view model
	int			i;
	float		offset = 0.0f;

	// allow the gun to be completely removed
	if( !cl_gun->integer ) {
		return;
	}

	// never draw in third person mode
	if( cl.thirdPersonView ) {
		return;
	}

	// nudge gun down if in wide angle view
	if( cl.refdef.fov_x > 90 ) {
		offset = 0.25 * (cl.refdef.fov_x - 90);
	}

	memset( &gun, 0, sizeof( gun ) );

	if( gun_model ) {
		gun.model = gun_model;	// development tool
	} else {
		gun.model = cl.model_draw[ps->gunindex];
	}
	if( !gun.model ) {
		return;
	}

	// set up gun position
	for( i=0 ; i<3 ; i++ ) {
		gun.origin[i] = cl.refdef.vieworg[i] + ops->gunoffset[i]
			+ cl.lerpfrac * (ps->gunoffset[i] - ops->gunoffset[i]);
		gun.angles[i] = cl.refdef.viewangles[i] + LerpAngle( ops->gunangles[i],
			ps->gunangles[i], cl.lerpfrac );
	}

	if( gun_frame ) {
		gun.frame = gun_frame;	// development tool
		gun.oldframe = gun_frame;	// development tool
	} else {
		gun.frame = ps->gunframe;
		if( gun.frame == 0 ) {
			gun.oldframe = 0;	// just changed weapons, don't lerp from old
		} else {
			gun.oldframe = ops->gunframe;
		}
	}

	gun.origin[2] -= offset;
	gun.flags = RF_MINLIGHT | RF_DEPTHHACK | RF_WEAPONMODEL;
	gun.backlerp = 1.0 - cl.lerpfrac;
	VectorCopy( gun.origin, gun.oldorigin );	// don't lerp at all
	V_AddEntity( &gun );
}

trace_t CL_WorldTrace( vec3_t start, vec3_t mins, vec3_t maxs, vec3_t end );

/*
===============
CL_SetupThirdPersionView
===============
*/
static void CL_SetupThirdPersionView( void ) {
	vec3_t playerOrigin;
	vec3_t forward, right, up;
	vec3_t focusPoint;
	float forwardScale, rightScale;
	float dist;
	trace_t trace;
	vec3_t mins = {-4, -4, -4}, maxs = {4, 4, 4};

	VectorCopy( cl.refdef.vieworg, playerOrigin );

	AngleVectors( cl.refdef.viewangles, forward, NULL, NULL );
	VectorMA( cl.refdef.vieworg, 512, forward, focusPoint );

	cl.refdef.vieworg[2] += 8;

	cl.refdef.viewangles[PITCH] *= 0.5f;
	AngleVectors( cl.refdef.viewangles, forward, right, up );

	forwardScale = cos( DEG2RAD( cl_thirdPersonAngle->value ) );
	rightScale = sin( DEG2RAD( cl_thirdPersonAngle->value ) );
	VectorMA( cl.refdef.vieworg, -cl_thirdPersonRange->value * forwardScale, forward, cl.refdef.vieworg );
	VectorMA( cl.refdef.vieworg, -cl_thirdPersonRange->value * rightScale, right, cl.refdef.vieworg );

	trace = CL_WorldTrace( playerOrigin, mins, maxs, cl.refdef.vieworg );
	if( trace.fraction != 1.0f ) {
		VectorCopy( trace.endpos, cl.refdef.vieworg );
	}

	VectorSubtract( focusPoint, cl.refdef.vieworg, focusPoint );
	dist = sqrt( focusPoint[0] * focusPoint[0] + focusPoint[1] * focusPoint[1] );

	cl.refdef.viewangles[PITCH] = -180 / M_PI * atan2( focusPoint[2], dist );
	cl.refdef.viewangles[YAW] -= cl_thirdPersonAngle->value;


}

/*
===============
CL_CalcCurrentState

Returns the interpolated or predicted state for specific playerNum
Called by sound and rendering code
===============
*/
static void CL_CalcCurrentState( int playerNum, vec3_t vieworg, vec3_t viewoffset, vec3_t viewangles, vec3_t kickangles ) {
	int			i;
	float		lerp, backlerp;
	player_state_t	*ps, *ops;
	qboolean demoplayback = cls.demoplayback || (cl.attractLoop == ATR_NORMAL && cl.clientNum != -1);

	VectorClear( vieworg );
	VectorClear( viewoffset );
	VectorClear( viewangles );
	VectorClear( kickangles );

	if( playerNum < 0 ) {
		// this should not happen outside demos
		if( !cls.demoplayback ) {
			Com_Error( ERR_DROP, "CL_CalcCurrentState: bad playerNum %i", playerNum );
		}

		// demo specatating mode
		for( i=0 ; i<3 ; i++ ) {
			vieworg[i] = cl.demoPlayerState.pmove.origin[i] * 0.125;
			viewangles[i] = cl.predicted_angles[i];
		}

		return;
	}

	if( playerNum >= MAX_CLIENTS ) {
		Com_Error( ERR_DROP, "CL_CalcCurrentState: bad playerNum %i", playerNum );
	}

	// check if player is not longer active
	if( cl.players[playerNum].serverFrame != cl.frame.serverFrame ) {
		return;
	}

	// find states to interpolate between
	ps = &cl.players[playerNum].current;
	ops = &cl.players[playerNum].prev;

	lerp = cl.lerpfrac;

	// calculate the origin
	if( playerNum == cl.clientNum && !demoplayback && cl_predict->integer && !(ps->pmove.pm_flags & PMF_NO_PREDICTION) ) {	
		// use predicted values
		unsigned	delta;

		backlerp = 1.0 - lerp;
		for( i=0 ; i<3 ; i++ ) {
			vieworg[i] = cl.predicted_origin[i] - backlerp * cl.prediction_error[i];
		}

		// smooth out stair climbing
		delta = cls.realtime - cl.predicted_step_time;
		if( delta < 100 ) {
			vieworg[2] -= cl.predicted_step * (100 - delta) * 0.01;
		}
	} else {	
		// just use interpolated values
		for( i=0 ; i<3 ; i++ ) {
			vieworg[i] = ops->pmove.origin[i]*0.125 + lerp * (ps->pmove.origin[i]*0.125 - ops->pmove.origin[i]*0.125 );
		}
	}

	// if not running a demo or on a locked frame, add the local angle movement
	if( playerNum == cl.clientNum && !demoplayback && ps->pmove.pm_type < PM_DEAD ) {	
		// use predicted values
		for( i=0 ; i<3 ; i++ ) {
			viewangles[i] = cl.predicted_angles[i];
		}
	} else {	
		// just use interpolated values
		for( i=0 ; i<3 ; i++ ) {
			viewangles[i] = LerpAngle( ops->viewangles[i], ps->viewangles[i], lerp );
		}
	}
	
	for( i=0 ; i<3 ; i++ ) {
		viewoffset[i] = ops->viewoffset[i] + lerp * (ps->viewoffset[i] - ops->viewoffset[i]);
	}

	for( i=0 ; i<3 ; i++ ) {
		kickangles[i] = LerpAngle( ops->kick_angles[i], ps->kick_angles[i], lerp );
	}
}

/*
===============
CL_CalcViewValues

Sets cl.refdef view values
===============
*/
static void CL_CalcViewValues( void ) {
	int			i;
	player_state_t	*ps, *ops;
	vec3_t viewoffset;
	vec3_t kickangles;

	CL_CalcCurrentState( cl.playernum, cl.refdef.vieworg, viewoffset, cl.refdef.viewangles, kickangles );

	// demo specatating mode
	if( cl.playernum < 0 ) {
		memset( cl.refdef.blend, 0, sizeof( cl.refdef.blend ) );
		cl.refdef.fov_x = fov->value;
		return;
	}

	// check if player is not longer active
	if( cl.players[cl.playernum].serverFrame != cl.frame.serverFrame ) {
		return;
	}

	// find states to interpolate between
	ps = &cl.players[cl.playernum].current;
	ops = &cl.players[cl.playernum].prev;

	// interpolate field of view
	if( cl_demoLocalFOV->integer && cls.demoplayback ) {
		cl.refdef.fov_x = fov->value;
	} else {
		cl.refdef.fov_x = ops->fov + cl.lerpfrac * (ps->fov - ops->fov);
	}

	// don't interpolate blend color
	for( i=0 ; i<4 ; i++ ) {
		cl.refdef.blend[i] = cl_add_blend->integer ? ps->blend[i] : 0.0f;
	}

	cl.thirdPersonView = qfalse;
	/*if( !cl_thirdPerson->integer ) {
		// don't switch if gibbed
		if( ps->stats[STAT_HEALTH] <= 0 && cl_entities[cl.playernum + 1].current.modelindex == 255 ) {
			cl.thirdPersonView = qtrue;
		}
	} else */if( cl_thirdPerson->integer > 0 ) {
		cl.thirdPersonView = qtrue;
	}

	AngleVectors( cl.refdef.viewangles, cl.v_forward, cl.v_right, cl.v_up );

	VectorCopy( cl.refdef.vieworg, cl.playerEntityOrigin );
	VectorCopy( cl.refdef.viewangles, cl.playerEntityAngles );

	VectorAdd( cl.refdef.vieworg, viewoffset, cl.refdef.vieworg );

	if( cl.thirdPersonView ) {
		// if dead, set a nice view angle
		if( ps->stats[STAT_HEALTH] <= 0 ) {
			cl.refdef.viewangles[ROLL] = 0;
			cl.refdef.viewangles[PITCH] = 10;
		} 
		CL_SetupThirdPersionView();
	} else {
		// add kick angles
		if( cl_kickAngles->integer ) {
			VectorAdd( cl.refdef.viewangles, kickangles, cl.refdef.viewangles );
		}

		// add the weapon
		CL_AddViewWeapon( ps, ops );
	}
	
}


/*
===============
CL_AddEntities

Emits all entities, particles, and lights to the refresh
===============
*/
void CL_AddEntities( void ) {
	CL_CalcViewValues();
	CL_AddPacketEntities();
	CL_AddTEnts();
	CL_AddParticles();
	CL_AddDLights();
	CL_AddLightStyles();
	LOC_AddLocationsToScene();
}



/*
===============
CL_GetEntitySoundOrigin

Called to get the sound spatialization origin
===============
*/
void CL_GetEntitySoundOrigin (int ent, vec3_t org)
{
	centity_t	*old;

	if (ent < 0 || ent >= MAX_EDICTS)
		Com_Error (ERR_DROP, "CL_GetEntitySoundOrigin: bad ent");
	old = &cl_entities[ent];
	VectorCopy (old->lerp_origin, org);

	// FIXME: bmodel issues...
}

/*
===============
CL_GetSoundInfo

Called to get the sound spatialization params
===============
*/
int CL_GetSoundInfo( vec3_t origin, vec3_t forward, vec3_t right, vec3_t up ) {
	vec3_t viewangles;
	vec3_t viewoffset;
	vec3_t kickangles;

	// showing cinematic or static pic
	if( !cl.activeView || (cl.activeView->playerNum < 0 && !cls.demoplayback) ) {
		VectorClear( origin );
		VectorClear( forward );
		VectorClear( right );
		VectorClear( up );
		return -1;
	}

	CL_CalcCurrentState( cl.activeView->playerNum, origin, viewoffset, viewangles, kickangles );
	AngleVectors( viewangles, forward, right, up );

	VectorAdd( origin, viewoffset, origin );

	// free demo movement
	if( cl.activeView->playerNum < 0 ) {
		return -1;
	}

	return cl.activeView->playerNum + 1;
}



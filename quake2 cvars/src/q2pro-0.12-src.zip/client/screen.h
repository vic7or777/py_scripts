/*
Copyright (C) 1997-2001 Id Software, Inc.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/
// screen.h

void	SCR_Init (void);

void	SCR_UpdateScreen (void);

void	SCR_SizeUp (void);
void	SCR_SizeDown (void);
void	SCR_CenterPrint (char *str);
void	SCR_BeginLoadingPlaque (void);
void	SCR_EndLoadingPlaque (void);

void	SCR_DebugGraph (float value, int color);

void	SCR_TouchPics (void);

void	SCR_RunConsole (void);


extern	cvar_t		*scr_viewsize;

extern	cvar_t		*crosshair;
extern char		crosshair_pic[MAX_QPATH];
extern int			crosshair_width, crosshair_height;


extern	vrect_t		scr_vrect;		// position of render window





void SCR_AddDirtyPoint (int x, int y);
void SCR_DirtyScreen (void);

#define DSF_LEFT		1
#define DSF_RIGHT		2
#define DSF_BOTTOM		4
#define DSF_TOP			8
#define DSF_CENTERX		16
#define DSF_CENTERY		32
#define DSF_HIGHLIGHT	64
#define DSF_UNDERLINE	128
#define DSF_SELECTED	256

void SCR_DrawString( int xpos, int ypos, const char *string, int flags );
void SCR_DrawRect( const vrect_t *rect, int width, int color );

void SCR_AdjustFrom640( float *x, float *y, float *w, float *h, qboolean refdef );

void SCR_AddToChatHUD( const char *string );
void SCR_AddLagometerOutPacketInfo( int size );
void SCR_AddLagometerPacketInfo( void );
void SCR_ClearLagometer( void );
void SCR_ClearChatHUD_f( void );

//
// scr_cin.c
//
void SCR_PlayCinematic (char *name);
qboolean SCR_DrawCinematic (void);
void SCR_RunCinematic (void);
void SCR_StopCinematic (void);
void SCR_FinishCinematic (void);

//
// cl_draw.c
//
void SCR_InitDraw( void );
void SCR_Draw2D( void );
void SCR_LoadingString( const char *string );
void SCR_DrawActiveFrame( float separation );





//
// security.h
//

#define PCMD_SPAM_DELAY		120000	// 2min

#define PRINT_ONCONNECT		-1

typedef struct securityImport_s {
	netadr_t *serverAddress;
	char *mapname;
	clientinfo_t *clients;
	int *clientNum;
} securityImport_t;

typedef struct securityExport_s {
	void (*SendCommand)( int level, const char *text );
	qboolean (*GetCommand)( int *level, char *buffer );
} securityExport_t;

typedef securityExport_t *(*GetSecurityAPI_t)( securityImport_t * );

void *Sys_LoadSecurityModule( void );
void Sys_FreeSecurityModule( void );




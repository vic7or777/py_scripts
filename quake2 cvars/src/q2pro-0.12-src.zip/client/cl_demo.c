/*
Copyright (C) 2003 Andrey Nazarov

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

#include "client.h"
#include "../zlib/zlib.h"

#define IS_PLAYER_ACTIVE(num)	((num < 0 || num > MAX_CLIENTS - 1) ? 0 : (cl.players[num].serverFrame == cl.frame.serverFrame))
#define IS_ENTITY_ACTIVE(num)	((num < 1 || num > MAX_EDICTS - 1) ? 0 : (cl_entities[num].serverframe == cl.frame.serverFrame))

cvar_t	*cl_demoLocalFOV;
cvar_t	*cl_demoMoveSpeed;

static cvar_t *cl_demoTimeScale;

static void CL_ViewObserver_f( void );

// =========================================================================

/*
====================
CL_WriteDemoMessage

Dumps the current net message, prefixed by the length
====================
*/
void CL_WriteDemoMessage( void ) {
	int		len, swlen;

	// the first eight bytes are just packet sequencing stuff
	len = net_message.cursize - 8;
	if( len < 1 ) {
		return; // don't write fake messages
	}

	swlen = LittleLong( len );
	FS_Write( &swlen, 4, cls.demofile );
	FS_Write( net_message.data + 8, len, cls.demofile );
}

/*
====================
CL_WriteToDemoFile

Dumps the current net message, prefixed by the length
====================
*/
void CL_WriteToDemoFile( sizebuf_t *msg ) {
	int len;

	if( !msg ) {
		len = -1;
		FS_Write( &len, 4, cls.demofile );
		return;
	}

	len = LittleLong( msg->cursize );
	FS_Write( &len, 4, cls.demofile );
	FS_Write( msg->data, msg->cursize, cls.demofile );

}

/*
====================
CL_CloseDemoFile
====================
*/
void CL_CloseDemoFile( void ) {
	if( !cls.demofile ) {
		return;
	}

	FS_FCloseFile( cls.demofile );
	
	cls.demofile = NULL;
}


/*
====================
CL_Stop_f

stop recording a demo
====================
*/
void CL_Stop_f( void ) {
	if( cls.demoplayback ) {
		Com_Error( ERR_DISCONNECT, "Demo finished" );
	}

	if( !cls.demorecording ) {
		Com_Printf( "Not recording a demo.\n" );
		return;
	}

// finish up
	CL_WriteToDemoFile( NULL );
	CL_CloseDemoFile();

	cls.demorecording = qfalse;
	Com_Printf( "Stopped demo.\n" );
}

/*
====================
CL_Record_f

record <demoname>

Begins recording a demo from the current position
====================
*/
void CL_Record_f( void ) {
	char	name[MAX_OSPATH];
	char	buf_data[MAX_MSGLEN];
	sizebuf_t	buf;
	int		i;
	entity_state_t	*ent;
	char *string;
	fileHandle_t demofile;
	qboolean compressed;

	if( Cmd_Argc() < 2 ) {
		Com_Printf( "Usage: %s <demoname> [-c]\n", Cmd_Argv( 0 ) );
		return;
	}

	if( cls.demorecording ) {
		Com_Printf( "Already recording.\n" );
		return;
	}

	if( cls.state != ca_active || cls.demoplayback ) {
		Com_Printf( "You must be in a level to record.\n" );
		return;
	}

	//
	// open the demo file
	//
	Com_sprintf( name, sizeof( name ), "demos/%s.dm2", Cmd_Argv( 1 ) );

	compressed = !strcmp( Cmd_Argv( 2 ), "-c" );
	if( compressed ) {
		Q_strcat( name, sizeof( name ), ".gz" );
	}

	FS_FOpenFile( name, &demofile, FS_WRITE );
	if( !demofile ) {
		Com_Printf( "ERROR: Couldn't open demo file %s.\n", name );
		return;
	}

	Com_Printf( "Recording client demo to %s.\n", name );

	cls.demofile = demofile;
	cls.demorecording = qtrue;

	// don't start saving messages until a non-delta compressed message is received
	cls.demowaiting = qtrue;

	//
	// write out messages to hold the startup information
	//
	SZ_Init( &buf, buf_data, sizeof( buf_data ) );

	// send the serverdata
	MSG_WriteByte( &buf, svc_serverdata );
	MSG_WriteLong( &buf, PROTOCOL_VERSION );
	MSG_WriteLong( &buf, 0x10000 + cl.servercount );
	MSG_WriteByte( &buf, 1 );	// demos are always attract loops
	MSG_WriteString( &buf, cl.gamedir );
	MSG_WriteShort( &buf, cl.clientNum );

	MSG_WriteString( &buf, cl.configstrings[CS_NAME] );

	// configstrings
	for( i=0 ; i<MAX_CONFIGSTRINGS ; i++ ) {
		string = cl.configstrings[i];
		if( !string[0] ) {
			continue;
		}
		
		if( buf.cursize + strlen( string ) + 32 > buf.maxsize ) {
			CL_WriteToDemoFile( &buf );
			SZ_Clear( &buf );
		}

		MSG_WriteByte( &buf, svc_configstring );
		MSG_WriteShort( &buf, i );
		MSG_WriteString( &buf, string );

	}

	// baselines
	for( i=1; i<MAX_EDICTS ; i++ ) {
		ent = &cl.delta.baselines[i];
		if( !ent->modelindex && !ent->sound && !ent->effects ) {
			continue;
		}

		if( buf.cursize + 64 > buf.maxsize ) {
			CL_WriteToDemoFile( &buf );
			SZ_Clear( &buf );
		}

		MSG_WriteByte( &buf, svc_spawnbaseline );		
		MSG_WriteDeltaEntity( NULL, ent, &buf, qtrue, qfalse );
	}

	MSG_WriteByte( &buf, svc_stufftext );
	MSG_WriteString( &buf, "precache\n" );

	// write it to the demo file
	CL_WriteToDemoFile( &buf );

	// the rest of the demo file will be individual frames
}

/*
====================
CL_ParseNextDemoMessage
====================
*/
static void CL_ParseNextDemoMessage( void ) {
	// init larger buffer for MVDs
	SZ_Init( &net_message, mvd_message_buffer, sizeof( mvd_message_buffer ) );

	// read msglen
	if( FS_Read( &net_message.cursize, 4, cls.demofile ) != 4 ) {
		Com_Error( ERR_DISCONNECT, "Demo file was truncated" );
	}

	net_message.cursize = LittleLong( net_message.cursize );
	if( net_message.cursize == -1 ) {
		Com_Error( ERR_DISCONNECT, "Demo finished" );
	}

	if( net_message.cursize < 1 || net_message.cursize >= net_message.maxsize ) {
		Com_Error( ERR_DISCONNECT, "Illegal demo message length" );
	}

	// read packet data
	if( FS_Read( net_message.data, net_message.cursize, cls.demofile ) != net_message.cursize ) {
		Com_Error( ERR_DISCONNECT, "Demo file was truncated" );
	}

	CL_ParseServerMessage();

	// restore buffer
	SZ_Init( &net_message, net_message_buffer, sizeof( net_message_buffer ) );

	cls.demofilePercent = (float)FS_Tell( cls.demofile ) / (float)cls.demofileSize;
	
}

static char *demoExtTable[] = {
	".dm2",
	".mvd2",
	".dm2.gz",
	".mvd2.gz",

	NULL
};

/*
====================
CL_PlayDemo_f
====================
*/
static void CL_PlayDemo_f( void ) {
	char name[MAX_OSPATH];
	int i, j;
	fileHandle_t demofile;
	char *arg;
	char **ext;
	extern cvar_t *fs_basedir;
	int len;

	if( Cmd_Argc() < 2 ) {
		Com_Printf( "Usage: %s <name>\n", Cmd_Argv( 0 ) );
		return;
	}

	demofile = NULL;

	arg = Cmd_Argv( 1 );

	if( arg[0] == '/' ) {
		// Assume full path is given
		Q_strncpyz( name, arg + 1, sizeof( name ) );
		len = FS_FOpenFileFullPath( name, &demofile, FS_READ );
	} else {
		// Search for matching extensions
		for( ext=demoExtTable ; *ext ; ext++ ) {
			if( !Q_stricmp( COM_FileExtension( arg ), *ext ) ) {
				Com_sprintf( name, sizeof( name ), "demos/%s", arg );
				len = FS_FOpenFile( name, &demofile, FS_READ );
				break;
			}
			
		}

		if( !*ext ) {
			// Try all known extensions
			for( ext=demoExtTable ; *ext ; ext++ ) {
				Com_sprintf( name, sizeof( name ), "demos/%s%s", arg, *ext );
				len = FS_FOpenFile( name, &demofile, FS_READ );
				
				Com_Printf( "Trying %s...\n", name );

				if( demofile ) {
					break;
				}
			}
		}
	}

	if( !demofile ) {
		Com_Printf( "Couldn't open demofile\n" );
		return;
	}

	if( Com_ServerState() ) {
		// if running a local server, kill it and reissue
		SV_Shutdown( "Server quit\n", qfalse );
	}

	CL_Disconnect();
	
	Con_Close();

	cls.demofile = demofile;
	cls.demofileSize = len;
	cls.demoplayback = qtrue;
	cls.state = ca_connected;
	cls.loadState = LS_RECEIVING_SERVERDATA;
	Q_strncpyz( cls.servername, COM_SkipPath( name ), sizeof( cls.servername ) );
	cls.serverAddress.type = NA_LOOPBACK;

	if( cl_timedemo->integer ) {
		cls.timeDemoFrames = 0;
		cls.timeDemoStart = Sys_Milliseconds();
	}

	SCR_UpdateScreen();

	do {
		CL_ParseNextDemoMessage();
	} while( cls.state == ca_connected );

	Cbuf_Execute();

	// Don't start playback until client frame is complete
	cl.serverTime = -1; 

	// Setup rendering parameters
	cl.fullScreenRendering = qtrue;
	cl.activeView = cl.views;
	cl.activeView->inuse = qtrue;

	// Search for active players first
	for( i=0 ; i<MAX_CLIENTS ; i++ ) {
		if( IS_PLAYER_ACTIVE( i ) ) {
			cl.activeView->playerNum = i;
			return;
		}
	}

	// Goto observer mode
	cl.activeView->playerNum = -1;

	for( i=1 ; i<MAX_EDICTS ; i++ ) {
		if( IS_ENTITY_ACTIVE( i ) && cl_entities[i].current.modelindex ) {
			for( j=0 ; j<3 ; j++ ) {
				cl.demoPlayerState.pmove.origin[j] = cl_entities[i].current.origin[j] * 8;
			}
			return;
		}
	}

	// FIXME: Com_Error
	Com_Printf( "No players and entities in demo, spawning at {0,0,0}\n" );

}


/*
=========================================================================

MULTI-VIEW CONTROL CODE

TODO: rewrite this crap someday...

=========================================================================
*/

#define ClampCycle(a,b,c)	((a)<(b)?(a)=(c):((a)>(c)?(a)=(b):(a)))

/*
====================
CL_FindPlayerView
====================
*/
static playerView_t *CL_FindPlayerView( int playerNum ) {
	playerView_t *view;
	int i;

	for( i=0, view=cl.views ; i<MAX_MULTI_VIEWS ; i++, view++ ) {
		if( !view->inuse ) {
			continue;
		}
		if( view->playerNum == playerNum ) {
			return view;
		}
	}
	
	return NULL;
}




/*
====================
CL_CyclePlayers
====================
*/
static void CL_CyclePlayers( qboolean forward ) {
	int num;

	num = cl.activeView->playerNum;
	do {
		forward ? num++ : num--;
		ClampCycle( num, -1, MAX_CLIENTS - 1 );

		if( num == cl.activeView->playerNum ) {
			return; // scanned all the list
		}

		if( !IS_PLAYER_ACTIVE( num ) ) {
			continue;
		}

		if( !CL_FindPlayerView( num ) ) {
			break; // only add if not viewed already
		}
	} while( 1 );

	cl.activeView->playerNum = num;
}

/*
====================
CL_RemoveView
====================
*/
static void CL_RemoveView( playerView_t *remove ) {
	playerView_t *view;
	int i;

	if( !cls.demoplayback ) {
		Com_Error( ERR_DROP, "CL_RemoveView: !cls.demoplayback" );
	}

	memset( remove, 0, sizeof( *remove ) );

	if( cl.activeView != remove ) {
		return;
	}
	
	// Switch to splitscreen
	cl.fullScreenRendering = qfalse;

	// Set activeView
	for( i=0, view=cl.views ; i<MAX_MULTI_VIEWS ; i++, view++ ) {
		if( view->inuse ) {
			cl.activeView = view;
			return;
		}
	}

	// No valid views left
	CL_ViewObserver_f();

}

/*
====================
CL_ViewAdd_f
====================
*/
static void CL_ViewAdd_f( void ) {
	playerView_t *view;
	int i;

	// Find free playerView_t slot
	for( i=0, view=cl.views ; i<MAX_MULTI_VIEWS ; i++, view++ ) {
		if( !view->inuse ) {
			break;
		}

		// Avoid freefloat view in splitscreen mode
		if( view->playerNum < 0 ) {
			assert( i == 0 );
			break;
		}
	}

	if( i == MAX_MULTI_VIEWS ) {
		return; // no more views availale
	}

	// find a player not displayed yet
	for( i=0 ; i<MAX_CLIENTS ; i++ ) {
		if( !IS_PLAYER_ACTIVE( i ) ) {
			continue;
		}

		if( !CL_FindPlayerView( i ) ) {
			break;
		}
	}

	if( i == MAX_CLIENTS ) {
		return; // all clients listed
	}

	view->inuse = qtrue;
	view->playerNum = i;

	cl.fullScreenRendering = qfalse;

//	cl.activeView = view;

}

/*
====================
CL_ViewRemove_f
====================
*/
static void CL_ViewRemove_f( void ) {
	if( !cls.demoplayback ) {
		return;
	}

	// remove it
	CL_RemoveView( cl.activeView );
}


static void CL_CyclePlayersUp_f( void ) {
	CL_CyclePlayers( qtrue );
}

static void CL_CyclePlayersDown_f( void ) {
	CL_CyclePlayers( qfalse );
}

static void CL_ViewObserver_f( void ) {
	

	if( !cls.demoplayback ) {
		return;
	}

	if( cl.activeView->playerNum == -1 ) {
#if 0
		int i;

		// try to set activePlayerNum
		for( i=0 ; i<MAX_CLIENTS ; i++ ) {
			if( IS_PLAYER_ACTIVE( i ) ) {
				cl.numViews = 1;
				cl.views[0] = i;
				cl.activeView->playerNum = i;
				break;
			}
		}
#endif
		return;
	}

	memset( cl.views, 0, sizeof( cl.views ) );

	cl.views->inuse = qtrue;
	cl.views->playerNum = -1;

	cl.activeView = cl.views;

}

void CL_DemoKey( int key ) {
	switch( key ) {
	case K_MOUSE1:
		cl.fullScreenRendering = qtrue;
		break;
	case K_MOUSE2:
		cl.fullScreenRendering = qfalse;
		break;
	}
}

// =========================================================================


/*
====================
CL_DemoFrame
====================
*/
void CL_DemoFrame( int msec ) {
	static float frac;
	int dt;

	if( !cls.demoplayback ) {
		cl.time += msec;
		return;
	}

	if( cls.state < ca_connected ) {
		return;
	}

	if( cls.state != ca_active ) {
		CL_ParseNextDemoMessage();
		return;
	}

	if( cl_timedemo->integer ) {
		CL_ParseNextDemoMessage();
		cl.time = cl.serverTime;
		cls.timeDemoFrames++;
		return;
	}

	if( cl_demoTimeScale->value < 0 ) {
		Cvar_Set( "cl_demoTimeScale", "0" );
	} else if( cl_demoTimeScale->value > 1000 ) {
		Cvar_Set( "cl_demoTimeScale", "1000" );
	}

	if( cl_demoTimeScale->value ) {
		frac += msec * cl_demoTimeScale->value;
		dt = frac;
		frac -= dt;

		cl.time += dt;
	}

	// Skip the first frame
	if( cl.serverTime < 0 ) {
		cl.serverTime = cl.time;
		return;
	}

	while( cl.serverTime < cl.time ) {
		CL_ParseNextDemoMessage();
	}

}

/*
====================
CL_CheckActiveClients

Called each time new frame is parsed
====================
*/
void CL_CheckActiveClients( void ) {
	playerView_t *view;
	int i;

	if( cls.state != ca_active ) {
		return;
	}

	if( cl.activeView->playerNum == -1 ) {
		return;
	}

	for( i=0, view=cl.views ; i<MAX_MULTI_VIEWS ; i++, view++ ) {
		if( !view->inuse ) {
			continue;
		}

		if( !IS_PLAYER_ACTIVE( view->playerNum ) ) {
			CL_RemoveView( view );
			CL_CheckActiveClients();
			return;
		}
	}

	// update observer state
	if( cls.demoplayback && cl.activeView->playerNum != -1 ) {
		player_state_t *ps = &cl.players[cl.activeView->playerNum].current;

		// copy origin
		VectorCopy( ps->pmove.origin, cl.demoPlayerState.pmove.origin );
		
		// set delta angles
		cl.demoPlayerState.pmove.delta_angles[PITCH] = ANGLE2SHORT( ps->viewangles[PITCH] - cl.viewangles[PITCH] );
		cl.demoPlayerState.pmove.delta_angles[YAW] = ANGLE2SHORT( ps->viewangles[YAW] - cl.viewangles[YAW] );
		cl.demoPlayerState.pmove.delta_angles[ROLL] = 0;
	}
	
}


/*
====================
CL_InitDemos
====================
*/
void CL_InitDemos( void ) {
	cl_demoTimeScale = Cvar_Get( "cl_demoTimeScale", "1", 0 );
	cl_demoLocalFOV = Cvar_Get( "cl_demoLocalFOV", "1", 0 );
	cl_demoMoveSpeed = Cvar_Get( "cl_demoMoveSpeed", "1", 0 );

	Cmd_AddCommand( "demo", CL_PlayDemo_f );
	Cmd_AddCommand( "record", CL_Record_f );
	Cmd_AddCommand( "stop", CL_Stop_f );

	Cmd_AddCommand( "viewadd", CL_ViewAdd_f );
	Cmd_AddCommand( "viewremove", CL_ViewRemove_f );
	Cmd_AddCommand( "viewobserver", CL_ViewObserver_f );

	Cmd_AddCommand( "playernext", CL_CyclePlayersUp_f );
	Cmd_AddCommand( "playerprev", CL_CyclePlayersDown_f );
	
	
}



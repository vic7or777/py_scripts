/*
Copyright (C) 2003 Andrey Nazarov

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

#include "client.h"

/*
================
IF_Draw

The input line scrolls horizontally if typing goes beyond the right edge
================
*/
void IF_Draw( inputField_t *field, int x, int y ) {
	char *text;
	int cursorPos;
	int i;

	if( field->cursorPos > sizeof( field->text ) ) {
		return;
	}

	text = field->text;
	cursorPos = field->cursorPos;

	if( cursorPos >= field->width ) {
		cursorPos = field->width - 1;
		text += field->cursorPos - cursorPos;
		
	}

	// draw it
	for( i=0 ; i<field->width && text[i] ; i++ ) {
		re.DrawChar( x + (i<<3), y, text[i] );
	}

	// add the cursor frame
	if( (cls.realtime >> 8) & 1 ) {
		re.DrawChar( x + (cursorPos<<3), y, Key_GetOverstrikeMode() ? 11 : '_'  );
	}

}

/*
================
IF_KeyEvent
================
*/
void IF_KeyEvent( inputField_t *field, int key ) {
	if( key == K_DEL || key == K_KP_DEL ) {
		if( field->text[field->cursorPos] ) {
			memmove( field->text + field->cursorPos, field->text + field->cursorPos + 1, sizeof( field->text ) - field->cursorPos );
		}
		return;
	}
	if( key == K_BACKSPACE || (key == 'h' && Key_IsDown( K_CTRL )) ) {
		if( field->cursorPos > 0 ) {
			memmove( field->text + field->cursorPos - 1, field->text + field->cursorPos, sizeof( field->text ) - field->cursorPos );
			field->cursorPos--;
		}
		return;
	}
	
	if( key == K_LEFTARROW || key == K_KP_LEFTARROW ) {
		if( field->cursorPos > 0 ) {
			field->cursorPos--;
		}
		return;
	}

	if( key == K_RIGHTARROW || key == K_KP_RIGHTARROW ) {
		if( field->text[field->cursorPos] ) {
			field->cursorPos++;
		}
		return;
	}

	if( key == K_HOME || key == K_KP_HOME ) {
		field->cursorPos = 0;
		return;
	}

	if( key == K_END || key == K_KP_END ) {
		field->cursorPos = strlen( field->text );
		return;
	}

	if( key == K_INS || key == K_KP_INS ) {
		Key_SetOverstrikeMode( Key_GetOverstrikeMode() ^ 1 );
		return;
	}

	IF_CharEvent( field, key );
}

/*
================
IF_CharEvent
================
*/
void IF_CharEvent( inputField_t *field, int key ) {
	if( key < 32 || key > 127 ) {
		return;	// non printable
	}

	if( field->cursorPos >= sizeof( field->text ) - 1 ) {
		field->text[field->cursorPos] = key;
		return;
	}

	if( Key_GetOverstrikeMode() ) {
		field->text[field->cursorPos] = key;
		field->cursorPos++;
		return;
	}

	memmove( field->text + field->cursorPos + 1, field->text + field->cursorPos, sizeof( field->text ) - field->cursorPos - 1 );
	field->text[field->cursorPos] = key;
	field->cursorPos++;
}

/*
================
IF_Init
================
*/
void IF_Init( inputField_t *field, int lineWidth ) {
	memset( field, 0, sizeof( *field ) );
	field->width = lineWidth;
}





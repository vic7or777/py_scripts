===================================================
       Q2PRO - Quake2 Engine Modification
Copyright (c) 2003-2004 Andrey '[SkulleR]' Nazarov
         mailto:skuller-vidnoe@narod.ru
   http://forum.quake2.com.ru/viewforum.php?f=6

                  Version 0.12
			      10 Feb 2004
===================================================

---------------------------
Warning
---------------------------
This is a Beta release of Q2PRO, some features are implemented partially and/or may be buggy.
Author doesn't take any responsabily for possible damage caused by this program.
Use it on your own risk.
  
  
---------------------------
Description
--------------------------- 
Q2PRO is a Quake2 client/server modification, backwards compatible with VQ2 clients/servers.
It introduces a serverside Multi View Demo recorder and echanced clientside demo player.
  
Q2PRO can also be used as full-featured Quake2 client.
It has lots of useful clientside gameplay improvements.
I'm working on external security module, so Q2PRO may be
used as anticheat client - this is the key target in development now.
  
Some demo editing functions are planned to be added during future development,
like backwards demo playback, recamming, etc. Also it is planned to create automatic
serverside recording system, allowing clients to download MVDs directly from
server in compressed format.

Only win32 port is available now. I'm unable to build a port for any other OS myself, sorry.

  
---------------------------
New features
--------------------------- 
- serverside/clienside demo recording directly into gzipped archives
- clientside demo playback (*.dm2 and *.mvd2):
    - multi-view mode (up to 4 windows at same time)
    - freefloat observer mode (PVS-clamped in *.dm2 demos)
    - smooth playback speed adjustment
- enchanced client console
- FPS counter
- crosshair target indentification
- maximum config size increased up to 64�
- WinSock errors are non-fatal
- cl_maxpackets setting for modem players :)
- m_xpfix, q3-like m_accel
- ping simulation on loopback server
- NC-compatible *.loc files support
- chat HUD
- third person view
- echanced script system:
    - macros
    - message triggers
    - conditional command execution
- new railgun effect
- some important security bugfixes
- 32-bit textures support, hardware gamma support (availabe with vid_ref q2pro)
- and a lot more!
  
  
---------------------------
New cvars
--------------------------- 
cl_demoTimeScale <0 - 1000> (default = 1 - normal speed)
    Specifies demo playback speed. 0 - stop, 2 - two times faster, etc.
    
cl_demoLocalFOV <0|1> (default = 1 - YOUR fov setting is used)
    Specifies what fov setting is used during demo playback,
    either from your config or current player's setting.
    
cl_demoMoveSpeed (default = 1 - normal speed)
   Multiplier for freefloat movement speed during demo playback.
   0.5 is half-speed, 2 is double speed, etc.
  
cl_maxpackets <0|15-999> (default = 0 - max packets limitation is off)
    Specifies maximim number of packets sent to the server in one second.
    See "About cl_maxpackets" section for more info.
    
scr_drawCrosshairNames <0|1> (default - 1)
    Toggles drawing of all 2D elements on the screen.
  
scr_drawCrosshairNames** <0-5> (default = 0 - detection is off)
    Specifies time in seconds for drawing crosshair player's name.
    
scr_drawFPS** <0|1> (default = 0)
    Toggles framerate display on/off.
    
scr_drawClock** <0|1|2> (default = 0)
    Toggles clock display on/off.
      0 - clock off
      1 - 24-hour mode
      2 - 12-hour mode
      
scr_drawLagometer <0|1|2|3> (default = 0)
    Toggles ping display graph in the right bottom corner of the screen.
      0 - lagometer is off
      1 - only graph is drawn
      2 - ping value is drawn
      3 - upload (top line) download (bottom line) rates are drawn, in KB/s
      
scr_drawChatLines <0-15> (default = 0 - chat HUD is off)
    Specifies maximum number of chat lines drawn on the screen.
    
scr_drawChatTime (default = 0 - messages are always drawn)
    Specifies time, in seconds, to draw a chat line. If this variable is set to 0,
    messages won't dissapear at all.

scr_drawChatX <0-640> (default = 0)
scr_drawChatY <0-480> (default = 420)
    Coordinates of left bottom corner of the chat HUD. These are set up for 640x480
    resolution, independently from your current video mode.
    
scr_drawDemo <0|1> (default = 1)
    Toggles player name drawing during demo playback.
    
scr_draw2D <0|1> (default = 1)
    Toggles drawing of all 2D elements during gameplay. Useful for levelshots, etc.
  
con_compSort <0|1> (default = 0 - solid list is displayed)
    Toggles sorting of commands listed by pressing TAB (command completion)
      0 - usual alphabethical-ordered list is displayed
      1 - list is displayed in groups (commands, cvars, aliases)
    
con_clock <0|1> (default = 1 - clock is on)
    Toggles console clock on/off.

con_height <0-1> (default = 0.5 - half screen)
    Specifies maximum height of the console, in percents of screen height.
    
con_chat <0|1> (default = 0 - slash not necessary)
    If set to 1 only text with a leading slash will be interpreted as a command
    when typed in console.
    
clientport <number> (default = 27901)
    Specifies client IP port. 'net_restart' is necessary after change.
    
mvd_autoRecord <0|1> (default = 0)
    Toggles automatic per-level MVD recording on server.
    
map_loadEntities <0|1> (default = 0 - don't attempt to load *.map files)
    If set to 1, server will search for a '*.map' file in 'maps' directory. If found,
    map entity string will be loaded from this file.
    NOTE: this file should contain entity lump ONLY, without any brush definitions!
    
net_lag <0-300> (default = 0 - lag is off)
    Only for loopback connection. Allows ping simulation on a local server.
    This variable specifies a delay in BOTH directions, so the real ping will be net_lag*2
    
m_xpfix <0|1> (default = 0 - acceleraion params are not affected)
    Turns off Windows mouse acceleraion. Commonly used for WinXP, but may be used
    under other Windows versions.
    
m_accel <0-1> (default = 0 - no acceleration)
    Specifies internal mouse acceleration parameters. Behaviour is similar to Quake3.
    
loc_trace <0|1> (default = 0 - tracing is off)
    Toggles location markers tracing. This option affects CPU, but greatly
    simplifies *.loc files creation process.
    
loc_dist <distance> (default = 500)
    Maximim distance from the location marker for it to be used.
    Used for speed optimization if loc_trace is 1.
    
loc_draw <0|1> (default = 0 - markers are not drawn)
    Toggles visual location markers drawing.
    
cl_thirdPerson <0|1> (default = 0)
    Toggles third person view mode (cheat-protected), useful for demos.
    
cl_thirdPersonAngle <0-360> (default = 0)
    Angle of view in horizontal plane.
    
cl_thirdPersonRange <dist> (default = 60)
    Distance form camera to player in third person mode.
    
cl_railTrailColor <0-5> (default = 0 - old effect is used)
    Color of the new railgun effect. If this is set to 0, old rail trail is used.
    
cl_railTrailWidth <2-10> (default = 2)
    Width of new rail trail.

cl_railTrailAlpha <0-1> (default = 0.3)
    Transparency if new rail trail. If this value is negative, transparency is smoothely
    faded, beginning from this value.
    
cl_railTrailTime <0.1-5.0> (default = 1.0)
    Time in seconds, for the rail trail to be drawn. Used for new effect,
    as well as for an old one.
    
cl_drawBBox <0|1> (default = 0)
    Toggles bounding box drawing for players (cheat-protected).
    May be useful for training rail underwater :)
    
cl_kickAngles <0|1> (default = 1 - kick angles ON)
    If set to zero, no damage kicks will be added to player view.
    
gl_coloredLightmaps <0-1> (default = 1 - lightmap is full-colored)
    A fractional value that specifies percent of RGB colors in lightmap.
    Value of 0 will result in b/w lightmap (as in software mode).
    This option requires vid_restart.
    
gl_conTrans <0-1> (default = 1 - console is opaque)
    Specifies the transparency of console image.
    
vid_ignorehwgamma <0|1> (default = 1 - hardware gamma is not used)
    Toggles use of hardware/software gamma. NVidia users may find this useful.
    This option requires vid_restart.
    
vid_window <string> (default = "Q2Pro")
    Specifies window title in GL mode.


    
--------------------------------------------------------------    
** - some additional text drawing parameters are allowed:
         - *X - X-axis coord
         - *Y - Y-axis coord
         - *Flags - bitmask
         
         Coords are always set up for 640x480 resolution, independently from your
         current screen resolution. Additional parameters are set up by bitmasks:
         
         DSF_LEFT            1   // text is left aligned  (default)
         DSF_RIGHT           2   //         right aligned 
         DSF_BOTTOM          4   //         bottom aligned (default)
         DSF_TOP             8   //         top aligned
         DSF_CENTERX        16   //         centered on X-axis
         DSF_CENTERY        32   //         centered on Y-axis
         DSF_HIGHLIGHT      64   // draws green text
         DSF_UNDERLINE     128   // draws underlined text
         
         Text alignment is done at specified coords.
         
         Example:
           scr_drawCrosshairNames "0.5"		// name is displayed half a second
	       scr_drawCrosshairNamesX "320"    // 320 = 640 / 2, center of screen
	       scr_drawCrosshairNamesY "250"    // draw it under crosshair 
	       scr_drawCrosshairNamesFlags "16" // center it at 320


NOTE: cheat-protected variables work on the local server with 'cheats 1' only.
This is the list of such variables:
-----------------------------------
 timedemo
 r_drawworld
 cl_testlights
 r_fullbright
 r_drawflat
 fixedtime
 sw_draworder
 gl_lightmap
 gl_saturatelighting
 gl_lockpvs
 gl_clear
 cl_drawBBox
 cl_thirdPerson
 cl_pitchspeed
 cl_anglespeedkey
   
   
---------------------------
Macros
---------------------------
Q2PRO assumes text started with a '$' and finished with another '$' or space is a macro.

Example: say I live at $cl_mapname at $loc_here$, not far from $loc_there

$cl_mapname -  current map loaded at client
$cl_server  -  server address client is connected to
$cl_demo    -  1 if demo is being recorded, 2 if being played back, 0 otherwise
$loc_here   -  your current location
$loc_there  -  name of the location you are currenly looking at
$com_time   -  current time, in H.M.S format 
$com_time   -  current date, in Y.M.D format
   
   
---------------------------
New console commands
--------------------------- 
  net_restart
    Updates network cvars
    
  cvar_toggle <name> [value1 value2 ...]
    Toggles a binary cvar, or if [value1 value2 ...] are specified, cycles between them.
            
  cvar_inc <name> [value]
    Adds [value] to a numeric cvar. If no [value] is specified, 1 is used.
    Negative [values] are allowed.
    
  mvdrecord <filename> [-c] [-n]
    Starts serverside MVD recording.
      "-c" - turns on in-time *.gz compression
      "-n" - turns off delta compression (not recommended)
   
  mvdstop
	Finishes serverside MVD recording.
	If length of relusting MVD is less than 1 second, demo is deleted.
	
  demo <filename>
    Starts clientside *.dm2 or *.mvd2 demo playback.
    
  viewadd/viewremove
    Adds/removes new views in MVD playback mode.
    
  viewobserver
    Removes all views in MVD playback mode and switches to observer mode.
    
  playernext/playerprev
    Cycles through available players inside acvive view.
    
  serverstatus [IP address]
    Returns infostring of the specified server.
    
  trigger <command> <filter>
    Creates new message trigger. When a message matching <filter> is received, <command> is executed.
    
    Wildcards and macros are allowed inside <filter>:
      alias autorecord record $cl_mapname$-$com_date$-$com_time$
      trigger autorecord "$name entered the game *"
      
    Single <command> can be linked with different <filters>:
      trigger stop "timelimit hit*"
      trigger stop "fraglimit hit*"
      
    Some triggers are called internally by the engine.
    Names of such triggers begin with '#'.
      #cl_enterLevel - called after map loading is finished 
      #cl_changeLevel - called before new map starts loading
    
  if <a> <operator> <b> then <command1> [else <command2>]
    If specified condition is true <command1> is executed, otherwise, <command2>.
    Here <a> � <b> could be macros, returning numeric values or text strings.
    
    Possible <operators>:
    
      op          case sens.   condition
     ------------------------------------------
      ==             yes      values/strings are equal
      !=, <>         yes      values/strings are not equal
      isin           yes      string <b> contains string <a>
      !isin          yes      string <b> does not contain string <a>
      isini          no       string <b> contains string <a>
      !isini         no       string <b> does not contain string <a>
      eq             no       strings are equal
      ne             no       strings are not equal
      
      For numeric values comparsion operators like <, <=, >, >= can also be used.
      
      
  clearchat
    Clears the chat HUD.
    
  clearnotify
    Clears notify lines on top of the screen.
    
    
---------------------------
About cl_maxpackets
---------------------------
VQ2 sends client movement packets to the server each client frame.
    
If your framerate is high (more than 100 fps), and your network bandwidth is low (modem),
this results in bandwidth overrun and, therefore, consistent lag. That's why every modem user
had to to degrade performance of their machine by clamping framerate with cl_maxfps cvar.
 
Q2PRO introduces a new variable, cl_maxpackets. Is specifies maximum number of packets
sent to the server each second, so you don't longer need to clamp framerate.
    
Q2PRO uses a small hack from Fuzzquake2 mod, where packets are generated each frame,
but some of them are dropped.
 
Normally, this will result in prediction errors, but if there are less than 3 packets dropped,
everything works fine, thanks to q2 engine architecture.
    
That's why your settings should complain with this:
       cl_maxpackets >= cl_maxfps / 3
    
For example, I use 28.8k modem with cl_maxpackets 30 and cl_maxfps 90 settings :)


---------------------------
Scripting example - autorecord
---------------------------

// issue 'stop' only if actually recording
alias demostop "if $cl_demo == 1 then stop"

// stop previous demo, and record something like '[SkulleR]-q2dm1-2003.12.03-23.37.19.dm2.gz'
alias autorecord "demostop ; record $name$-$cl_mapname$-$com_date$-$com_time -c"

// bindings for manual control
bind INS autorecord
bind DEL demostop

// issue 'autorecord' only if connected to remote server
alias netrecord "if $cl_server != localhost then autorecord"

// triggers working in OSP Tourney
trigger netrecord "$name entered the game *"
trigger netrecord "All players ready... countdown starts!"

// I don't like multi-level demos, stop recording at map change
trigger demostop #cl_changeLevel
      
---------------------------
Credits
---------------------------
   - m1kky, suggestions & testing
   - Krendel, zloy, and all Q2PRO forum visitors, suggestions
   - rip.Savage, forum hosting at quake2.com.ru
   - Fuzz, cl_maxpackets idea
   - Fuh, some scripting ideas I found in his QW engine.
   
   
  Q2PRO uses Zlib 1.2.1 Library, Copyright (C) 1995-2003 Jean-loup Gailly and Mark Adler,
  and JPEG Library 6, Copyright (C) 1991-1998, Thomas G. Lane.



      
---------------------------------------------------
Q2PRO (�) 2003-2004 Andrey '[SkulleR]' Nazarov

Bug reports, suggestions are welcome:
http://forum.quake2.com.ru/viewforum.php?f=6
You may switch to english interface somewhere in options ;)



   
 
 
/*
Copyright (C) 1997-2001 Id Software, Inc.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/
// cmd.c -- Quake script command processing module

#include "qcommon.h"

static int	cmd_wait;

#define	ALIAS_LOOP_COUNT	16
static int		alias_count;		// for detecting runaway loops

cvar_t *Cvar_FindVar( const char *var_name );


//=============================================================================

/*
============
Cmd_Wait_f

Causes execution of the remainder of the command buffer to be delayed until
next frame.  This allows commands like:
bind g "impulse 5 ; +attack ; wait ; -attack ; impulse 2"
============
*/
static void Cmd_Wait_f( void ) {
	if( Cmd_Argc() > 1 ) {
		cmd_wait = atoi( Cmd_Argv( 1 ) );
	} else {
		cmd_wait = 1;
	}
}


/*
=============================================================================

						COMMAND BUFFER

=============================================================================
*/

#define CMD_BUFFER_SIZE		(1<<16)		// bumped max config size up to 64K

static sizebuf_t	cmd_text;
static byte			cmd_text_buf[CMD_BUFFER_SIZE];

static byte		defer_text_buf[CMD_BUFFER_SIZE];

/*
============
Cbuf_Init
============
*/
void Cbuf_Init (void)
{
	SZ_Init (&cmd_text, cmd_text_buf, sizeof(cmd_text_buf));
}

/*
============
Cbuf_AddText

Adds command text at the end of the buffer
============
*/
void Cbuf_AddText (char *text)
{
	int		l;
	
	l = strlen (text);

	if (cmd_text.cursize + l >= cmd_text.maxsize)
	{
		Com_Printf ("Cbuf_AddText: overflow\n");
		return;
	}
	SZ_Write (&cmd_text, text, strlen (text));
}


/*
============
Cbuf_InsertText

Adds command text immediately after the current command
Adds a \n to the text
FIXME: actually change the command buffer to do less copying
============
*/
void Cbuf_InsertText (char *text)
{
	char	*temp;
	int		templen;

// copy off any commands still remaining in the exec buffer
	templen = cmd_text.cursize;
	if (templen)
	{
		temp = Z_Malloc (templen);
		memcpy (temp, cmd_text.data, templen);
		SZ_Clear (&cmd_text);
	}
	else
		temp = NULL;	// shut up compiler
		
// add the entire text of the file
	Cbuf_AddText (text);

// Actually end '\n' to the text!
// This fixes annoying quake2 'freezing' on initial server connect

// 1.) Quake2 changes gamedir in CL_ParseServerData and puts 'exec autoexec.cfg' into command buffer
// 2.) Then it appends 'cmd configstrings' to the end
// 3.) When Cbuf_Execute is called, contents of autoexec.cfg is inserted before 'cmd configstrings'
// 4.) If autoexec.cfg doesn't have '\n' at the end, 'cmd configstrings' will be concated to cfg contents
// 5.) As a result, connection sequence will be broken

	if( text[strlen( text ) - 1] != '\n' ) {
		Cbuf_AddText( "\n" );
	}

	
// add the copied off data
	if (templen)
	{
		SZ_Write (&cmd_text, temp, templen);
		Z_Free (temp);
	}
}


/*
============
Cbuf_CopyToDefer
============
*/
void Cbuf_CopyToDefer (void)
{
	memcpy(defer_text_buf, cmd_text_buf, cmd_text.cursize);
	defer_text_buf[cmd_text.cursize] = 0;
	cmd_text.cursize = 0;
}

/*
============
Cbuf_InsertFromDefer
============
*/
void Cbuf_InsertFromDefer (void)
{
	Cbuf_InsertText (defer_text_buf);
	defer_text_buf[0] = 0;
}


/*
============
Cbuf_ExecuteText
============
*/
void Cbuf_ExecuteText (int exec_when, char *text)
{
	switch (exec_when)
	{
	case EXEC_NOW:
		Cmd_ExecuteString (text);
		break;
	case EXEC_INSERT:
		Cbuf_InsertText (text);
		break;
	case EXEC_APPEND:
		Cbuf_AddText (text);
		break;
	default:
		Com_Error (ERR_FATAL, "Cbuf_ExecuteText: bad exec_when");
	}
}

/*
============
Cbuf_Execute
============
*/
void Cbuf_Execute( void ) {
	int		i;
	char	*text;
	char	line[MAX_STRING_CHARS];
	int		quotes;

	alias_count = 0;		// don't allow infinite alias loops

	while( cmd_text.cursize ) {
		if( cmd_wait > 0 ) {
			// skip out while text still remains in buffer, leaving it
			// for next frame
			cmd_wait--;
			break;
		}

// find a \n or ; line break
		text = (char *)cmd_text.data;

		quotes = 0;
		for( i=0 ; i<cmd_text.cursize ; i++ ) {
			if( text[i] == '"' )
				quotes++;
			if( !(quotes & 1) && text[i] == ';' )
				break;	// don't break if inside a quoted string
			if( text[i] == '\n' )
				break;
		}

		// check for buffer overflow
		if( i > sizeof( line ) - 1 ) {
			i = sizeof( line ) - 1;
		}

		memcpy( line, text, i );
		line[i] = 0;
		
// delete the text from the command buffer and move remaining commands down
// this is necessary because commands (exec, alias) can insert data at the
// beginning of the text buffer

		if( i == cmd_text.cursize )
			cmd_text.cursize = 0;
		else {
			i++;
			cmd_text.cursize -= i;
			memmove( text, text+i, cmd_text.cursize );
		}

// execute the command line
		Cmd_ExecuteString( line );

	}
}


/*
===============
Cbuf_AddEarlyCommands

Adds command line parameters as script statements
Commands lead with a +, and continue until another +

Set commands are added early, so they are guaranteed to be set before
the client and server initialize for the first time.

Other commands are added late, after all initialization is complete.
===============
*/
void Cbuf_AddEarlyCommands (qboolean clear)
{
	int		i;
	char	*s;

	for (i=0 ; i<COM_Argc() ; i++)
	{
		s = COM_Argv(i);
		if (strcmp (s, "+set"))
			continue;
		Cbuf_AddText (va("set %s %s\n", COM_Argv(i+1), COM_Argv(i+2)));
		if (clear)
		{
			COM_ClearArgv(i);
			COM_ClearArgv(i+1);
			COM_ClearArgv(i+2);
		}
		i+=2;
	}
}

/*
=================
Cbuf_AddLateCommands

Adds command line parameters as script statements
Commands lead with a + and continue until another + or -
quake +vid_ref gl +map amlev1

Returns qtrue if any late commands were added, which
will keep the demoloop from immediately starting
=================
*/
qboolean Cbuf_AddLateCommands (void)
{
	int		i, j;
	int		s;
	char	*text, *build, c;
	int		argc;
	qboolean	ret;

// build the combined string to parse from
	s = 0;
	argc = COM_Argc();
	for (i=1 ; i<argc ; i++)
	{
		s += strlen (COM_Argv(i)) + 1;
	}
	if (!s)
		return qfalse;
		
	text = Z_Malloc (s+1);
	text[0] = 0;
	for (i=1 ; i<argc ; i++)
	{
		strcat (text,COM_Argv(i));
		if (i != argc-1)
			strcat (text, " ");
	}
	
// pull out the commands
	build = Z_Malloc (s+1);
	build[0] = 0;
	
	for (i=0 ; i<s-1 ; i++)
	{
		if (text[i] == '+')
		{
			i++;

			for (j=i ; (text[j] != '+') && (text[j] != '-') && (text[j] != 0) ; j++)
				;

			c = text[j];
			text[j] = 0;
			
			strcat (build, text+i);
			strcat (build, "\n");
			text[j] = c;
			i = j-1;
		}
	}

	ret = (build[0] != 0);
	if (ret)
		Cbuf_AddText (build);
	
	Z_Free (text);
	Z_Free (build);

	return ret;
}


/*
==============================================================================

						SCRIPT COMMANDS

==============================================================================
*/

#define	MAX_ALIAS_NAME	32

typedef struct cmdalias_s {
	struct cmdalias_s	*next;
	struct cmdalias_s	*hashNext;

	char	name[MAX_ALIAS_NAME];
	char	*value;
} cmdalias_t;

#define ALIASHASH_SIZE	256

static cmdalias_t	*cmd_alias;
static cmdalias_t	*cmd_aliasHash[ALIASHASH_SIZE];

/*
===============
Cmd_AliasFind
===============
*/
static cmdalias_t *Cmd_AliasFind( const char *name ) {
	int hash;
	cmdalias_t *alias;

	hash = Com_HashString( name, ALIASHASH_SIZE );
	for( alias=cmd_aliasHash[hash] ; alias ; alias=alias->hashNext ) {
		if( !Q_stricmp( name, alias->name ) ) {
			return alias;
		}
	}

	return NULL;
}

/*
===============
Cmd_Alias_f

Creates a new command that executes a command string (possibly ; seperated)
===============
*/
static void Cmd_Alias_f( void ) {
	cmdalias_t	*a;
	char		cmd[MAX_STRING_CHARS];
	char		*s;
	int			hash;

	if( Cmd_Argc() < 2 ) {
		Com_Printf( "Current alias commands:\n" );
		for( a=cmd_alias ; a ; a=a->next )
			Com_Printf( "%s : %s\n", a->name, a->value );
		return;
	}

	s = Cmd_Argv( 1 );
	if( strlen( s ) >= MAX_ALIAS_NAME ) {
		Com_Printf( "Alias name is too long\n" );
		return;
	}

	if( Cmd_Argc() < 3 ) {
		a = Cmd_AliasFind( s );
		if( a ) {
			Com_Printf( "\"%s\" = \"%s\"\n", a->name, a->value );
		} else {
			Com_Printf( "\"%s\" is undefined\n", s );
		}
		return;
	}

	// copy the rest of the command line
	Q_strncpyz( cmd, Cmd_ArgsFrom( 2 ), sizeof( cmd ) );
	Q_strcat( cmd, sizeof( cmd ), "\n" );
	

	// if the alias already exists, reuse it
	a = Cmd_AliasFind( s );
	if( a ) {
		Z_Free( a->value );
		a->value = CopyString( cmd );
		return;
	}

	a = Z_Malloc( sizeof( cmdalias_t ) );
	Q_strncpyz( a->name, s, sizeof( a->name ) );
	a->value = CopyString( cmd );

	a->next = cmd_alias;
	cmd_alias = a;

	hash = Com_HashString( s, ALIASHASH_SIZE );
	a->hashNext = cmd_aliasHash[hash];
	cmd_aliasHash[hash] = a;

}


/*
===============
Cmd_Exec_f
===============
*/
/*
===============
Cmd_Exec_f
===============
*/
void Cmd_Exec_f( void ) {
	char	buffer[MAX_QPATH];
	char	*f;
	int		len;

	if( Cmd_Argc () != 2 ) {
		Com_Printf( "exec <filename> : execute a script file\n" );
		return;
	}

	Q_strncpyz( buffer, Cmd_Argv( 1 ), sizeof( buffer ) );

	len = FS_LoadFile( buffer, (void **)&f );
	if( !f ) {
		// Try with *.cfg extension
		COM_DefaultExtension( buffer, ".cfg" );
		len = FS_LoadFile( buffer, (void **)&f );
		if( !f ) {
			Com_Printf( "Couldn't exec %s\n", buffer );
			return;
		}
	}

	Com_Printf( "Execing %s\n", buffer );
	
	Cbuf_InsertText( f );

	FS_FreeFile( f );
}



/*
===============
Cmd_Echo_f

Just prints the rest of the line to the console
===============
*/
void Cmd_Echo_f (void)
{
	int		i;
	
	for (i=1 ; i<Cmd_Argc() ; i++)
		Com_Printf ("%s ",Cmd_Argv(i));
	Com_Printf ("\n");
}

/*
=============================================================================

					MESSAGE TRIGGERS

=============================================================================
*/

typedef struct cmd_trigger_s {
	char		*match;
	char		*command;

	struct cmd_trigger_s	*next;
} cmd_trigger_t;

static cmd_trigger_t	*cmd_triggers;

/*
============
Cmd_Trigger_f
============
*/
static void Cmd_Trigger_f( void ) {
	cmd_trigger_t *trigger;

	if( Cmd_Argc() == 1 ) {
		Com_Printf( "Current message triggers:\n" );
		for( trigger=cmd_triggers ; trigger ; trigger=trigger->next ) {
			Com_Printf( "\"%s\" = \"%s\"\n", trigger->command, trigger->match );
		}
		return;
	}

	if( Cmd_Argc() < 3 ) {
		Com_Printf( "Usage: %s <command> <match>\n", Cmd_Argv( 0 ) );
		return;
	}

	// don't create the same trigger twice
	for( trigger=cmd_triggers ; trigger ; trigger=trigger->next ) {
		if( !strcmp( trigger->command, Cmd_Argv( 1 ) ) &&
			!strcmp( trigger->match, Cmd_ArgsFrom( 2 ) ) )
		{
			return;
		}
	}

	trigger = Z_Malloc( sizeof( cmd_trigger_t ) );
	trigger->next = cmd_triggers;
	cmd_triggers = trigger;

	trigger->command = CopyString( Cmd_Argv( 1 ) );
	trigger->match = CopyString( Cmd_ArgsFrom( 2 ) );
}

/*
============
Cmd_ExecTrigger
============
*/
void Cmd_ExecTrigger( const char *string ) {
	char buffer[MAX_STRING_CHARS];
	int l;
	cmd_trigger_t *trigger;
	const char *text;
	int c;

	// remove unprintable characters
	l = 0;
	while( *string && l < sizeof( buffer ) - 1 ) {
		c = *string & 127;
		if( c > 31 ) {
			buffer[l++] = c;
		}
		string++;
	}
	buffer[l] = 0;

	// execute matching triggers
	for( trigger=cmd_triggers ; trigger ; trigger=trigger->next ) {
		text = Cmd_MacroExpandString( trigger->match );
		if( text && Com_WildCmp( text, buffer, qtrue ) ) {
			Cbuf_AddText( va( "%s\n", trigger->command ) );
		}
	}

	
}

/*
=============================================================================

					MACRO EXECUTION

=============================================================================
*/

typedef struct cmd_macro_s {
	struct cmd_macro_s	*next;
	struct cmd_macro_s	*hashNext;

	const char		*name;
	void		(*function)( char *buffer, int bufferSize );
} cmd_macro_t;

static cmd_macro_t	*cmd_macros;

#define MACROHASH_SIZE	256
static cmd_macro_t	*cmd_macroHash[MACROHASH_SIZE];

/*
============
Cmd_MacroFind
============
*/
static cmd_macro_t *Cmd_MacroFind( const char *name ) {
	cmd_macro_t *macro;
	int hash;

	hash = Com_HashString( name, MACROHASH_SIZE );
	for( macro=cmd_macroHash[hash] ; macro ; macro=macro->hashNext ) {
		if( !Q_stricmp( macro->name, name ) ) {
			return macro;
		}
	}

	return NULL;
}

/*
============
Cmd_AddMacro
============
*/
void Cmd_AddMacro( const char *name, void (*function)( char *, int ) ) {
	cmd_macro_t	*macro;
	int hash;
	
// fail if the macro already exists
	if( Cmd_MacroFind( name ) ) {
		Com_Printf( "Cmd_AddMacro: %s already defined\n", name );
		return;
	}

	hash = Com_HashString( name, MACROHASH_SIZE );

	macro = Z_Malloc( sizeof( cmd_macro_t ) );
	macro->name = name;
	macro->function = function;
	macro->next = cmd_macros;
	cmd_macros = macro;
	macro->hashNext = cmd_macroHash[hash];
	cmd_macroHash[hash] = macro;
}




/*
=============================================================================

					COMMAND EXECUTION

=============================================================================
*/

typedef struct cmd_function_s {
	struct cmd_function_s	*next;
	struct cmd_function_s	*hashNext;

	const char				*name;
	xcommand_t				function;
} cmd_function_t;

static	int			cmd_argc;
static	char		*cmd_argv[MAX_STRING_TOKENS];
static	char		*cmd_null_string = "";
static	char		cmd_args[MAX_STRING_CHARS];
static	char		cmd_argsFrom[MAX_STRING_CHARS];

static	cmd_function_t	*cmd_functions;		// possible commands to execute

#define CMDHASH_SIZE	1024
static cmd_function_t	*cmd_hash[CMDHASH_SIZE];

/*
============
Cmd_Argc
============
*/
int Cmd_Argc( void ) {
	return cmd_argc;
}

/*
============
Cmd_Argv
============
*/
char *Cmd_Argv( int arg ) {
	if( arg < 0 || arg >= cmd_argc ) {
		return cmd_null_string;
	}
	return cmd_argv[arg];	
}

/*
============
Cmd_Args

Returns a single string containing argv(1) to argv(argc()-1)
============
*/
char *Cmd_Args( void ) {
	return cmd_args;
}

/*
============
Cmd_ArgsFrom

Returns a single string containing argv(1) to argv(from-1)
============
*/
char *Cmd_ArgsFrom( int from ) {
	int i;

	cmd_argsFrom[0] = 0;

	if( from < 0 || from >= cmd_argc ) {
		return cmd_argsFrom;
	}
	
	for( i=from ; i<cmd_argc ; i++ ) {
		if( cmd_argsFrom[0] ) {
			Q_strcat( cmd_argsFrom, sizeof( cmd_argsFrom ), " " );
		}
		Q_strcat( cmd_argsFrom, sizeof( cmd_argsFrom ), cmd_argv[i] );
	}

	return cmd_argsFrom;
}


/*
======================
Cmd_MacroExpandString
======================
*/
const char *Cmd_MacroExpandString( const char *text ) {
	int		i, j, count, len;
	qboolean	inquote;
	const char	*scan, *start;
	static	char	expanded[MAX_STRING_CHARS];
	char	temporary[MAX_STRING_CHARS];
	char	buffer[MAX_TOKEN_CHARS];
	char	*token;
	cmd_macro_t *macro;
	cvar_t	*var;
	qboolean	rescan;

	inquote = qfalse;
	scan = text;

	len = strlen( scan );
	if( len >= MAX_STRING_CHARS ) {
		Com_Printf( "Line exceeded %i chars, discarded.\n", MAX_STRING_CHARS );
		return NULL;
	}

	count = 0;

	for( i=0 ; i<len ; i++ ) {
		if( !scan[i] ) {
			break;
		}
		if( scan[i] == '"' ) {
			inquote ^= 1;
		}
		if( inquote ) {
			continue;	// don't expand inside quotes
		}
		if( scan[i] != '$' ) {
			continue;
		}
		
		// scan out the complete macro
		start = scan + i + 1;

		if( !*start ) {
			break;
		}

		// convert $$text to $text and skip
		if( *start == '$' ) {
			strncpy( temporary, scan, i );
			strcpy( temporary + i, start );

			strcpy( expanded, temporary );
			scan = expanded;
			i++;
			continue;
		}

		// fix from jitspoe - skip spaces
		while( *start == 32 ) {
			start++;
		}

		// allow $var$ scripting
		token = temporary;
		while( *start > 32 ) {
			*token++ = *start++;
			if( *start == '$' ) {
				start++;
				break;
			}
		}
		*token = 0;

		if( token == temporary ) {
			continue;
		}

		rescan = qfalse;
		
		// check for macros first
		macro = Cmd_MacroFind( temporary );
		if( macro ) {
			macro->function( buffer, sizeof( buffer ) );
			token = buffer;
		} else {
			var = Cvar_FindVar( temporary );
			if( var && !(var->flags & CVAR_PRIVATE) ) {
				token = var->string;
				rescan = qtrue;
			} else if( !Q_stricmp( temporary, "quote" ) ) {
				token = "\"";
			} else {
				token = "";
			}
		}
		

		j = strlen( token );
		len += j;
		if( len >= MAX_STRING_CHARS ) {
			Com_Printf( "Expanded line exceeded %i chars, discarded.\n", MAX_STRING_CHARS );
			return NULL;
		}

		strncpy( temporary, scan, i );
		strcpy( temporary + i, token );
		strcpy( temporary + i + j, start );

		strcpy( expanded, temporary );
		scan = expanded;
		if( !rescan ) {
			i += j;
		}
		i--;

		if( ++count == 100 ) {
			Com_Printf( "Macro expansion loop, discarded.\n" );
			return NULL;
		}
	}

	if( inquote ) {
		Com_Printf( "Line has unmatched quote, discarded.\n" );
		return NULL;
	}

	return scan;
}

/*
============
Cmd_TokenizeString

Parses the given string into command line tokens.
$Cvars will be expanded unless they are in a quoted token
============
*/
void Cmd_TokenizeString( const char *text, qboolean macroExpand ) {
	int		i;
	char	*com_token;

// clear the args from the last string
	for( i=0 ; i<cmd_argc ; i++ ) {
		Z_Free( cmd_argv[i] );
	}
		
	cmd_argc = 0;
	cmd_args[0] = 0;
	
	// macro expand the text
	if( macroExpand ) {
		text = Cmd_MacroExpandString( text );
	}

	if( !text ) {
		return;
	}

	do {
// skip whitespace up to a /n
		while( *text && *text <= ' ' && *text != '\n' ) {
			text++;
		}
		
		if( *text == '\n' ) {
			// a newline seperates commands in the buffer
			text++;
			break;
		}

		if( !*text ) {
			return;
		}

		// set cmd_args to everything after the first arg
		if( cmd_argc == 1 ) {
			int		l;

			Q_strncpyz( cmd_args, text, sizeof( cmd_args ) );

			// strip off any trailing whitespace
			l = strlen( cmd_args ) - 1;
			for( ; l >= 0 ; l-- ) {
				if( cmd_args[l] <= ' ' ) {
					cmd_args[l] = 0;
				} else {
					break;
				}
			}
		}
			
		com_token = COM_Parse( (char **)&text );
		if( !text ) {
			return;
		}

		cmd_argv[cmd_argc++] = CopyString( com_token );

	} while( cmd_argc != MAX_STRING_TOKENS );
	
}

/*
============
Cmd_Find
============
*/
static cmd_function_t *Cmd_Find( const char *name ) {
	cmd_function_t *cmd;
	int hash;

	hash = Com_HashString( name, CMDHASH_SIZE );
	for( cmd=cmd_hash[hash] ; cmd ; cmd=cmd->hashNext ) {
		if( !Q_stricmp( cmd->name, name ) ) {
			return cmd;
		}
	}

	return NULL;
}

/*
============
Cmd_AddCommand
============
*/
void Cmd_AddCommand( const char *cmd_name, xcommand_t function ) {
	cmd_function_t	*cmd;
	int hash;
	
// fail if the command is a variable name
	if( Cvar_FindVar( cmd_name ) ) {
		Com_Printf( "Cmd_AddCommand: %s already defined as a var\n", cmd_name );
		return;
	}
	
// fail if the command already exists
	if( Cmd_Find( cmd_name ) ) {
		Com_Printf( "Cmd_AddCommand: %s already defined\n", cmd_name );
		return;
	}

	hash = Com_HashString( cmd_name, CMDHASH_SIZE );

	cmd = Z_Malloc( sizeof( cmd_function_t ) );
	cmd->name = cmd_name;
	cmd->function = function;
	cmd->next = cmd_functions;
	cmd_functions = cmd;
	cmd->hashNext = cmd_hash[hash];
	cmd_hash[hash] = cmd;
}

/*
============
Cmd_RemoveCommand
============
*/
void Cmd_RemoveCommand( const char *cmd_name ) {
	cmd_function_t	*cmd, **back;
	int hash;

	back = &cmd_functions;
	while( 1 ) {
		cmd = *back;
		if( !cmd ) {
			Com_Printf( "Cmd_RemoveCommand: %s not added\n", cmd_name );
			return;
		}
		if( !Q_stricmp( cmd_name, cmd->name ) ){
			*back = cmd->next;
			break;
		}
		back = &cmd->next;
	}

	hash = Com_HashString( cmd_name, CMDHASH_SIZE );

	back = &cmd_hash[hash];
	while( 1 ) {
		cmd = *back;
		if( !cmd ) {
			Com_Error( ERR_FATAL, "Cmd_RemoveCommand: %s not found in hash array", cmd_name );
			return;
		}
		if( !Q_stricmp( cmd_name, cmd->name ) ){
			*back = cmd->hashNext;
			Z_Free( cmd );
			break;
		}
		back = &cmd->hashNext;
	}
}

/*
============
Cmd_Exists
============
*/
qboolean Cmd_Exists( const char *cmd_name ) {
	if( Cmd_Find( cmd_name ) ) {
		return qtrue;
	}

	return qfalse;
}



/*
============
Cmd_ListPartial
============
*/
void Cmd_ListPartial( const char *partial, int param, qboolean (*callback)( const char *, int ) ) {
	cmd_function_t	*cmd;
	int				len;
	
	len = strlen( partial );
	if( !len ) {
		return;
	}

// check commands
	for( cmd=cmd_functions ; cmd ; cmd=cmd->next ) {
		if( !Q_strncasecmp( partial, cmd->name, len ) ) {
			if( !callback( cmd->name, param ) ) {
				break;
			}
		}
	}
}

/*
============
Cmd_ListPartialAliases
============
*/
void Cmd_ListPartialAliases( const char *partial, int param, qboolean (*callback)( const char *, int ) ) {
	cmdalias_t		*alias;
	int				len;
	
	len = strlen( partial );
	if( !len ) {
		return;
	}

// check aliases
	for( alias=cmd_alias ; alias ; alias=alias->next ) {
		if( !Q_strncasecmp( partial, alias->name, len ) ) {
			if( !callback( alias->name, param ) ) {
				break;
			}
		}
	}
}

/*
============
Cmd_ExecuteString

A complete command line has been parsed, so try to execute it
FIXME: lookupnoadd the token to speed search?
============
*/
void Cmd_ExecuteString( const char *text ) {	
	cmd_function_t	*cmd;
	cmdalias_t		*a;

	Cmd_TokenizeString( text, qtrue );
			
	// execute the command line
	if( !cmd_argc ) {
		return;		// no tokens
	}

	// check functions
	cmd = Cmd_Find( cmd_argv[0] );
	if( cmd ) {
		if( !cmd->function ) {	
			// forward to server command
			Cmd_ExecuteString( va( "cmd %s", text ) );
		} else {
			cmd->function();
		}
		return;
	}

	// check alias
	a = Cmd_AliasFind( cmd_argv[0] );
	if( a ) {
		if( ++alias_count == ALIAS_LOOP_COUNT ) {
			Com_Printf( "ALIAS_LOOP_COUNT\n" );
			return;
		}
		Cbuf_InsertText( a->value );
		return;
	}
	
	// check cvars
	if( Cvar_Command() )
		return;

	// send it as a server command if we are connected
	Cmd_ForwardToServer();
}

/*
============
Cmd_List_f
============
*/
static void Cmd_List_f( void ) {
	cmd_function_t	*cmd;
	int				i;
	char		*filter = NULL;

	if( cmd_argc > 1 ) {
		filter = cmd_argv[1];
	}

	i = 0;
	for( cmd=cmd_functions ; cmd ; cmd=cmd->next ) {
		if( filter && !Com_WildCmp( filter, cmd->name, qtrue ) ) {
			continue;
		}
		Com_Printf( "%s\n", cmd->name );
		i++;
	}
	Com_Printf( "%i commands\n", i );
}

/*
============
Cmd_MacroList_f
============
*/
static void Cmd_MacroList_f( void ) {
	cmd_macro_t	*macro;
	int				i;
	char		*filter = NULL;

	if( cmd_argc > 1 ) {
		filter = cmd_argv[1];
	}

	i = 0;
	for( macro=cmd_macros ; macro ; macro=macro->next ) {
		if( filter && !Com_WildCmp( filter, macro->name, qtrue ) ) {
			continue;
		}
		Com_Printf( "%s\n", macro->name );
		i++;
	}
	Com_Printf( "%i macros\n", i );
}

/*
============
Cmd_If_f

For insane scripters :)
============
*/
static void Cmd_If_f( void ) {
	char command[MAX_STRING_CHARS];
	char *a, *b, *op;
	qboolean numeric;
	qboolean istrue;
	int i;

	if( Cmd_Argc() < 5 ) {
		Com_Printf( "Usage: if <expr> <op> <expr> then <command> [else <command>]\n" );
	}

	a = Cmd_Argv( 1 );
	op = Cmd_Argv( 2 );
	b = Cmd_Argv( 3 );

#define CHECK_NUMERIC																	\
	if( !numeric ) {																	\
		Com_Printf( "Can't use '%s' with non-numeric expression(s)\n", op );			\
		return;																			\
	}																					\

	numeric = COM_IsNumeric( a ) && COM_IsNumeric( b );
	if( !strcmp( op, "==" ) ) {
		istrue = numeric ? atof( a ) == atof( b ) : !strcmp( a, b );
	} else if( !strcmp( op, "!=" ) || !strcmp( op, "<>" ) ) {
		istrue = numeric ? atof( a ) != atof( b ) : strcmp( a, b );
	} else if( !strcmp( op, "<" ) ) {
		CHECK_NUMERIC;
		istrue = atof( a ) < atof( b );
	} else if( !strcmp( op, "<=" ) ) {
		CHECK_NUMERIC;
		istrue = atof( a ) <= atof( b );
	} else if( !strcmp( op, ">" ) ) {
		CHECK_NUMERIC;
		istrue = atof( a ) > atof( b );
	} else if( !strcmp( op, ">=" ) ) {
		CHECK_NUMERIC;
		istrue = atof( a ) >= atof( b );
	} else if( !Q_stricmp( op, "isin" ) ) {
		istrue = strstr( b, a ) != NULL;
	} else if( !Q_stricmp( op, "!isin" ) ) {
		istrue = strstr( b, a ) == NULL;
	} else if( !Q_stricmp( op, "isini" ) ) {
		strlwr( a ); strlwr( b );
		istrue = strstr( b, a ) != NULL;
	} else if( !Q_stricmp( op, "!isini" ) ) {
		strlwr( a ); strlwr( b );
		istrue = strstr( b, a ) == NULL;
	} else if( !Q_stricmp( op, "eq" ) ) {
		istrue = !Q_stricmp( a, b );
	} else if( !Q_stricmp( op, "ne" ) ) {
		istrue = Q_stricmp( a, b );
	} else {
		Com_Printf( "Unknown operator '%s'\n", op );
		Com_Printf( "Valid are: ==, != or <>, <, <=, >, >=, isin, !isin, isini, !isini, eq, ne\n" );
		return;
	}

	i = 4;
	if( !Q_stricmp( Cmd_Argv( i ), "then" ) ) {
		i++;
	}

	command[0] = 0;
	for( ; i<Cmd_Argc() ; i++ ) {
		if( !Q_stricmp( Cmd_Argv( i ), "else" ) ) {
			break;
		}
		if( istrue ) {
			if( command[0] ) {
				Q_strcat( command, sizeof( command ), " " );
			}
			Q_strcat( command, sizeof( command ), Cmd_Argv( i ) );
		}
	}

	if( istrue ) {
		Q_strcat( command, sizeof( command ), "\n" );
		Cbuf_InsertText( command );
		return;
	}

	i++;
	if( i >= Cmd_Argc() ) {
		return;
	}

	Com_sprintf( command, sizeof( command ), "%s\n", Cmd_ArgsFrom( i ) );
	Cbuf_InsertText( command );
}



/*
============
Cmd_Init
============
*/
void Cmd_Init( void ) {
//
// register our commands
//
	Cmd_AddCommand( "cmdlist", Cmd_List_f );
	Cmd_AddCommand( "macrolist", Cmd_MacroList_f );
	Cmd_AddCommand( "exec", Cmd_Exec_f );
	Cmd_AddCommand( "echo", Cmd_Echo_f );
	Cmd_AddCommand( "alias", Cmd_Alias_f );
	Cmd_AddCommand( "wait", Cmd_Wait_f );
	Cmd_AddCommand( "trigger", Cmd_Trigger_f );
	Cmd_AddCommand( "if", Cmd_If_f );
}


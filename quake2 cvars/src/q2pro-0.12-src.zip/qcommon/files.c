/*
Copyright (C) 1997-2001 Id Software, Inc.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

#include "qcommon.h"
#include "../zlib/zlib.h"

/*
=============================================================================

QUAKE FILESYSTEM

=============================================================================
*/


//
// in memory
//

typedef struct packfile_s {
	char	name[MAX_QPATH];
	int		filepos;
	int		filelen;

	struct packfile_s *hashNext;
} packfile_t;

typedef struct pack_s
{
	char	filename[MAX_OSPATH];
	FILE	*handle;
	int		numfiles;
	packfile_t	*files;
	packfile_t	**fileHash;
	int			hashSize;
} pack_t;

#define FS_BADFILE	0
#define FS_REAL		1
#define FS_GZIP		2

typedef struct fsFile_s {
	int type;
	void *fp;
} fsFile_t;

char	fs_gamedir[MAX_OSPATH];
cvar_t	*fs_basedir;
cvar_t	*fs_cddir;
cvar_t	*fs_gamedirvar;

typedef struct filelink_s
{
	struct filelink_s	*next;
	char	*from;
	int		fromlength;
	char	*to;
} filelink_t;

filelink_t	*fs_links;

typedef struct searchpath_s
{
	char	filename[MAX_OSPATH];
	pack_t	*pack;		// only one of filename / pack will be used
	struct searchpath_s *next;
} searchpath_t;

searchpath_t	*fs_searchpaths;
searchpath_t	*fs_base_searchpaths;	// without gamedirs


/*

All of Quake's data access is through a hierchal file system, but the contents of the file system can be transparently merged from several sources.

The "base directory" is the path to the directory holding the quake.exe and all game directories.  The sys_* files pass this to host_init in quakeparms_t->basedir.  This can be overridden with the "-basedir" command line parm to allow code debugging in a different directory.  The base directory is
only used during filesystem initialization.

The "game directory" is the first tree on the search path and directory that all generated files (savegames, screenshots, demos, config files) will be saved to.  This can be overridden with the "-game" command line parameter.  The game directory can never be changed while quake is executing.  This is a precacution against having a malicious server instruct clients to write files over areas they shouldn't.

*/


/*
================
FS_filelength
================
*/
int FS_FileLength (FILE *f)
{
	int		pos;
	int		end;

	pos = ftell (f);
	fseek (f, 0, SEEK_END);
	end = ftell (f);
	fseek (f, pos, SEEK_SET);

	return end;
}

int FS_GetFileLength( fileHandle_t f ) {
	int		pos;
	int		end;
	fsFile_t *file = (fsFile_t *)f;

	switch( file->type ) {
	case FS_REAL:
		pos = ftell( file->fp );
		fseek( file->fp, 0, SEEK_END );
		end = ftell( file->fp );
		fseek( file->fp, pos, SEEK_SET );
		break;
	case FS_GZIP:
		// FIXME HACK
		gzseek( file->fp, 999999999, SEEK_SET );
		end = gztell( file->fp );
		gzrewind( file->fp );
		break;
	default:
		Com_Error( ERR_FATAL, "FS_FCloseFile: illegal file type" );
		end = -1;
		break;
	}

	return end;
}


/*
============
FS_CreatePath

Creates any directories needed to store the given filename
============
*/
void FS_CreatePath( const char *path ) {
	char buffer[MAX_OSPATH];
	char	*ofs;

	Q_strncpyz( buffer, path, sizeof( buffer ) );
	
	for( ofs=buffer+1 ; *ofs ; ofs++ ) {
		if( *ofs == '/' ) {	
			// create the directory
			*ofs = 0;
			Sys_Mkdir( buffer );
			*ofs = '/';
		}
	}
}


/*
==============
FS_FCloseFile

For some reason, other dll's can't just cal fclose()
on files returned by FS_FOpenFile...
==============
*/
void FS_FCloseFile( fileHandle_t f ) {
	fsFile_t *file = (fsFile_t *)f;

	switch( file->type ) {
	case FS_REAL:
		fclose( file->fp );
		break;
	case FS_GZIP:
		gzclose( file->fp );
		break;
	default:
		Com_Error( ERR_FATAL, "FS_FCloseFile: illegal file type" );
		break;
	}
}


// RAFAEL
/*
	Developer_searchpath
*/
int	Developer_searchpath (int who)
{
	
	int		ch;
	// PMM - warning removal
//	char	*start;
	searchpath_t	*search;
	
	if (who == 1) // xatrix
		ch = 'x';
	else if (who == 2)
		ch = 'r';

	for (search = fs_searchpaths ; search ; search = search->next)
	{
		if (strstr (search->filename, "xatrix"))
			return 1;

		if (strstr (search->filename, "rogue"))
			return 2;
/*
		start = strchr (search->filename, ch);

		if (start == NULL)
			continue;

		if (strcmp (start ,"xatrix") == 0)
			return (1);
*/
	}
	return (0);

}


/*
============
FS_FOpenFileWrite
============
*/
static void FS_FOpenFileWrite( const char *filename, fileHandle_t *hFile, qboolean fullPath  ) {
	char path[MAX_QPATH];
	void *fp;
	qboolean gzip;
	fsFile_t *file;

	if( fullPath ) {
		Com_sprintf( path, sizeof( path ), "%s/%s", fs_basedir->string, filename );
	} else {
		Com_sprintf( path, sizeof( path ), "%s/%s", FS_Gamedir(), filename );
	}

	FS_CreatePath( path );

	gzip = !Q_stricmp( COM_FileExtension( path ), ".gz" );

	if( gzip ) {
		fp = gzopen( path, "wb" );
	} else {
		fp = fopen( path, "wb" );
	}
	
	if( !fp ) {
		*hFile = NULL;
		return;
	}

	file = Z_Malloc( sizeof( *file ) );
	file->fp = fp;
	file->type = gzip ? FS_GZIP : FS_REAL;
	*hFile = (fileHandle_t)file;

}


/*
===========
FS_FOpenFileRead

Finds the file in the search path.
returns filesize and an open FILE *
Used for streaming data out of either a pak file or
a seperate file.
===========
*/
int file_from_pak = 0;

static int FS_FOpenFileRead( const char *filename, fileHandle_t *hFile, qboolean fullPath ) {
	searchpath_t	*search;
	char			netpath[MAX_OSPATH];
	pack_t			*pak;
	filelink_t		*link;
	int				hash;
	packfile_t		*entry;
	void			*fp;
	fsFile_t		*file;
	qboolean		gzip;

	file_from_pak = 0;

	if( fullPath ) {
		// check a file in the directory tree

		Com_sprintf( netpath, sizeof( netpath ), "%s/%s", fs_basedir->string, filename );

		gzip = !Q_stricmp( COM_FileExtension( netpath ), ".gz" );

		if( gzip ) {
			fp = gzopen( netpath, "rb" );
		} else {
			fp = fopen( netpath, "rb" );
		}
		
		if( !fp ) {
			goto fail;
		}
		
		Com_DPrintf( "FindFile: %s\n", netpath );

		file = Z_Malloc( sizeof( *file ) );
		file->fp = fp;
		file->type = gzip ? FS_GZIP : FS_REAL;
		*hFile = (fileHandle_t)file;

		return FS_GetFileLength( file );
	}

	// check for links first
	for( link=fs_links ; link ; link=link->next ) {
		if( !strncmp( filename, link->from, link->fromlength ) ) {
			Com_sprintf( netpath, sizeof( netpath ), "%s%s", link->to, filename + link->fromlength );
			gzip = !Q_stricmp( COM_FileExtension( netpath ), ".gz" );

			if( gzip ) {
				fp = gzopen( netpath, "rb" );
			} else {
				fp = fopen( netpath, "rb" );
			}

			if( !fp ) {
				return -1;
			}
	
			Com_DPrintf( "link file: %s\n", netpath );

			file = Z_Malloc( sizeof( *file ) );
			file->fp = fp;
			file->type = gzip ? FS_GZIP : FS_REAL;
			*hFile = (fileHandle_t)file;

			return FS_GetFileLength( file );
		}
	}

//
// search through the path, one element at a time
//
	for( search=fs_searchpaths ; search ; search=search->next ) {
	// is the element a pak file?
		if( search->pack ) {
		// look through all the pak file elements
			pak = search->pack;
			hash = Com_HashPath( filename, pak->hashSize );
			for( entry=pak->fileHash[hash] ; entry ; entry=entry->hashNext ) {
				if( !Q_stricmp( entry->name, filename ) ) {	
					// found it!
					file_from_pak = 1;
					Com_DPrintf( "PackFile: %s : %s\n", pak->filename, filename );
				// open a new file on the pakfile
					fp = fopen( pak->filename, "rb" );
					if( !fp ) {
						Com_Error( ERR_FATAL, "Couldn't reopen %s", pak->filename );
					}
					fseek( fp, entry->filepos, SEEK_SET );

					file = Z_Malloc( sizeof( *file ) );
					file->fp = fp;
					file->type = FS_REAL;
					*hFile = (fileHandle_t)file;

					return entry->filelen;
				}
			}
		} else {		
	// check a file in the directory tree

			Com_sprintf( netpath, sizeof( netpath ), "%s/%s", search->filename, filename );

			gzip = !Q_stricmp( COM_FileExtension( netpath ), ".gz" );

			if( gzip ) {
				fp = gzopen( netpath, "rb" );
			} else {
				fp = fopen( netpath, "rb" );
			}
			
			if( !fp ) {
				continue;
			}
			
			Com_DPrintf( "FindFile: %s\n", netpath );

			file = Z_Malloc( sizeof( *file ) );
			file->fp = fp;
			file->type = gzip ? FS_GZIP : FS_REAL;
			*hFile = (fileHandle_t)file;

			return FS_GetFileLength( file );

		}
		
	}
	
fail:
	Com_DPrintf( "FindFile: can't find %s\n", filename );
	
	*hFile = NULL;
	return -1;
}




/*
=================
FS_ReadFile

Properly handles partial reads
=================
*/
void CDAudio_Stop( void );
#define	MAX_READ	0x10000		// read in blocks of 64k
int FS_Read( void *buffer, int len, fileHandle_t hFile ) {
	int		block, remaining;
	int		read;
	byte	*buf;
	int		tries;
	fsFile_t	*file = (fsFile_t *)hFile;

	buf = (byte *)buffer;

	// read in chunks for progress bar
	remaining = len;
	tries = 0;
	while( remaining ) {
		block = remaining;
		if( block > MAX_READ )
			block = MAX_READ;
		switch( file->type ) {
		case FS_REAL:
			read = fread( buf, 1, block, file->fp );
			break;
		case FS_GZIP:
			read = gzread( file->fp, buf, block );
			break;
		default:
			Com_Error( ERR_FATAL, "FS_Read: illegal file type" );
			break;
		}
		if( read == 0 ) {
			// we might have been trying to read from a CD
			if( !tries ) {
				tries = 1;
				CDAudio_Stop();
			} else {
				return len - remaining;
			}
		}

		if( read == -1 )
			Com_Error( ERR_FATAL, "FS_Read: -1 bytes read" );

		// do some progress bar thing here...

		remaining -= read;
		buf += read;
	}

	return len;
}

/*
=================
FS_Write

Properly handles partial writes
=================
*/
#define	MAX_WRITE	0x10000		// write in blocks of 64k
int FS_Write( const void *buffer, int len, fileHandle_t hFile ) {
	int		block, remaining;
	int		write;
	byte	*buf;
	fsFile_t	*file = (fsFile_t *)hFile;

	buf = (byte *)buffer;

	// read in chunks for progress bar
	remaining = len;
	while( remaining ) {
		block = remaining;
		if( block > MAX_READ )
			block = MAX_READ;
		switch( file->type ) {
		case FS_REAL:
			write = fwrite( buf, 1, block, file->fp );
			break;
		case FS_GZIP:
			write = gzwrite( file->fp, buf, block );
			break;
		default:
			Com_Error( ERR_FATAL, "FS_Write: illegal file type" );
			break;
		}
		if( write == 0 ) {
			return len - remaining;
		}

		if( write == -1 ) {
			Com_Error( ERR_FATAL, "FS_Write: -1 bytes written" );
		}

		// do some progress bar thing here...

		remaining -= write;
		buf += write;
	}

	return len;
}



/*
============
FS_FOpenFile
============
*/
int FS_FOpenFile( const char *filename, fileHandle_t *f, int mode ) {
	if( strstr( filename, ".." ) ) {
		Com_Printf( "FS_FOpenFile: refusing relative path\n" );
		*f = 0;
		return -1;
	}
	switch( mode ) {
	case FS_READ:
		return FS_FOpenFileRead( filename, f, qfalse );
	case FS_WRITE:
		FS_FOpenFileWrite( filename, f, qfalse );
		return 0;
	default:
		Com_Error( ERR_FATAL, "FS_FOpenFile: illegal mode" );
		break;
	}

	return -1;
}

/*
============
FS_FOpenFileFullPath
============
*/
int FS_FOpenFileFullPath( const char *filename, fileHandle_t *f, int mode ) {
	if( strstr( filename, ".." ) ) {
		Com_Printf( "FS_FOpenFileFullPath: refusing relative path\n" );
		*f = 0;
		return -1;
	}
	switch( mode ) {
	case FS_READ:
		return FS_FOpenFileRead( filename, f, qtrue );
	case FS_WRITE:
		FS_FOpenFileWrite( filename, f, qtrue );
		return 0;
	default:
		Com_Error( ERR_FATAL, "FS_FOpenFileFullPath: illegal mode" );
		break;
	}

	return -1;
}

int FS_Tell( fileHandle_t f ) {
	fsFile_t *file = (fsFile_t *)f;

	switch( file->type ) {
	case FS_REAL:
		return ftell( file->fp ); // TODO: *.pak files support
	case FS_GZIP:
		return gztell( file->fp );
	default:
		Com_Error( ERR_FATAL, "FS_Tell: illegal file type" );
		break;
	}

	return -1;
}


/*
============
FS_LoadFile

Filename are reletive to the quake search path
a null buffer will just return the file length without loading
============
*/
int FS_LoadFile( const char *path, void **buffer ) {
	fileHandle_t h;
	byte	*buf;
	int		len;

	buf = NULL;	// quiet compiler warning

// look for it in the filesystem or pack files
	len = FS_FOpenFileRead( path, &h, qfalse );
	if( !h ) {
		if( buffer )
			*buffer = NULL;
		return -1;
	}
	
	if( buffer ) {
		buf = Z_Malloc( len + 1 );
		*buffer = buf;

		FS_Read( buf, len, h );
		buf[len] = 0;
	}

	FS_FCloseFile( h );

	return len;
}


/*
=============
FS_FreeFile
=============
*/
void FS_FreeFile( void *buffer ) {
	Z_Free( buffer );
}

/*
=================
FS_LoadPackFile

Takes an explicit (not game tree related) path to a pak file.

Loads the header and directory, adding the files at the beginning
of the list so they override previous pack files.
=================
*/
pack_t *FS_LoadPackFile (char *packfile)
{
	dpackheader_t	header;
	int				i;
	packfile_t		*file;
	dpackfile_t		*dfile;
	int				numpackfiles;
	pack_t			*pack;
	FILE			*packhandle;
	dpackfile_t		info[MAX_FILES_IN_PACK];
	unsigned		checksum;
	int				hashSize;
	int				hash;

	packhandle = fopen( packfile, "rb" );
	if( !packhandle )
		return NULL;

	fread( &header, 1, sizeof( header ), packhandle );
	if( LittleLong( header.ident ) != IDPAKHEADER ) {
		Com_Printf( "%s is not a packfile", packfile );
		return NULL;
	}
	header.dirofs = LittleLong( header.dirofs );
	header.dirlen = LittleLong( header.dirlen );

	numpackfiles = header.dirlen / sizeof( dpackfile_t );

	if( numpackfiles > MAX_FILES_IN_PACK ) {
		Com_Printf( "%s has %i files", packfile, numpackfiles );
		return NULL;
	}

	for( hashSize=1 ; hashSize<numpackfiles ; hashSize<<=1 )
		;

	pack = Z_Malloc( sizeof( pack_t ) );
	Q_strncpyz( pack->filename, packfile, sizeof( pack->filename ) );
	pack->handle = packhandle;
	pack->numfiles = numpackfiles;
	pack->hashSize = hashSize;
	pack->files = Z_Malloc( numpackfiles * sizeof( packfile_t ) );
	pack->fileHash = Z_Malloc( hashSize * sizeof( int ) );

	fseek( packhandle, header.dirofs, SEEK_SET );
	fread( info, 1, header.dirlen, packhandle );

// crc the directory to check for modifications
	checksum = Com_BlockChecksum( (void *)info, header.dirlen );

// parse the directory
	for( i=0, file=pack->files, dfile=info ; i<pack->numfiles ; i++, file++, dfile++ ) {
		Q_strncpyz( file->name, dfile->name, sizeof( file->name ) );
		file->filepos = LittleLong( dfile->filepos );
		file->filelen = LittleLong( dfile->filelen );

		hash = Com_HashPath( file->name, hashSize );
		file->hashNext = pack->fileHash[hash];
		pack->fileHash[hash] = file;
	}
	
	Com_Printf( "Added packfile %s (%i files)\n", pack->filename, pack->numfiles );
	return pack;
}


/*
================
FS_AddGameDirectory

Sets fs_gamedir, adds the directory to the head of the path,
then loads and adds pak1.pak pak2.pak ... 
================
*/
void FS_AddGameDirectory( const char *dir ) {
	int				i;
	searchpath_t	*search;
	pack_t			*pak;
	char			pakfile[MAX_OSPATH];
	char **			list;
	int				numFiles;

	Q_strncpyz( fs_gamedir, dir, sizeof( fs_gamedir ) );

	//
	// add the directory to the search path
	//
	search = Z_Malloc( sizeof( searchpath_t ) );
	Q_strncpyz( search->filename, dir, sizeof( search->filename ) );
	search->next = fs_searchpaths;
	fs_searchpaths = search;

	list = Sys_ListFiles( fs_gamedir, ".pak", NULL, -1, &numFiles );
	if( !list ) {
		return;
	}

	//
	// add any pak files in the format *.pak
	//
	for( i=0 ; i<numFiles ; i++ ) {
		Com_sprintf( pakfile, sizeof( pakfile ), "%s/%s", fs_gamedir, list[i] );
		pak = FS_LoadPackFile( pakfile );
		if( !pak )
			continue;
		search = Z_Malloc( sizeof( searchpath_t ) );
		search->pack = pak;
		search->next = fs_searchpaths;
		fs_searchpaths = search;	
	}

	Sys_FreeFileList( list );

}

/*
============
FS_Gamedir

Called to find where to write a file (demos, savegames, etc)
============
*/
char *FS_Gamedir (void)
{
	if (*fs_gamedir)
		return fs_gamedir;
	else
		return BASEDIRNAME;
}

/*
=============
FS_ExecAutoexec
=============
*/
void FS_ExecAutoexec (void)
{
	char *dir;
	char name [MAX_QPATH];

	dir = Cvar_VariableString("gamedir");
	if (*dir)
		Com_sprintf(name, sizeof(name), "%s/%s/autoexec.cfg", fs_basedir->string, dir); 
	else
		Com_sprintf(name, sizeof(name), "%s/%s/autoexec.cfg", fs_basedir->string, BASEDIRNAME); 
	if (Sys_FindFirst(name, 0, SFF_SUBDIR | SFF_HIDDEN | SFF_SYSTEM))
		Cbuf_AddText ("exec autoexec.cfg\n");
	Sys_FindClose();
}


/*
================
FS_SetGamedir

Sets the gamedir and path to a different directory.
================
*/
void FS_SetGamedir (char *dir)
{
	searchpath_t	*next;

	if (strstr(dir, "..") || strstr(dir, "/")
		|| strstr(dir, "\\") || strstr(dir, ":") )
	{
		Com_Printf ("Gamedir should be a single filename, not a path\n");
		return;
	}

	//
	// free up any current game dir info
	//
	while (fs_searchpaths != fs_base_searchpaths)
	{
		if (fs_searchpaths->pack)
		{
			fclose (fs_searchpaths->pack->handle);
			Z_Free (fs_searchpaths->pack->files);
			Z_Free (fs_searchpaths->pack->fileHash);
			Z_Free (fs_searchpaths->pack);
		}
		next = fs_searchpaths->next;
		Z_Free (fs_searchpaths);
		fs_searchpaths = next;
	}

	//
	// flush all data, so it will be forced to reload
	//
	if (dedicated && !dedicated->integer)
		Cbuf_AddText ("vid_restart\nsnd_restart\n");

	Com_sprintf (fs_gamedir, sizeof(fs_gamedir), "%s/%s", fs_basedir->string, dir);

	if (!strcmp(dir,BASEDIRNAME) || (*dir == 0))
	{
		Cvar_FullSet ("gamedir", "", CVAR_SERVERINFO|CVAR_NOSET);
		Cvar_FullSet ("game", "", CVAR_LATCH|CVAR_SERVERINFO);
	}
	else
	{
		Cvar_FullSet ("gamedir", dir, CVAR_SERVERINFO|CVAR_NOSET);
		if (fs_cddir->string[0])
			FS_AddGameDirectory (va("%s/%s", fs_cddir->string, dir) );
		FS_AddGameDirectory (va("%s/%s", fs_basedir->string, dir) );
	}
}


/*
================
FS_Link_f

Creates a filelink_t
================
*/
void FS_Link_f (void)
{
	filelink_t	*l, **prev;

	if (Cmd_Argc() != 3)
	{
		Com_Printf ("USAGE: link <from> <to>\n");
		return;
	}

	// see if the link already exists
	prev = &fs_links;
	for (l=fs_links ; l ; l=l->next)
	{
		if (!strcmp (l->from, Cmd_Argv(1)))
		{
			Z_Free (l->to);
			if (!strlen(Cmd_Argv(2)))
			{	// delete it
				*prev = l->next;
				Z_Free (l->from);
				Z_Free (l);
				return;
			}
			l->to = CopyString (Cmd_Argv(2));
			return;
		}
		prev = &l->next;
	}

	// create a new link
	l = Z_Malloc(sizeof(*l));
	l->next = fs_links;
	fs_links = l;
	l->from = CopyString(Cmd_Argv(1));
	l->fromlength = strlen(l->from);
	l->to = CopyString(Cmd_Argv(2));
}

/*
=================
FS_ListFiles
=================
*/
char **FS_ListFiles( const char *path, const char *extension, const char *filter, int *numFiles ) {
	searchpath_t *search;
	char *listedFiles[MAX_LISTED_FILES];
	int count;
	char buffer[MAX_QPATH];
	char **dirlist;
	int numFilesInDir;
	char **list;
	int i;
	char *name;

	if( numFiles ) {
		*numFiles = 0;
	}

	if( !filter && !path ) {
		return NULL;
	}

//	if( extension ) {
//		if( *extension == '.' ) {
//			extension++;
//		}
//	}

	count = 0;

	for( search=fs_searchpaths ; search ; search=search->next ) {
		if( search->pack ) {
			for( i=0 ; i<search->pack->numfiles ; i++ ) {
				name = search->pack->files[i].name;

				if( filter ) {
					// check filter
					if( !Com_WildCmp( filter, name, qtrue ) ) {
						continue;
					}

					// copy filename with full path
					if( count == MAX_LISTED_FILES ) {
						break;
					}
					listedFiles[count++] = CopyString( name );
				} else {
					// check path
					COM_FilePath( name, buffer, sizeof( buffer ) );
					if( Q_stricmp( path, buffer ) ) {
						continue;
					}

					// check extension
					if( extension && Q_stricmp( extension, COM_FileExtension( name ) ) ) {
						continue;
					}
					
					// copy filename without a path
					if( count == MAX_LISTED_FILES ) {
						break;
					}
					listedFiles[count++] = CopyString( COM_SkipPath( name ) );
				}
			}
		} else {
			if( filter ) {
				Com_sprintf( buffer, sizeof( buffer ), "%s/%s", search->filename, filter );
				dirlist = Sys_ListFiles( search->filename, NULL, buffer, 1, &numFilesInDir );
			} else {
				Com_sprintf( buffer, sizeof( buffer ), "%s/%s", search->filename, path );
				dirlist = Sys_ListFiles( buffer, extension, NULL, -1, &numFilesInDir );
			}

			if( !dirlist ) {
				continue;
			}
			for( i=0 ; i<numFilesInDir ; i++ ) {
				if( count == MAX_LISTED_FILES ) {
					break;
				}
				listedFiles[count++] = CopyString( dirlist[i] );
			}
			Sys_FreeFileList( dirlist );
			
		}
		if( count == MAX_LISTED_FILES ) {
			break;
		}
	}

	if( !count ) {
		return NULL;
	}

	qsort( listedFiles, count, sizeof( listedFiles[0] ), SortStrcmp );

	list = Z_Malloc( sizeof( char * ) * (count + 1) );
	for( i=0 ; i<count ; i++ ) {
		list[i] = listedFiles[i];
	}
	list[count] = NULL;

	if( numFiles ) {
		*numFiles = count;
	}

	return list;


}

/*
=================
FS_FreeFileList
=================
*/
void FS_FreeFileList( char **list ) {
	char **p;

	if( !list ) {
		Com_Error( ERR_FATAL, "FS_FreeFileList: NULL" );
	}

	p = list;
	while( *p ) {
		Z_Free( *p++ );
	}

	Z_Free( list );
}

/*
** FS_Dir_f
*/
static void FS_Dir_f( void ) {
	char	**dirnames;
	int		ndirs = 0;
	int i;

	if( Cmd_Argc() != 2 ) {
		Com_Printf( "Usage: %s <filter>\n", Cmd_Argv( 0 ) );
		return;
	}

	if( (dirnames = FS_ListFiles( NULL, NULL, Cmd_Argv( 1 ), &ndirs )) != NULL ) {
		for( i=0 ; i<ndirs ; i++ ) {
			Com_Printf( "%s\n", dirnames[i] );
		}
		FS_FreeFileList( dirnames );
	}
	Com_Printf( "%i files listed\n", ndirs );
	
}

/*
============
FS_Path_f

============
*/
void FS_Path_f (void)
{
	searchpath_t	*s;
	filelink_t		*l;

	Com_Printf ("Current search path:\n");
	for (s=fs_searchpaths ; s ; s=s->next)
	{
		if (s == fs_base_searchpaths)
			Com_Printf ("----------\n");
		if (s->pack)
			Com_Printf ("%s (%i files)\n", s->pack->filename, s->pack->numfiles);
		else
			Com_Printf ("%s\n", s->filename);
	}

	Com_Printf ("\nLinks:\n");
	for (l=fs_links ; l ; l=l->next)
		Com_Printf ("%s : %s\n", l->from, l->to);
}

/*
================
FS_NextPath

Allows enumerating all of the directories in the search path
================
*/
char *FS_NextPath (char *prevpath)
{
	searchpath_t	*s;
	char			*prev;

	if (!prevpath)
		return fs_gamedir;

	prev = fs_gamedir;
	for (s=fs_searchpaths ; s ; s=s->next)
	{
		if (s->pack)
			continue;
		if (prevpath == prev)
			return s->filename;
		prev = s->filename;
	}

	return NULL;
}


/*
================
FS_InitFilesystem
================
*/
void FS_InitFilesystem (void)
{
	Cmd_AddCommand ("path", FS_Path_f);
	Cmd_AddCommand ("link", FS_Link_f);
	Cmd_AddCommand ("dir", FS_Dir_f );

	//
	// basedir <path>
	// allows the game to run from outside the data tree
	//
	fs_basedir = Cvar_Get ("basedir", ".", CVAR_NOSET);

	//
	// cddir <path>
	// Logically concatenates the cddir after the basedir for 
	// allows the game to run from outside the data tree
	//
	fs_cddir = Cvar_Get ("cddir", "", CVAR_NOSET);
	if (fs_cddir->string[0])
		FS_AddGameDirectory (va("%s/"BASEDIRNAME, fs_cddir->string) );

	//
	// start up with baseq2 by default
	//
	FS_AddGameDirectory (va("%s/"BASEDIRNAME, fs_basedir->string) );

	// any set gamedirs will be freed up to here
	fs_base_searchpaths = fs_searchpaths;

	// check for game override
	fs_gamedirvar = Cvar_Get ("game", "", CVAR_LATCH|CVAR_SERVERINFO);
	if (fs_gamedirvar->string[0])
		FS_SetGamedir (fs_gamedirvar->string);
}




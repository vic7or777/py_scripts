/*
Copyright (C) 1997-2001 Id Software, Inc.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/
// delta.c -- delta encoder/decoder

#include "qcommon.h"

static deltaState_t	*deltaState;
static deltaFrame_t	*deltaFrame;
static deltaFrame_t	*deltaFrameOld;
static sizebuf_t	*deltaMsg;

/*
==================
Delta_Entity
==================
*/
static void Delta_Entity( int newnum, entity_state_t *old, int bits ) {
	entity_state_t	*state;

	state = &deltaState->entityStates[deltaState->numEntityStates & PARSE_ENTITIES_MASK];
	deltaState->numEntityStates++;
	deltaFrame->numEntityStates++;

	MSG_ParseDeltaEntity( old, state, newnum, bits, deltaMsg );

	deltaState->deltaEntityCallback( deltaFrame, old, state );
}

/*
==================
Delta_ParsePacketEntities
==================
*/
static void Delta_ParsePacketEntities( void ) {
	int			newnum;
	int			bits;
	entity_state_t	*oldstate;
	int			oldindex, oldnum;

	deltaFrame->firstEntityState = deltaState->numEntityStates;
	deltaFrame->numEntityStates = 0;

	// delta from the entities present in oldframe
	oldindex = 0;
	if( !deltaFrameOld ) {
		oldnum = 99999;
	} else {
		if( oldindex >= deltaFrameOld->numEntityStates ) {
			oldnum = 99999;
		} else {
			oldstate = &deltaState->entityStates[(deltaFrameOld->firstEntityState + oldindex) & PARSE_ENTITIES_MASK];
			oldnum = oldstate->number;
		}
	}

	while( 1 ) {
		newnum = MSG_ParseEntityBits( &bits, deltaMsg );
		if( newnum < 0 || newnum >= MAX_EDICTS ) {
			Com_Error( ERR_DROP, "Delta_ParsePacketEntities: bad number %i", newnum );
		}

		if( deltaMsg->readcount > deltaMsg->cursize ) {
			Com_Error( ERR_DROP, "Delta_ParsePacketEntities: end of message" );
		}

		if( !newnum ) {
			break;
		}

		while( oldnum < newnum ) {	// one or more entities from the old packet are unchanged
			if( deltaState->debug ) {
				Com_Printf( "   unchanged: %i\n", oldnum );
			}
			Delta_Entity( oldnum, oldstate, 0 );
			
			oldindex++;

			if( oldindex >= deltaFrameOld->numEntityStates ) {
				oldnum = 99999;
			} else {
				oldstate = &deltaState->entityStates[(deltaFrameOld->firstEntityState + oldindex) & PARSE_ENTITIES_MASK];
				oldnum = oldstate->number;
			}
		}

		if( bits & U_REMOVE ) {	
			// the entity present in oldframe is not in the current frame
			if( deltaState->debug ) {
				Com_Printf( "   remove: %i\n", newnum );
			}
			if( oldnum != newnum ) {
				Com_DPrintf( "U_REMOVE: oldnum != newnum\n" );
			}

			oldindex++;

			if( oldindex >= deltaFrameOld->numEntityStates ) {
				oldnum = 99999;
			} else {
				oldstate = &deltaState->entityStates[(deltaFrameOld->firstEntityState + oldindex) & PARSE_ENTITIES_MASK];
				oldnum = oldstate->number;
			}
			continue;
		}

		if( oldnum == newnum ) {	
			// delta from previous state
			if( deltaState->debug ) {
				Com_Printf( "   delta: %i ", newnum );
			}
			Delta_Entity( newnum, oldstate, bits );
			if( deltaState->debug ) {
				Com_Printf( "\n", newnum );
			}

			oldindex++;

			if( oldindex >= deltaFrameOld->numEntityStates ) {
				oldnum = 99999;
			} else {
				oldstate = &deltaState->entityStates[(deltaFrameOld->firstEntityState + oldindex) & PARSE_ENTITIES_MASK];
				oldnum = oldstate->number;
			}
			continue;
		}

		if( oldnum > newnum ) {	
			// delta from baseline
			if( deltaState->debug ) {
				Com_Printf( "   baseline: %i ", newnum );
			}
			Delta_Entity( newnum, &deltaState->baselines[newnum], bits );
			if( deltaState->debug ) {
				Com_Printf( "\n", newnum );
			}
			continue;
		}

	}

	// any remaining entities in the old frame are copied over
	while( oldnum != 99999 ) {	
		// one or more entities from the old packet are unchanged
		if( deltaState->debug ) {
			Com_Printf( "   unchanged: %i\n", oldnum );
		}
		Delta_Entity( oldnum, oldstate, 0 );
		
		oldindex++;

		if( oldindex >= deltaFrameOld->numEntityStates ) {
			oldnum = 99999;
		} else {
			oldstate = &deltaState->entityStates[(deltaFrameOld->firstEntityState + oldindex) & PARSE_ENTITIES_MASK];
			oldnum = oldstate->number;
		}
	}
}

/*
==================
Delta_Player
==================
*/
static void Delta_Player( int newnum, player_state_t *old, int bits ) {
	player_state_t	*state;

	state = &deltaState->playerStates[deltaState->numPlayerStates & PARSE_PLAYERS_MASK];
	deltaState->numPlayerStates++;
	deltaFrame->numPlayerStates++;

	MSG_ParseDeltaPlayerstate( old, state, newnum, bits, deltaMsg );

	deltaState->deltaPlayerCallback( deltaFrame, old, state );
}

/*
==================
Delta_ParsePacketEntities
==================
*/
static void Delta_ParsePacketPlayers( void ) {
	int			newnum;
	int			bits;
	player_state_t	*oldstate;
	int			oldindex, oldnum;

	deltaFrame->firstPlayerState = deltaState->numPlayerStates;
	deltaFrame->numPlayerStates = 0;

	// delta from the entities present in oldframe
	oldindex = 0;
	if( !deltaFrameOld ) {
		oldnum = 99999;
	} else {
		if( oldindex >= deltaFrameOld->numPlayerStates ) {
			oldnum = 99999;
		} else {
			oldstate = &deltaState->playerStates[(deltaFrameOld->firstPlayerState + oldindex) & PARSE_PLAYERS_MASK];
			oldnum = oldstate->stats[STAT_PLAYERNUM];
		}
	}

	while( 1 ) {
		newnum = MSG_ReadByte( deltaMsg );
		if( newnum < 0 || newnum >= MAX_CLIENTS ) {
			Com_Error( ERR_DROP, "Delta_ParsePacketPlayers: bad number %i", newnum );
		}

		if( deltaMsg->readcount > deltaMsg->cursize ) {
			Com_Error( ERR_DROP, "Delta_ParsePacketPlayers: end of message" );
		}

		if( newnum == MAX_CLIENTS - 1 ) {
			break;
		}

		bits = MSG_ReadShort( deltaMsg );

		while( oldnum < newnum ) {	// one or more entities from the old packet are unchanged
			if( deltaState->debug ) {
				Com_Printf( "   unchanged: %i\n", oldnum );
			}
			Delta_Player( oldnum, oldstate, 0 );
			
			oldindex++;

			if( oldindex >= deltaFrameOld->numPlayerStates ) {
				oldnum = 99999;
			} else {
				oldstate = &deltaState->playerStates[(deltaFrameOld->firstPlayerState + oldindex) & PARSE_PLAYERS_MASK];
				oldnum = oldstate->stats[STAT_PLAYERNUM];
			}
		}

		if( bits & PS_REMOVE ) {	
			// the entity present in oldframe is not in the current frame
			if( deltaState->debug ) {
				Com_Printf( "   remove: %i\n", newnum );
			}
			if( oldnum != newnum ) {
				Com_DPrintf( "U_REMOVE: oldnum != newnum\n" );
			}

			oldindex++;

			if( oldindex >= deltaFrameOld->numPlayerStates ) {
				oldnum = 99999;
			} else {
				oldstate = &deltaState->playerStates[(deltaFrameOld->firstPlayerState + oldindex) & PARSE_PLAYERS_MASK];
				oldnum = oldstate->stats[STAT_PLAYERNUM];
			}
			continue;
		}

		if( oldnum == newnum ) {	
			// delta from previous state
			if( deltaState->debug ) {
				Com_Printf( "   delta: %i ", newnum );
			}
			Delta_Player( newnum, oldstate, bits );
			if( deltaState->debug ) {
				Com_Printf( "\n", newnum );
			}

			oldindex++;

			if( oldindex >= deltaFrameOld->numPlayerStates ) {
				oldnum = 99999;
			} else {
				oldstate = &deltaState->playerStates[(deltaFrameOld->firstPlayerState + oldindex) & PARSE_PLAYERS_MASK];
				oldnum = oldstate->stats[STAT_PLAYERNUM];
			}
			continue;
		}

		if( oldnum > newnum ) {	
			// delta from baseline
			if( deltaState->debug ) {
				Com_Printf( "   baseline: %i ", newnum );
			}
			Delta_Player( newnum, NULL, bits );
			if( deltaState->debug ) {
				Com_Printf( "\n", newnum );
			}
			continue;
		}

	}

	// any remaining entities in the old frame are copied over
	while( oldnum != 99999 ) {	
		// one or more entities from the old packet are unchanged
		if( deltaState->debug ) {
			Com_Printf( "   unchanged: %i\n", oldnum );
		}
		Delta_Player( oldnum, oldstate, 0 );
		
		oldindex++;

		if( oldindex >= deltaFrameOld->numPlayerStates ) {
			oldnum = 99999;
		} else {
			oldstate = &deltaState->playerStates[(deltaFrameOld->firstPlayerState + oldindex) & PARSE_PLAYERS_MASK];
			oldnum = oldstate->stats[STAT_PLAYERNUM];
		}
	}
}

/*
================
Delta_ParseFrame
================
*/
deltaFrame_t *Delta_ParseFrame( deltaState_t *state, sizebuf_t *msg ) {
	static deltaFrame_t frame;
	int cmd;
	int len;

	deltaState = state;
	deltaMsg = msg;
	deltaFrame = &frame;
	
	memset( deltaFrame, 0, sizeof( *deltaFrame ) );

	deltaFrame->serverFrame = MSG_ReadLong( deltaMsg );
	deltaFrame->deltaFrame = MSG_ReadLong( deltaMsg );

	// BIG HACK to let old demos continue to work
	if( deltaState->protocol != 26 ) {
		deltaState->surpressCount = MSG_ReadByte( deltaMsg );
	}

	// If the frame is delta compressed from data that we
	// no longer have available, we must suck up the rest of
	// the frame, but not use it, then ask for a non-compressed
	// message 
	if( deltaFrame->deltaFrame > 0 ) {
		deltaFrameOld = &deltaState->frames[deltaFrame->deltaFrame & UPDATE_MASK];
		if( !deltaFrameOld->valid ) {	
			// should never happen
			Com_Printf( "Delta from invalid frame (not supposed to happen!).\n" );
		} else if( deltaFrameOld->serverFrame != deltaFrame->deltaFrame ) {
			// The frame that the server did the delta from
			// is too old, so we can't reconstruct it properly.
			Com_Printf ("Delta frame too old.\n");
		} else if( deltaState->numEntityStates - deltaFrameOld->firstEntityState > MAX_PARSE_ENTITIES-128 ) {
			Com_Printf ("Delta parse_entities too old.\n");
		} else if( deltaState->numPlayerStates - deltaFrameOld->firstPlayerState > MAX_PARSE_PLAYERS-32 ) {
			Com_Printf ("Delta parse_players too old.\n");
		} else {
			deltaFrame->valid = qtrue;	// valid delta parse
		}
	} else {
		deltaFrameOld = NULL;
		deltaFrame->valid = qtrue;		// uncompressed frame
	}

	// read areabits
	len = MSG_ReadByte( deltaMsg );
	if( len ) {
		MSG_ReadData( deltaMsg, &deltaFrame->areabits, len );
	} else {
		memset( deltaFrame->areabits, 255, sizeof( deltaFrame->areabits ) );
	}

	// read playerinfo
	cmd = MSG_ReadByte( deltaMsg );
//	SHOWNET( svc_strings[cmd] );
	if( cmd != svc_playerinfo ) {
		Com_Error( ERR_DROP, "Delta_ParseFrame: not playerinfo" );
	}
	if( deltaState->protocol != PROTOCOL_VERSION_Q2PRO ) {
		// old good 3.20 protocol
		player_state_t *from = NULL;
		int bits;

		if( deltaFrameOld ) {
			from = &deltaState->playerStates[deltaFrameOld->firstPlayerState & PARSE_PLAYERS_MASK];
		}

		deltaFrame->firstPlayerState = state->numPlayerStates;
		deltaFrame->numPlayerStates = 0;

		bits = MSG_ReadShort( deltaMsg );
		Delta_Player( deltaState->localClientNum, from, bits );
	} else {
		// new MVD protocol
		Delta_ParsePacketPlayers();
	}

	// read packet entities
	cmd = MSG_ReadByte( deltaMsg );
//	SHOWNET( svc_strings[cmd] );
	if( cmd != svc_packetentities ) {
		Com_Error( ERR_DROP, "Delta_ParseFrame: not packetentities" );
	}
	Delta_ParsePacketEntities();

	// save the frame off in the backup array for later delta comparisons
	deltaState->frames[deltaFrame->serverFrame & UPDATE_MASK] = *deltaFrame;

	return deltaFrame;

}

/*
=============
MVD_EmitPacketEntities

Writes a delta update of an entity_state_t list to the message.
=============
*/
static void Delta_EmitPacketEntities( void ) {
	entity_state_t	*oldent, *newent;
	int		oldindex, newindex;
	int		oldnum, newnum;
	int		from_num_entities;

	if( !deltaFrameOld ) {
		from_num_entities = 0;
	} else {
		from_num_entities = deltaFrameOld->numEntityStates;
	}

	newindex = 0;
	oldindex = 0;
	while( newindex < deltaFrame->numEntityStates || oldindex < from_num_entities ) {
		if( newindex >= deltaFrame->numEntityStates ) {
			newnum = 9999;
		} else {
			newent = &deltaState->entityStates[(deltaFrame->firstEntityState + newindex) & PARSE_ENTITIES_MASK];
			newnum = newent->number;
		}

		if( oldindex >= from_num_entities ) {
			oldnum = 9999;
		} else {
			oldent = &deltaState->entityStates[(deltaFrameOld->firstEntityState + oldindex) & PARSE_ENTITIES_MASK];
			oldnum = oldent->number;
		}

		if( newnum == oldnum ) {	
			// delta update deltaFrameOld old position
			// because the force parm is qfalse, this will not result
			// in any bytes being emited if the entity has not changed at all
			// note that players are always 'newentities', this updates their oldorigin always
			// and prevents warping
			MSG_WriteDeltaEntity( oldent, newent, deltaMsg, qfalse, (qboolean)(newent->number <= deltaState->localClientNum ) );
			oldindex++;
			newindex++;
			continue;
		}

		if( newnum < oldnum ) {
			// this is a new entity, send it deltaFrameOld the baseline
			MSG_WriteDeltaEntity( &deltaState->baselines[newnum], newent, deltaMsg, qtrue, qtrue );
			newindex++;
			continue;
		}

		if( newnum > oldnum ) {
			// the old entity isn't present in the new message
			MSG_WriteDeltaEntity( oldent, NULL, deltaMsg, qtrue, qfalse );
			oldindex++;
			continue;
		}
	}

	MSG_WriteShort( deltaMsg, 0 );	// end of packetentities
}

/*
=============
MVD_EmitPacketEntities

Writes a delta update of an player_state_t list deltaFrame the message.
=============
*/
static void Delta_EmitPacketPlayers( void ) {
	player_state_t	*oldps, *newps;
	int		oldindex, newindex;
	int		oldnum, newnum;
	int		from_num_players;

	if( !deltaFrameOld ) {
		from_num_players = 0;
	} else {
		from_num_players = deltaFrameOld->numPlayerStates;
	}

	newindex = 0;
	oldindex = 0;
	while( newindex < deltaFrame->numPlayerStates || oldindex < from_num_players ) {
		if( newindex >= deltaFrame->numPlayerStates ) {
			newnum = 9999;
		} else {
			newps = &deltaState->playerStates[(deltaFrame->firstPlayerState + newindex) & PARSE_PLAYERS_MASK];
			newnum = newps->stats[STAT_PLAYERNUM];
		}

		if( oldindex >= from_num_players ) {
			oldnum = 9999;
		} else {
			oldps = &deltaState->playerStates[(deltaFrameOld->firstPlayerState + oldindex) & PARSE_PLAYERS_MASK];
			oldnum = oldps->stats[STAT_PLAYERNUM];
		}

		if( newnum == oldnum ) {	
			// delta update deltaFrameOld old position
			// because the force parm is qfalse, this will not result
			// in any bytes being emited if the entity has not changed at all
			MSG_WriteDeltaPlayerstate( oldps, newps, qfalse, deltaMsg );
			oldindex++;
			newindex++;
			continue;
		}

		if( newnum < oldnum ) {
			// this is a new entity, send it deltaFrameOld the baseline
			MSG_WriteDeltaPlayerstate( NULL, newps, qtrue, deltaMsg );
			newindex++;
			continue;
		}

		if( newnum > oldnum ) {
			// the old entity isn't present in the new message
			MSG_WriteDeltaPlayerstate( oldps, NULL, qtrue, deltaMsg );
			oldindex++;
			continue;
		}
	}

	MSG_WriteByte( deltaMsg, MAX_CLIENTS - 1 );	// end of packetentities
}

/*
================
Delta_BeginFrame
================
*/
void Delta_BeginFrame( deltaState_t *state, sizebuf_t *msg ) {
	deltaState = state;
	deltaMsg = msg;

	deltaFrame = &deltaState->frames[deltaState->frameNum & UPDATE_MASK];
	if( deltaState->frameNum > 1 ) {
		deltaFrameOld = &deltaState->frames[(deltaState->frameNum - 1) & UPDATE_MASK];
	} else {
		deltaFrameOld = NULL;
	}

	deltaFrame->numEntityStates = 0;
	deltaFrame->firstEntityState = deltaState->numEntityStates;

	deltaFrame->numPlayerStates = 0;
	deltaFrame->firstPlayerState = deltaState->numPlayerStates;

}

/*
================
Delta_AllocEntity
================
*/
entity_state_t *Delta_AllocEntity( void ) {
	entity_state_t *es;
		
	es = &deltaState->entityStates[deltaState->numEntityStates & PARSE_ENTITIES_MASK];

	deltaState->numEntityStates++;
	deltaFrame->numEntityStates++;

	return es;
}

/*
================
Delta_AllocPlayer
================
*/
player_state_t *Delta_AllocPlayer( void ) {
	player_state_t *ps;

	ps = &deltaState->playerStates[deltaState->numPlayerStates & PARSE_PLAYERS_MASK];

	deltaState->numPlayerStates++;
	deltaFrame->numPlayerStates++;

	return ps;
}

/*
================
Delta_FinishFrame
================
*/
void Delta_FinishFrame( void ) {
	int oldFrameNum;

	if( deltaFrameOld ) {
		oldFrameNum = deltaState->frameNum - 1;
	} else {
		oldFrameNum = -1;
	}

	MSG_WriteByte( deltaMsg, svc_frame );
	MSG_WriteLong( deltaMsg, deltaState->frameNum );		// frame num
	MSG_WriteLong( deltaMsg, oldFrameNum );		// delta frame num
	MSG_WriteByte( deltaMsg, 0 );				// surpress count
	MSG_WriteByte( deltaMsg, 0 );				// num of areabytes

	MSG_WriteByte( deltaMsg, svc_playerinfo );
	Delta_EmitPacketPlayers();

	MSG_WriteByte( deltaMsg, svc_packetentities );
	Delta_EmitPacketEntities();

	deltaState->frameNum++;
}








